<?php

use DrPlus\Components\ProIcon;
use DrPlus\Specialist;
use DrPlus\Utils;
use DrPlus\Utils\Archive;
use DrPlus\Utils\Elementor;
use DrPlus\Utils\Product;
use DrPlus\Utils\Search;
use DrPlus\Utils\Speciality;
use DrPlus\Utils\UtilsSpecialists;

$post_type = $args['post_type'];

$display_settings = [
	'desktop_slider'	=> false,
	'desktop_cols'		=> 3,
	'desktop_gap'		=> 16,

	'tablet_slider'	=> false,
	'tablet_cols'	=> 2,
	'tablet_gap'	=> 16,

	'mobile_slider'	=> false,
	'mobile_cols'	=> 1,
	'mobile_gap'	=> 16,
];
$display_attributes = Elementor::get_display_attributes( $display_settings );

$div_attrs = [
	'class'	=> array_merge( [
		"{$post_type}-wrap",
		'search-section',
	], $display_attributes['wrap_classes'] ),
	'data-settings'	=> $display_attributes['args'],
	'style'			=> $display_attributes['style'],
];
if( $post_type == 'specialist' ) {
	$div_attrs['class'][] = 'specialists';
} else if( $post_type == 'speciality' ) {
	$div_attrs['class'][] = 'specialities';
} else if( $post_type == 'hospital' ) {
	$div_attrs['class'][] = 'hospitals';
} else if( $post_type != 'product' ) { // Other post type but not product
	$div_attrs['class'][] = 'list-posts';
}

$wrapper_attrs = [
	'class'	=> array_merge( [
		'wrapper',
	], $display_attributes['classes'] ),
];

// To get icon and labels of post type
$categorized_results = Search::get_categorized_results();

echo "<div " . Utils::get_html_attributes( $div_attrs ) . ">";
	if( $post_type == 'specialist' ) {
		get_template_part( "templates/search/templates-search-section-head", null, [
			'show_more'	=> false,
			'icon'		=> $categorized_results['specialist']['icon'],
			'label'		=> $categorized_results['specialist']['label'],
			'count'		=> $categorized_results['specialist']['count'],
			'post_type'	=> $post_type,
		] );
	} else {
		get_template_part( "templates/search/templates-search-section-head", null, [
			'show_more'	=> false,
			'icon'		=> $categorized_results[$post_type]['icon'],
			'label'		=> $categorized_results[$post_type]['label'],
			'count'		=> $categorized_results[$post_type]['count'],
		] );
	}
	echo "<div " . Utils::get_html_attributes( $wrapper_attrs ) . ">";
		if( $post_type == 'specialist' ) {
			$upp = get_option( 'posts_per_page' );
			$page_number = Archive::get_paged();
			$specialists_query = UtilsSpecialists::search( get_search_query(), [
				'number'		=> $upp,
				'count_total'	=> true,
				'fields'		=> 'all',
				'paged'			=> $page_number,
			], 'query' );
			$total_specialists = $specialists_query->get_total();

			$specialists = [];
			foreach( $specialists_query->get_results() as $user ) {
				$specialists[] = new Specialist( null, $user );
			}

			UtilsSpecialists::list_html( [
				'specialists'	=> $specialists,
				'settings'		=> $display_settings,
				'remove_wrap'	=> true,
			] );

			get_template_part( "templates/archives/template-archives-pagination", 'custom', [
				'max_num_pages'	=> ceil( $total_specialists / $upp ),
				'paged'			=> $page_number,
			] );
		} else {
			if( have_posts() ) {
				if( $post_type == 'product' ) {
					$props = Product::get_default_props();
					$props = Utils::check_default( $display_settings, $props ); // Set props values from display_settings
					$props['remove_swiper_div'] = true;
					
					wc_set_loop_prop( 'drplus_loop_props', $props );
					woocommerce_product_loop_start();
				}
				while( have_posts() ) {
					the_post();
					if( $post_type == 'product' ) {
						$GLOBALS['product'] = wc_get_product();
						/**
						 * Hook: woocommerce_shop_loop.
						 */
						do_action( 'woocommerce_shop_loop' );
						wc_get_template_part( 'content', 'product' );
					} else {
						if( $post_type == 'speciality' ) {
							$speciality_options = Speciality::get_options( get_the_ID() );
							ProIcon::view( [
								'icon_type'	=> 'icon',
								'icon'		=> $speciality_options['icon'],
								'title'		=> get_the_title(),
								'subtitle'	=> sprintf( esc_html__( "%d specialists", 'drplus' ), Speciality::count_specialists( get_the_ID() ) ),
								'link'		=> Speciality::get_archive_link( get_post() ),
							] );
						} else if( $post_type == 'hospital' ) {
							get_template_part( "templates/archives/template-archives-hospital" );
						} else {
							get_template_part( "templates/archives/template-archives-post", null, [
								'title_tag'			=> $args['options']['search_post_title_tag'],
								'time_type'			=> $args['options']['search_post_time_type'],
								'show_read_more'	=> $args['options']['search_post_show_read_more'],
								'read_more_text'	=> $args['options']['search_post_read_more_text'],
								'read_more_icon'	=> $args['options']['search_post_read_more_icon'],
							] );
						}
					}
				}
				if( $post_type == 'product' ) {
					woocommerce_product_loop_end();
				}

				get_template_part( "templates/archives/template-archives-pagination" );
			}
		}
	echo "</div>";
echo "</div>";