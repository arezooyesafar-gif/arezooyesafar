(function($) {
	$(document).ready(function(){
		// Upload new avatar
		$('#drplus-edit-avatar').on('click', function(e) {
			e.preventDefault();
			let wrap = $(this).closest('.drplus-edit-avatar-wrap-row'),
				selectedFileInput = wrap.find('#account_avatar_id');
			var fileFrame = wp.media.frames.file_frame = wp.media({
				frame: 'select',
				editing : false,
				multiple : false,
				library: {
					type: 'image'
				},
				selection : ""
			});

			fileFrame.on('open', function() {
				var selection = fileFrame.state().get('selection');
				let attachment = wp.media.attachment( selectedFileInput.val() );
				selection.add( attachment ? [ attachment ] : []);
			});

			fileFrame.on('select', function() {
				var selection = fileFrame.state().get('selection').first();

				selectedFileInput.val(selection.attributes.id);
				// Show avatar
				wrap.find('.drplus-edit-avatar-wrap img').attr('src', selection.attributes.url).removeAttr('srcset');
			});

			fileFrame.open();
		});
		$('.drplus-delete-avatar-icon').on('click', function(e) {
			e.stopPropagation();
			$('#account_avatar_id').val('');
			$(this).siblings('img').attr('src', drplusVars.defaults.avatar).removeAttr('srcset');
		});

		function checkFormError() {
			let active = true;
			$('.onboard-form *:is(input, select, textarea)[required]').each(function() {
				if(!$(this).val() || $(this).closest('.error').length) {
					active = false;
				}
			});
			if(active) {
				$('#onboard-submit').removeClass('disabled')
			} else {
				$('#onboard-submit').addClass('disabled')
			}
		}

		function setError(fieldset, error = '') {
			if(error) {
				fieldset.find('.input-error-text').text(error);
				fieldset.addClass('error');
			} else {
				fieldset.removeClass('error');
			}
		}

		$(document).on('change', '.onboard-form input, .onboard-form textarea, .onboard-form select', function() { // Check for empty required fields
			let $input = $(this),
				value = $input.val(),
				fieldset = $input.closest('.input-group'),
				error = $input.is(":required") && !value;
			if( error ) {
				setError(fieldset, drplusOnboard.i18n.requiredField)
			}
			if(!error) { // Validate fields
				if( $input.is("[type=email]") && !drplus.validateEmail(value)) { // Email
					error = true;
					setError(fieldset, drplusOnboard.i18n.wrongEmail)
				} else if( $input.hasClass('drplus-nid-input') && !drplus.validateIDCode(value) ) {
					error = true;
					setError(fieldset, drplusVars.i18n.wrongIDCode);
				} else if( $input.hasClass('drplus-phone-input') && !drplus.validateMobile(value) ) {
					error = true;
					setError(fieldset, drplusVars.i18n.wrongMobile);
				}
			}
			if( !error ) {
				setError(fieldset)
			}
			checkFormError()
		});

		let dropzones = {};
		if($('.drplus-dropzone').length) {
			Dropzone.autoDiscover = false;
			dropzones = drplus.initDropzone(dropzones);
		}
		$(document).on('click', '.drplus-dropzone-current-value-remove', function() {
			let wrap = $(this).closest('.drplus-dropzone-wrap'),
				index = wrap.attr('data-index');
			dropzones[index].removeAllFiles();
			$(this).closest('.drplus-dropzone-current-value').remove();
			wrap.find('input[type="hidden"]').val('').trigger('change');
		})

		// Search
		$('.onboard-search').on('input', function() {
			let $this = $(this),
				term = $this.val(),
				errorElement = $this.closest('.onboard-search-wrap').find('.onboard-search-error'),
				body = $this.closest('.onboard-subsection-body'),
				items = body.find('.checkbox-box'),
				currentValues = [];

			errorElement.hide();
			body.find('.onboard-search-item').remove()
			if(term.length > 2) {
				body.find('.onboard-search-item').remove();
				items.hide();
				// Fill currentValues
				items.find('input').each(function() {
					if($(this).prop('checked')) {
						currentValues.push($(this).val())
					}
				});

				// Send AJAX
				$.ajax({
					url: drplusVars.ajaxUrl,
					type: 'POST',
					data: {
						action: 'drplus_search_onboard',
						text: term,
						nonce: $this.attr('data-nonce'),
						type: $this.attr('data-type'),
						current_values: JSON.stringify(currentValues),
					},
					success: function(res) {
						if( res.success ) {
							$(res.data).appendTo(body);
						} else {
							errorElement.text(res.data).show();
						}
					}
				});
			} else {
				body.find('.checkbox-box').show();
			}
		})

		$(document).on('change', '.onboard-search-item input', function() {
			$(this).parent().removeClass('onboard-search-item');
		})
	});
})(jQuery);