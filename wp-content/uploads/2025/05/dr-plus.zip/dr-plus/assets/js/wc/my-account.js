(function($) {
	$(document).ready(function(){
		$('.woocommerce-MyAccount-navigation-expand a').on('click', function(e) {
			e.preventDefault();
			$('.myaccount-sidebar-wrap').toggleClass('expanded');
			if( $('.myaccount-sidebar-wrap').hasClass('expanded') ) {
				$('.myaccount-sidebar-wrap').css('width', '240px');
			} else {
				$('.myaccount-sidebar-wrap').css('width', '');
			}
		});
		$('.myaccount-sidebar-mobile-expand').on('click', function() {
			$('.myaccount-sidebar-wrap').addClass('mobile-expanded');
			$('#drplus-overlay').fadeIn();
		});
		$('#drplus-overlay').on('click', function() {
			$('.myaccount-sidebar-wrap').removeClass('mobile-expanded');
			$('#drplus-overlay').fadeOut();
		});

		// Upload new avatar
		$('#drplus-edit-avatar').on('click', function(e) {
			e.preventDefault();
			let wrap = $(this).closest('.drplus-edit-avatar-wrap-row'),
				selectedFileInput = wrap.find('#account_avatar_id');
			var fileFrame = wp.media.frames.file_frame = wp.media({
				frame: 'select',
				editing : false,
				multiple : false,
				library: {
					type: 'image'
				},
				selection : ""
			});

			fileFrame.on('open', function() {
				var selection = fileFrame.state().get('selection');
				let attachment = wp.media.attachment( selectedFileInput.val() );
				selection.add( attachment ? [ attachment ] : []);
			});

			fileFrame.on('select', function() {
				var selection = fileFrame.state().get('selection').first();

				selectedFileInput.val(selection.attributes.id);
				// Show avatar
				wrap.find('.drplus-edit-avatar-wrap img').attr('src', selection.attributes.url).removeAttr('srcset');
			});

			fileFrame.open();
		});

		$('.drplus-delete-avatar-icon').on('click', function(e) {
			e.stopPropagation();
			$('#account_avatar_id').val('');
			$(this).siblings('img').attr('src', drplusVars.defaults.avatar).removeAttr('srcset');
		});

		$('.notification-head').on('click', function() {
			let notification = $(this).closest('.notification');
			if(notification.hasClass('notification-unread')) {
				$.ajax({
					url: drplusVars.ajaxUrl,
					type: 'POST',
					data: {
						action: 'drplus_set_notification_read',
						id: notification.attr('data-id')
					},
					success: function(res) {
						if(res.success) {
							if(res.data.unreadCount > 0) {
								$('.account-notif-count').text(res.data.unreadCount);
							} else {
								$('.account-notif-count-wrap').fadeIn({
									complete: function() {
										$(this).remove();
									}
								});
							}
						}
					}
				});
			}
			notification.removeClass('notification-unread');
			notification.find('.notification-text').slideToggle();
		})

		// Specialist profile
		$('.specialist_offline_visit').on('change', function() {
			let list = $(this).parent().siblings('.drplus-specialist-form-reserve-offices');
			if($(this).prop('checked')) {
				list.fadeIn({
					start: function() {
						$(this).css('display', 'grid')
					}
				});
			} else {
				list.fadeOut({
					start: function() {
						$(this).css('display', 'grid')
					}
				});
			}
		});
		// Times
		// Switch status
		$(document).on('change', '.drplus-specialist-form-time-status', function() {
			let row = $(this).closest('.drplus-specialist-form-time-row');
			if($(this).prop('checked')) {
				row.removeClass('inactive');
			} else {
				row.addClass('inactive');
			}
		})
		// Remove time
		let reservationPrefix = 'drplus-specialist-form-time-',
			defaultTimeLength = $(`.drplus-specialist-form-default-time-row`).length;
		$(document).on('click', `.${reservationPrefix}remove`, function() {
			// alert
			if( confirm(drplusMyAccount.i18n.confirmRemoveTime) ) {
				let type = $(this).data('type');
				if( type == 'custom' ) {
					dayIndex = $(this).closest(`.${reservationPrefix}day`).data('day-index');
				}

				let times = $(this).closest('.drplus-specialist-form-times');
				$(this).closest(`.${reservationPrefix}row`).fadeOut({
					duration: 300,
					complete: function() {
						$(this).remove();
						if(type == 'custom') {
							times.find(`.${reservationPrefix}row`).each(function( index, el ) {
								let newIndex = index + 1;
								$(el).find(`.${reservationPrefix}from`).attr('name', `specialist_days[${dayIndex}][times][${newIndex}][time_from]`);
								$(el).find(`.${reservationPrefix}to`).attr('name', `specialist_days[${dayIndex}][times][${newIndex}][time_to]`);
								$(el).find(`.${reservationPrefix}id`).attr('name', `specialist_days[${dayIndex}][times][${newIndex}][id]`);
								$(el).find(`.${reservationPrefix}index`).text(newIndex);
							});
						} else {
							times.find(`.${reservationPrefix}row`).each(function( index, el ) {
								let newIndex = index + 1;
								$(el).find(`.${reservationPrefix}from`).attr('name', `specialist_default_times[${newIndex}][from]`);
								$(el).find(`.${reservationPrefix}to`).attr('name', `specialist_default_times[${newIndex}][to]`);
								$(el).find(`.${reservationPrefix}status`).attr('name', `specialist_default_times[${newIndex}][status]`);
								$(el).find(`.${reservationPrefix}index`).text(newIndex);
								defaultTimeLength = $(`.drplus-specialist-form-default-time-row`).length;									
							})
						}
					}
				})
			}
		});
		// New time
		$(`.drplus-specialist-form-times-new`).on('click', function(e) {
			e.preventDefault();
			let type = $(this).attr('data-type'),
				html;
			if( type == 'default' ) {
				let template = wp.template(`specialist_default_time`);			
				defaultTimeLength++;
				html = template({
					index: defaultTimeLength
				});
			} else {
				let template = wp.template('specialist_custom_time'),
					timesLength = $(this).closest(`.drplus-specialist-form-day-times-wrap`).find(`.drplus-specialist-form-time-row`).length+1,
					dayIndex = $(this).closest(`.drplus-specialist-form-day`).data('day-index');
				html = template({
					index: timesLength,
					day_index: dayIndex,
				});
			}
			$(html).appendTo($(this).siblings('.drplus-specialist-form-times'));

			// Focus on time from input
			$(this).siblings(`.drplus-specialist-form-times`).find(`.${reservationPrefix}from`).last().focus();
		});
		// Custom times
		$('.drplus-specialist-form-day-status').on('change', function() {
			let dayWrap = $(this).closest('.drplus-specialist-form-day');
			if( $(this).prop('checked') ) {
				dayWrap.removeClass('inactive');
			} else {
				dayWrap.addClass('inactive');
			}
			dayWrap.find('.drplus-specialist-form-day-default').trigger('change')
		})
		$('.drplus-specialist-form-day-default').on('change', function() {
			let dayWrap = $(this).closest('.drplus-specialist-form-day'),
				timesWrap = dayWrap.find('.drplus-specialist-form-day-times-wrap');
			if($(this).prop('checked')) {
				timesWrap.hide();
			} else {
				timesWrap.show();
			}
		})
	});
})(jQuery);