<?php
namespace DrPlus;

use DrPlus\Utils\Booking;
use DrPlus\Utils\Options;
use DrPlus\Utils\SMS;

class Includes {
	public static function main( $is_admin ) {
		include( DRPLUS_DIR . "inc/DB.php" );
		include( DRPLUS_DIR . "inc/Libs/ir-cities.php" );

		include( DRPLUS_DIR . "inc/Utils/utils-sanitizers.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-validators.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-formatters.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-page.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-archive.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-product.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-ui.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-date.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-elementor.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-user.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-hospital.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-wc.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-wishlist.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-speciality.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-search.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-sms.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-onboard.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-auth.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-notifications.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-booking.php" );
		if( $is_admin ) {
			include( DRPLUS_DIR . "inc/Utils/utils-admin-ui.php" );
		}
		include( DRPLUS_DIR . "inc/Utils/utils-widgets.php" );

		// Specialists utils files
		include( DRPLUS_DIR . "inc/Utils/Specialists/utils-specialists.php" );
		include( DRPLUS_DIR . "inc/Utils/Specialists/utils-specialists-statics.php" );
		include( DRPLUS_DIR . "inc/Utils/Specialists/utils-specialist-specialities-rel.php" );
		include( DRPLUS_DIR . "inc/Utils/Specialists/utils-specialist-hospitals-rel.php" );
		include( DRPLUS_DIR . "inc/Utils/Specialists/utils-specialist-insurances-rel.php" );
		include( DRPLUS_DIR . "inc/Utils/Specialists/utils-specialist-cities-rel.php" );

		// Include classes
		include( DRPLUS_DIR . "inc/Classes/Specialist.php" );

		if( Booking::is_booking_active() ) {
			include( DRPLUS_DIR . "inc/SaveBookingProcess.php" );
		}

		self::post_types();

		if ( !isset( $redux_demo ) && file_exists( DRPLUS_DIR . '/Redux/Options.php' ) ) {
			include_once( DRPLUS_DIR . '/Redux/Options.php' );
		}

		if( wp_doing_ajax() ) {
			include( DRPLUS_DIR . "inc/AJAX.php" );
		} else {
			include( DRPLUS_DIR . "inc/PublicScripts.php" );
		}

		self::DB();

		if( $is_admin ) {
			self::meta_boxes();
			// include( DRPLUS_DIR . "Redux/Save.php" );

			include( DRPLUS_DIR . "inc/Backend/DashboardFont.php" );

			// Specialists
			if ( ! class_exists( 'WP_List_Table' ) ) {
				require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
			}
			include( DRPLUS_DIR . "inc/Backend/Specialists/specialists-settings.php" );
			include( DRPLUS_DIR . "inc/Backend/Specialists/class-specialists-list-table.php" );
			
			include( DRPLUS_DIR . "inc/Backend/WidgetsPage.php" );
		}

		include( DRPLUS_DIR . "inc/MenuItem.php" );

		self::sms();
	}

	public static function cronjobs() {
		include( DRPLUS_DIR . "inc/Cronjobs/CheckBookingStatuses.php" );
	}

	private static function DB() {
		$options = Options::get_options( [
			'wishlist'		=> true,
			'auth'			=> true,
		] );
		if( Utils::to_bool( $options['wishlist'] ) ) {
			include( DRPLUS_DIR . "inc/DB/Wishlist.php" );
		}
		if( Utils::to_bool( $options['auth'] ) ) {
			include( DRPLUS_DIR . "inc/DB/OTP.php" );
		}

		// Specialists DB files
		include( DRPLUS_DIR . "inc/DB/Specialists.php" );
		include( DRPLUS_DIR . "inc/DB/SpecialistsStatics.php" );
		include( DRPLUS_DIR . "inc/DB/SpecialistSpecialitiesRel.php" );
		include( DRPLUS_DIR . "inc/DB/SpecialistHospitalsRel.php" );
		include( DRPLUS_DIR . "inc/DB/SpecialistInsurancesRel.php" );
		include( DRPLUS_DIR . "inc/DB/SpecialistCitiesRel.php" );
		
		include( DRPLUS_DIR . "inc/DB/Times.php" );
		include( DRPLUS_DIR . "inc/DB/Booking.php" );
		include( DRPLUS_DIR . "inc/DB/NotificationsUserRel.php" );
	}

	private static function post_types() {
		include( DRPLUS_DIR . "inc/PostTypes/post-type-specialist.php" );
		include( DRPLUS_DIR . "inc/PostTypes/post-type-speciality.php" );
		include( DRPLUS_DIR . "inc/PostTypes/post-type-hospital.php" );
		include( DRPLUS_DIR . "inc/PostTypes/post-type-notification.php" );
	}

	private static function meta_boxes() {
		include( DRPLUS_DIR . "inc/Backend/Metaboxes/Page/Settings.php" );
		include( DRPLUS_DIR . "inc/Backend/Metaboxes/Hospital/Settings.php" );
		include( DRPLUS_DIR . "inc/Backend/Metaboxes/Speciality/Settings.php" );
		include( DRPLUS_DIR . "inc/Backend/Metaboxes/Notification/Users.php" );
		include( DRPLUS_DIR . "inc/Backend/Metaboxes/Product/Attribute.php" );
		include( DRPLUS_DIR . "inc/Backend/Metaboxes/Product/Subtitle.php" );
	}

	public static function wc( $is_admin ) {
		if( !Utils::is_wc_active() ) return;
		
		include( DRPLUS_DIR . "woocommerce/WC.php" );

		if( $is_admin ) {
			include( DRPLUS_DIR . "inc/Backend/WCAttributeFields.php" );
		}
	}

	public static function integrations( $is_admin ) {
		include( DRPLUS_DIR . "inc/Integrations/integrations-wp-rocket.php" );
	}

	public static function backend_pages() {
		$options = Options::get_options( [
			'sms'	=> true,
		] );
		if( Utils::to_bool( $options['sms'] ) ) {
			include( DRPLUS_DIR . "inc/Backend/Pages/SMS.php" );
		}
		include( DRPLUS_DIR . "inc/Backend/Comments.php" );
		include( DRPLUS_DIR . "inc/Backend/Functions.php" );
	}
	
	public static function components() {
		$components = [
			'alert',
			'button',
			'custom-select',
			'simple-icon',
			'select'	,
			'loading'	,
			'pro-icon'	,
			'section-title',
		];
		
		foreach( $components as $component ) {
			include( DRPLUS_DIR . "inc/Components/component-{$component}.php" );
		}
	}

	private static function sms() {
		include( DRPLUS_DIR . "inc/SMS/Gateway.php" );

		// Include gateway files automatically
		$gateways = SMS::gateways();
		foreach( $gateways as $gateway_name => $gateway ) {
			if( $gateway['is_service'] ) continue;
			$filename = Utils::convert_to_pascal_case( $gateway_name );
			include( DRPLUS_DIR . "inc/SMS/{$filename}.php" );
		}
		
		include( DRPLUS_DIR . "inc/SMS/SMS.php" );
	}
}
$is_admin = is_admin();
Includes::main( $is_admin );
Includes::wc( $is_admin );
Includes::integrations( $is_admin );
Includes::components();
Includes::cronjobs();
if( $is_admin ) {
	Includes::backend_pages();
}