<?php

use DrPlus\Utils;
use DrPlus\Utils\Formatters;
use DrPlus\Utils\Options;
use DrPlus\Utils\User;
use DrPlus\Utils\UtilsSpecialists;
use DrPlus\Utils\WC;

if( !function_exists( "drplus_wc_my_account_items" ) ) {
	function drplus_wc_my_account_items( $menu_links ) {
		$menu_links = array_merge( $menu_links, WC::my_account_custom_links() );

		$links_orders = [
			'dashboard',
			'orders',
			'appointments',
			'downloads',
			'specialist-dashboard',
			'notifications',
			'tickets',
			'edit-address',
			'wishlist',
			'edit-account',
			'customer-logout',
		];

		$options = Options::get_options( [
			'appointments'	=> true,
			'notifications'	=> true,
			'tickets'		=> true,
			'wishlist'		=> true,
		] );
		$unset = [];
		if( !Utils::to_bool( $options['appointments'] ) ) {
			$unset[] = 'appointments';
		}
		if( !Utils::to_bool( $options['notifications'] ) ) {
			$unset[] = 'notifications';
		}
		if( !Utils::to_bool( $options['tickets'] ) ) {
			$unset[] = 'tickets';
		}
		if( !Utils::to_bool( $options['wishlist'] ) ) {
			$unset[] = 'wishlist';
		}
		if( !empty( $unset ) ) {
			$links_orders = Utils::unset( $links_orders, $unset );
			$links_orders = array_values( $links_orders );
		}

		foreach( array_keys( $menu_links ) as $link ) {
			Utils::reposition_array_element( $menu_links, $link, array_search( $link, $links_orders ) );
		}

		return $menu_links;
	}
}
add_filter( 'woocommerce_account_menu_items', 'drplus_wc_my_account_items' );

if( !function_exists( "drplus_wc_my_account_links_endpoint" ) ) {
	function drplus_wc_my_account_links_endpoint() {
		foreach( array_keys( WC::my_account_custom_links() ) as $link ) {
			add_rewrite_endpoint( $link, EP_PAGES );
		}
	}
}
add_action( 'init', 'drplus_wc_my_account_links_endpoint' );

if( !function_exists( "drplus_wc_my_account_start" ) ) {
	function drplus_wc_my_account_start() {
		$endpoint = Utils::get_wc_account_endpoint();
		if( $endpoint != 'dashboard' ) {
			echo "<div class=\"drplus-myaccount-section drplus-myaccount-section-{$endpoint}\">";
		}
	}
}
add_action( 'woocommerce_account_content', 'drplus_wc_my_account_start', 7 );

if( !function_exists( "drplus_wc_my_account_end" ) ) {
	function drplus_wc_my_account_end() {
		$endpoint = Utils::get_wc_account_endpoint();
		if( $endpoint != 'dashboard' ) {
			echo '</div>';
		}
	}
}
add_action( 'woocommerce_account_content', 'drplus_wc_my_account_end', 999 );

if( !function_exists( "drplus_wc_my_account_redirect_guest" ) ) {
	function drplus_wc_my_account_redirect_guest() {
		$options = Options::get_options( [
			'auth'				=> true,
			'guest-login-url'	=> home_url( "?login=true" ),
		] );
		
		if( !Utils::to_bool( $options['auth'] ) ) return;

		if( is_account_page() ) {
			wp_redirect( $options['guest-login-url'] );
			die;
		}
	}
}
if( !is_user_logged_in() ) {
	add_action( 'template_redirect', 'drplus_wc_my_account_redirect_guest' );
}

if( !function_exists( "drplus_modify_my_account_my_orders_actions" ) ) {
	function drplus_modify_my_account_my_orders_actions( $actions ) {
		if( isset( $actions['view'] ) ) {
			$actions['view']['name'] = __( 'View', 'drplus' );
		}
		return $actions;
	}
}
add_filter( 'woocommerce_my_account_my_orders_actions', 'drplus_modify_my_account_my_orders_actions' );

if( !function_exists( "drplus_modify_woocommerce_my_account_edit_address_title" ) ) {
	function drplus_modify_woocommerce_my_account_edit_address_title( $title ) {
		return sprintf( __( 'Edit %s', 'drplus' ), $title );
	}
}
add_filter( 'woocommerce_my_account_edit_address_title', 'drplus_modify_woocommerce_my_account_edit_address_title' );

if( !function_exists( "drplus_edit_account_title" ) ) {
	function drplus_edit_account_title() {
		?>
		<h2 class="drplus-edit-account-title drplus-myaccount-page-title"><?php echo esc_html( __( 'Edit Account', 'drplus' ) ); ?></h2>
		<?php
	}
}
add_action( 'woocommerce_before_edit_account_form', 'drplus_edit_account_title' );

// Custom links functions
$custom_links = WC::my_account_custom_links();
if( !function_exists( "drplus_wc_my_account_appointments_content" ) && isset( $custom_links['appointments'] ) ) {
	function drplus_wc_my_account_appointments_content() {
		include( DRPLUS_DIR . "woocommerce/myaccount/custom-links/appointments.php" );
	}
}

if( !function_exists( "drplus_wc_my_account_notifications_content" ) && isset( $custom_links['notifications'] ) ) {
	function drplus_wc_my_account_notifications_content() {
		include( DRPLUS_DIR . "woocommerce/myaccount/custom-links/notifications.php" );
	}
}
if( !function_exists( "drplus_wc_my_account_tickets_content" ) && isset( $custom_links['tickets'] ) ) {
	function drplus_wc_my_account_tickets_content() {
		include( DRPLUS_DIR . "woocommerce/myaccount/custom-links/tickets.php" );
	}
}
if( !function_exists( "drplus_wc_my_account_wishlist_content" ) && isset( $custom_links['wishlist'] ) ) {
	function drplus_wc_my_account_wishlist_content() {
		include( DRPLUS_DIR . "woocommerce/myaccount/custom-links/wishlist.php" );
	}
}
if( !function_exists( "drplus_wc_my_account_specialist_dashboard_content" ) && isset( $custom_links['specialist-dashboard'] ) ) {
	function drplus_wc_my_account_specialist_dashboard_content() {
		include( DRPLUS_DIR . "woocommerce/myaccount/custom-links/specialist_dashboard.php" );
	}
}

foreach( array_keys( WC::my_account_custom_links() ) as $my_account_link ) {
	$function = $my_account_link;
	if( strpos( $function, "-" ) !== false ) {
		$function = str_replace( "-", "_", $function );
	}
	if( function_exists( "drplus_wc_my_account_{$function}_content" ) ) {
		add_action( "woocommerce_account_{$my_account_link}_endpoint", "drplus_wc_my_account_{$function}_content" );
	}
}

if( !function_exists( "drplus_wc_my_account_avatar" ) ) {
	function drplus_wc_my_account_avatar() {
		$user = wp_get_current_user();
		$user_custom_avatar = User::get_avatar_id( $user );
		?>
		<div class="woocommerce-form-row woocommerce-form-row--wide drplus-edit-avatar-wrap-row">
			<input type="hidden" name="drplus_account_avatar_id" id="account_avatar_id" value="<?php echo esc_attr( $user_custom_avatar ) ?>">
			<div class="drplus-edit-avatar-wrap" id="drplus-edit-avatar">
				<?php echo get_avatar( $user->ID, 96 ) ?>
				<i class="drplus-icon-edit drplus-edit-avatar-icon"></i>
				<?php if( !empty( $user_custom_avatar ) ) { ?>
					<i class="drplus-icon-trash drplus-delete-avatar-icon"></i>
				<?php } ?>
			</div>
		</div>
		<?php
	}
}
add_action( 'woocommerce_edit_account_form_start', 'drplus_wc_my_account_avatar' );

if( !function_exists( "drplus_wc_my_account_fields" ) ) {
	function drplus_wc_my_account_fields() {
		$user_id = get_current_user_id();
		$birthday = User::get_birthday( $user_id );
		$nid = User::get_nid( $user_id );
		$phone = User::get_phone( $user_id );
		?>
		<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
			<label for="drplus_birthday"><?php esc_html_e( 'Birthday', 'drplus' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label>
			<input
				type="text"
				class="woocommerce-Input input-text drplus-datepicker-input drplus-datepicker-input"
				id="drplus_birthday"
				data-time="<?php echo esc_attr( $birthday ) ?>"
				aria-required="true"
				readonly
				<?php echo UtilsSpecialists::is_user_specialist( $user_id ) ? 'data-options=\'' . wp_json_encode( ['maxDate' => strtotime( '-18 years' )*1000] ) . '\'' : '' ?>
			>
			<input type="hidden" name="drplus_birthday" id="drplus_birthday_alt" value="<?php echo esc_attr( $birthday ) ?>">
		</p>

		<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
			<label for="drplus_nid"><?php esc_html_e( 'National ID', 'drplus' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label>
			<input
				type="text"
				class="woocommerce-Input input-text drplus-nid-input drplus-numeric-input input-ltr"
				id="drplus_nid"
				name="drplus_nid"
				value="<?php echo esc_attr( $nid ) ?>"
				aria-required="true"
				inputmode="numeric"
				minlength="10"
				maxlength="10"
			>
		</p>

		<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
			<label for="drplus_mobile"><?php esc_html_e( 'Phone number', 'drplus' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label>
			<input
				type="text"
				class="woocommerce-Input input-text drplus-phone-input input-ltr"
				id="drplus_mobile"
				name="drplus_mobile"
				value="<?php echo esc_attr( Formatters::phone( $phone ) ) ?>"
				aria-required="true"
				autocomplete="tel"
				inputmode="tel"
				minlength="13"
				maxlength="13"
				placeholder="09..."
			>
		</p>
		<?php
	}
}
add_action( 'woocommerce_edit_account_form_fields', 'drplus_wc_my_account_fields' );

if( !function_exists( "drplus_wc_save_account_details" ) ) {
	function drplus_wc_save_account_details( $user_id ) {
		if( isset( $_POST['drplus_account_avatar_id'] ) ) {
			$avatar_id = Utils::convert_chars( $_POST['drplus_account_avatar_id'], true, 'absint' );
			User::save_avatar_id( $avatar_id, $user_id );
		}
	}
}
add_action( 'woocommerce_save_account_details', 'drplus_wc_save_account_details' );