<?php
namespace DrPlus;

abstract class DB {
	private $_columns = [
		'created_at'	=> 'DATETIME NOT NULL',
		'updated_at'	=> 'DATETIME NOT NULL',
		'deleted'		=> 'TINYINT(1) NOT NULL DEFAULT 0',
		'creator'		=> 'INT NOT NULL',
	];
	// Fill:
	public string $table;
	public string $key = 'id';
	public array $exclude_columns;

	// Fill:
	public array $columns;
	public array $defaults;

	public bool $include_deleted = false;

	public $data = [];
	private $update_data;

	/**
	 * Initializes the database
	 *
	 */
	public function __construct( int $id = 0 ) {
		global $wpdb;
		$this->table = $wpdb->prefix.$this->table;
		$this->table_creator();
		$id = absint( $id );
		if( $id ) {
			$this->get( $id );
		}
		return $this;
	}

	public function __get( $name ) {
		if( ( is_array( $this->data ) && isset( $this->data[$name] ) ) ) {
			return $this->data[$name];
		}
		if( property_exists( $this, $name ) ) {
			return $this->$name;
		}
		return null;
	}

	public function __set( $name, $value ) {
		if( isset( $this->columns[$name] ) ) {
			if( !isset( $this->data[$name] ) || $this->data[$name] != $value ) {
				$this->update_data[$name] = $value;
			}
			$this->data[$name] = $value;
		}
	}

	abstract public function sanitize( bool $update = false );

	public function set_columns( array $columns ) {
		$this->columns = $columns;
        return $this;
	}

	public function set_defaults( array $defaults ) {
		$this->defaults = $defaults;
        return $this;
	}

	public function get( int $id, array $columns = [] ) {
		global $wpdb;
		$columns = $this->get_cols( $columns );

		$where = [
			'AND'	=> [
				"`{$this->key}`=%d" => $id
			]
		];
		if( !in_array( 'deleted', $this->exclude_columns ) ) {
			if( !$this->include_deleted ) {
				$where['AND']['`deleted`=%d'] = 0;
			}
		}
		
		$query = self::query_creator( "SELECT {$columns} FROM `{$this->table}`", $where, ['LIMIT' => 1] );

		$this->data = $wpdb->get_row( $query, ARRAY_A );
		$this->sanitize();
		return $this;
	}

	public function find( array $where = [], array $columns = [], array $attrs = [] ) {
		global $wpdb;

		if( !in_array( 'deleted', $this->exclude_columns ) ) {
			if( !$this->include_deleted ) {
				$where['AND']['`deleted`=%d'] = 0;
			}
		}

		$columns = $this->get_cols( $columns );
		$query = "SELECT {$columns} FROM `{$this->table}`";
		$query = self::query_creator( $query, $where, $attrs );

		$this->data = $wpdb->get_results( $query, ARRAY_A );
		return $this;
	}

	public function get_cols( array $cols = [] ) {
		if( empty( $cols ) ) {
			$cols[] = "*";
		} else {
			$cols = array_map( function( $col ) {
				$table = '';
				if( strpos( $col, '.' ) ) {
					$col = explode( ".", $col );
					$table = $col[0];
					$col = $col[1];
				}
				$col = $table ? "`{$table}`.`{$col}`" : "`{$col}`";
				return str_replace( "``", "`", $col );
			}, $cols );
		}
		$cols = array_unique( $cols );
		$cols = implode( ", ", $cols );

		return $cols;
	}

	public function query_creator( string $query, array $where = [], array $attrs = [] ) {
		$values = [];
		if( !empty( $where ) ) {
			$relation = 'OR';
			if( !empty( $where['relation'] ) ) {
				$relation = $where['relation'];
				unset( $where['relation'] );
			}
			$query .= " WHERE " ;
			if( !empty( $where['AND'] ) || !empty( $where['OR'] ) ) {
				if( !empty( $where['AND'] ) ) {
					$values = array_merge( $values, array_values( $where['AND'] ) );
					$query .= implode( " AND ", array_keys( $where['AND'] ) );
				}

				if( !empty( $where['AND'] ) && !empty( $where['OR'] ) ) {
					$query .= " {$relation} ";
				}

				if( !empty( $where['OR'] ) ) {
					$values = array_merge( $values, array_values( $where['OR'] ) );
					$query .= "(" . implode( " OR ", array_keys( $where['OR'] ) ) . ")";
				}
			} else if( !empty( $where[0] ) && !empty( $where['values'] ) ) {
				$values = $where['values'];
				$query .= $where[0];
			} else {
				$values = array_values( $where );
				$query .= array_keys( $where )[0];
			}

			// Convert multidimensional arrays
			$values = Utils::array_flatten( $values );
		}
		$values = Utils::remove_empty_indexes( $values );

		if( !empty( $attrs ) ) {
			foreach( $attrs as $key => $value ) {
				$query .= " {$key} {$value}";
			}
		}

		if( !empty( $values ) ) {
			global $wpdb;
			return $wpdb->prepare( $query, $values );
		} else {
			return $query;
		}
	}

	public function to_array() {
		$this->data = Utils::obj_to_array( $this->data );
		return $this;
	}

	public function insert() {
		// Prevent to set primary key value
		$data = Utils::obj_to_array( $this->data );
		$data = Utils::unset( $data, array_merge( array_keys( $this->_columns, [$this->key] ) ) );
		$this->sanitize( true );

		$insert_data = [];
		$types = [];

		foreach( $this->defaults as $column => $default ) {
			if( isset( $data[$column] ) && is_null( $this->defaults[$column] ) ) continue;

			if( isset( $data[$column] ) ) {
				$insert_data[$column] = $data[$column];
			} else {
				$insert_data[$column] = $default;
			}

			if( is_numeric( $default ) ) {
				$types[] = is_float( $default ) ? '%f' : "%d";
			} else {
				if( $default === '0.00' ) {
					$types[] = "%f";
				} else {
					$types[] = "%s";
				}
			}
		}

		// Check excluded columns
		if( !in_array( 'created_at', $this->exclude_columns ) ) {
			$insert_data['created_at'] = date( 'Y-m-d H:i:s' );
			$types[] = "%s";
		}

		if( !in_array( 'updated_at', $this->exclude_columns ) ) {
			$insert_data['updated_at'] = !empty( $insert_data['created_at'] ) ? $insert_data['created_at'] : date( 'Y-m-d H:i:s' );
			$types[] = "%s";
		}

		if( !in_array( 'creator', $this->exclude_columns ) ) {
			$insert_data['creator'] = get_current_user_id();
			$types[] = "%d";
		}

		if( !in_array( 'deleted', $this->exclude_columns ) ) {
			$insert_data['deleted'] = 0;
			$types[] = "%d";
		}

		global $wpdb;
		$wpdb->insert( $this->table, $insert_data, $types );
		return $wpdb->insert_id;
	}

	public function new() {
		return $this->insert();
	}

	public function update( int $id = 0 ) {
		if( !empty( $this->update_data ) && ( $id > 0 || isset( $this->data[$this->key] ) ) ) {
			$this->sanitize( true );
			$this->update_data = Utils::unset( $this->update_data, array_merge( array_keys( $this->_columns, [$this->key] ) ) );
			
			global $wpdb;
			$wpdb->update( $this->table, $this->update_data, [
				$this->key => $id > 0 ? $id : $this->{$this->key}
			] );
		}
		return $this;
	}

	public function restore() {
		global $wpdb;
		if( !isset( $this->data[0] ) || !is_array( $this->data[0] ) ) {
			$this->data = [$this->data];
		}
		foreach( $this->data as $data ) {
			return $wpdb->update( $this->table, ['deleted' => 0], [
				$this->key => $data[$this->key]
			] );
		}
	}

	public function delete( bool $soft = true ) {
		if( in_array( 'deleted', $this->exclude_columns ) ) $soft = false;

		global $wpdb;
		if( !isset( $this->data[0] ) || !is_array( $this->data[0] ) ) {
			$this->data = [$this->data];
		}
		$_res = true;
		foreach( $this->data as $data ) {
			if( $soft ) {
				$res = $wpdb->update( $this->table, ['deleted' => 1], [
					$this->key => $data[$this->key]
				] );
			} else {
				$res = $wpdb->delete( $this->table, [
					$this->key => $data[$this->key]
				] );
			}
			if( !$res ) $_res = false;
		}
		return $_res;
	}

	public function count( array $where = [], array $attrs = [] ) {
		$attrs = Utils::unset( $attrs, ['LIMIT', 'OFFSET'] );

		$query = "SELECT COUNT(`{$this->key}`) as counts FROM `{$this->table}`";
		$query = $this->query_creator( $query, $where, $attrs );
		global $wpdb;
		return $wpdb->get_row( $query )->counts ?? 0;
	}

	private function table_creator() {
		global $wpdb;

		// Check if table already exists
		if( $wpdb->get_var( "SHOW TABLES LIKE '{$this->table}'" ) === $this->table ) {
			return $this;
		}

		$columns_list = array_merge( $this->columns, $this->_columns );
		if( !empty( $this->exclude_columns ) ) {
			$columns_list = Utils::unset( $columns_list, $this->exclude_columns );
		}
		$query = "CREATE TABLE `{$this->table}` (
";
		foreach( $columns_list as $name => $type ) {
			$query .= "`{$name}` {$type},
";
		}
		$query .= "PRIMARY KEY  (`{$this->key}`)
)
COLLATE {$wpdb->collate}";
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $query );
		return $this;
	}

	/**
	 * Create placeholder for use in DB query
	 *
	 * @param array|object $object
	 * @param string $type Accepts: %d, %s, %f
	 * @return string
	 */
	public static function placeholder( $object, $type ) {
		$object = Utils::obj_to_array( $object );
		return implode( ", ", array_fill( 0, count( $object ), $type ) );
	}

	public function query( $query, $prepare_args = [], $function = 'get_results' ) {
		global $wpdb;
		if( !empty( $prepare_args ) ) {
			$query = $wpdb->prepare( $query, $prepare_args );
		}
		return $wpdb->$function( $query );
	}
}