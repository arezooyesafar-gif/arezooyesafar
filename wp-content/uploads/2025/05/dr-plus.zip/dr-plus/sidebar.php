<?php
if( !defined( 'ABSPATH' ) ) exit;
?>
<div id="sidebar" class="sidebar sidebar-general col-md-3 col-sm-12">
	<div id="widget-area" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 'general' ); ?>
	</div>
</div>
<?php