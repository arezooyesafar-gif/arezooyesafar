<?php
namespace DrPlus\DB;

use DrPlus\Utils;
use DrPlus\DB as DB;

class SpecialistsStatics extends DB {
	public string $table = 'drplus_specialists_statics';
	public array $exclude_columns = ['creator', 'deleted'];

	public array $columns = [
		'id'			=> 'INT NOT NULL AUTO_INCREMENT',
		'user_id'		=> 'INT NOT NULL',
		'static_name'	=> 'VARCHAR(255) NOT NULL',
		'static_value'	=> 'LONGTEXT NOT NULL',
	];
	public array $defaults = [
		'user_id'		=> 0,
		'static_key'	=> '',
		'static_value'	=> '',
	];

	public function sanitize( bool $update = false ) {
		$this->user_id		= Utils::convert_chars( $this->user_id, 'sanitize_text_field', 'absint' );
		$this->static_key			= Utils::convert_chars( $this->static_key, 'sanitize_text_field' );
		if( !is_scalar( $this->static_value ) ) {
			if( !Utils::is_json( $this->static_value ) ) {
				$this->static_value = Utils::convert_chars( $this->static_value, 'sanitize_text_field' );
			}
		} else {
			$this->static_value = serialize( $this->static_value );
		}
	}
}
new SpecialistsStatics;