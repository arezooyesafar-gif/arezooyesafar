<?php
namespace DrPlus\Utils;

use DrPlus\Specialist;
use DrPlus\Utils;

class Search extends Utils {
	public static function get_post_types_object() {
		static $post_types = null;
		if( $post_types === null ) {
			$post_types = get_post_types( [
				'public'				=> true,
				'exclude_from_search'	=> false,
			], 'objects' );
		}
		return $post_types;
	}
	/**
	 * Use this function only when is_search is true
	 *
	 * @return array
	 */
	public static function get_categorized_results() : array {
		static $categorized_results = null;
		if( $categorized_results === null ) {
			$categorized_results = [];
			if( is_search() ) {
				$search_term = get_search_query();

				$options = Options::get_options( [
					'search_specialist'			=> true,
					'search_specialist_icon'	=> 'drplus-icon-stethoscope',
					'search_specialist_title'	=> __( 'Specialists', 'drplus' ),
				] );

				$total_specialists = 0;
				if( parent::to_bool( $options['search_specialist'] ) ) {
					$specialists_args = [
						'number'		=> 8,
						'count_total'	=> true,
						'fields'		=> 'all',
					];
					$specialists = UtilsSpecialists::search( $search_term, $specialists_args, 'query' );
					$total_specialists = $specialists->get_total();
				}

				if( have_posts() || $total_specialists ) {
					// Convert founded users to specialist
					if( $total_specialists ) {
						$categorized_results['specialist'] = [
							'icon'		=> $options['search_specialist_icon'],
							'label'		=> $options['search_specialist_title'],
							'count'		=> $total_specialists,
							'results'	=> [],
						];
						foreach( $specialists->get_results() as $user ) {
							$categorized_results['specialist']['results'][] = new Specialist( null, $user );
						}
					}

					$post_types = self::get_post_types_object();

					// Get posts(post_type: post) (The query is modified in function/archive.php)
					global $wp_query;
					while( have_posts() ) {
						the_post();

						if( empty( $categorized_results['post'] ) ) {
							$categorized_results['post'] = [
								'icon'		=> 'drplus-icon-diamond',
								'label'		=> $post_types['post']->labels->name,
								'count'		=> $wp_query->found_posts,
								'results'	=> [],
							];
						}
						$categorized_results['post']['results'][] = get_post();
					}

					// Get other post types posts
					$exclude_search_post_types = Options::get_options( [
						'exclude_post_types'	=> ['page', 'attachment', 'e-floating-buttons', 'speciality'],
					] )['exclude_post_types'];
					$default_section_icons = [
						'speciality'	=> 'drplus-icon-plus',
						'product'		=> 'drplus-icon-shopping-cart',
						'hospital'		=> 'drplus-icon-hospital-pin',
						'post'			=> 'drplus-icon-diamond',
					];
					foreach( $post_types as $post_type => $post_type_object ) {
						if( !isset( $categorized_results[$post_type] ) && !in_array( $post_type, $exclude_search_post_types ) ) {
							$post_type_options = Options::get_options( [
								"search_{$post_type}_icon"	=> $default_section_icons[$post_type] ?? 'drplus-icon-grid-fill',
							] );

							$categorized_results[$post_type] = [
								'icon'		=> $post_type_options["search_{$post_type}_icon"],
								'label'		=> $post_type_object->labels->name,
								'count'		=> 0,
								'results'	=> [],
							];
							$query = new \WP_Query( [
								'post_type'				=> $post_type,
								's'						=> $search_term,
								'posts_per_page'		=> 8,
								'ignore_sticky_posts'	=> true,
							] );
							$categorized_results[$post_type]['count'] = $query->found_posts;
							if( !$query->found_posts ) {
								unset( $categorized_results[$post_type] );
								continue;
							}
							while( $query->have_posts() ) {
								$query->the_post();
								$categorized_results[$post_type]['results'][] = get_post();
							}
							wp_reset_postdata();
						}
					}

					// Reposition founded items
					// First place for specialists
					if( !empty( $categorized_results['speciality'] ) ) {
						parent::reposition_array_element( $categorized_results, 'speciality', 1 ); // Move the specialities
					}
					if( !empty( $categorized_results['hospital'] ) ) {
						parent::reposition_array_element( $categorized_results, 'hospital', 2 ); // Move the hospitals
					}
					if( !empty( $categorized_results['product'] ) ) {
						parent::reposition_array_element( $categorized_results, 'product', 3 ); // Move the products
					}
					if( !empty( $categorized_results['post'] ) ) {
						parent::reposition_array_element( $categorized_results, 'post', 99 ); // Move the posts
					}
				}
			}
		}
		return $categorized_results;
	}

	/**
	 * Use this function only when is_search is true. Return the current post type
	 *
	 * @return string
	 */
	public static function get_post_type() : string {
		if( empty( $_GET['post_type'] ) && empty( $_GET['section'] ) ) {
			return '';
		} else {
			if( !empty( $_GET['post_type'] ) ) {
				$post_type = parent::convert_chars( $_GET['post_type'] );
			} else {
				$post_type = parent::convert_chars( $_GET['section'] );
			}
			return $post_type;
		}
	}

	public static function get_city_from_GET() {
		static $city = '';
		if( $city === '' ) {
			if( empty( $_GET['city'] ) || empty( parent::convert_chars( $_GET['city'] ) ) ) return $city;
			$cities = parent::get_cities( false );
			$city = parent::convert_chars( $_GET['city'] );
			$city = $city && in_array( $city, $cities ) ? $city : '';
		}
		return $city;
	}
}