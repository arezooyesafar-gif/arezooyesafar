<?php
namespace DrPlus\DB;

use DrPlus\DB as DB;
use DrPlus\Utils;
use DrPlus\Utils\Date;
use DrPlus\Utils\Sanitizers;

class OTP extends DB {
	public string $table = 'drplus_otp';
	public array $exclude_columns = ['updated_at', 'creator', 'deleted'];

	public array $columns = [
		'id'		=> 'INT NOT NULL AUTO_INCREMENT',
		'mobile'	=> 'VARCHAR(11) NOT NULL',
		'otp'		=> 'INT(4) NOT NULL',
		'expire'	=> 'DATETIME NOT NULL',
	];
	public array $defaults = [
		'mobile'	=> '',
		'otp'		=> 0,
		'expire'	=> '0000-00-00 00:00:00',
	];

	public function sanitize( bool $update = false ) {
		$this->mobile	= Sanitizers::phone( $this->mobile );
		$this->otp		= Sanitizers::otp( $this->otp );
		if( is_numeric( $this->expire ) ) {
			$this->expire = date_i18n( "Y-m-d H:i:s", $this->expire );
		}
		if( $update ) {
			$this->expire = Date::maybe_j2g( Utils::convert_chars( $this->expire ) );
		}
	}

	public function get_by_mobile( $mobile = '' ) {
		$find = (new self)->find( ['AND' => ['`mobile`=%s' => $mobile ?: $this->mobile]], [], [
			'LIMIT'	=> 1,
		] );
		return !empty( $find->data ) ? $find->data[0] : [];
	}

	public function new_or_update() {
		$find = $this->get_by_mobile();
		if( !empty( $this->id ) || !empty( $find['id'] ) ) { // Update
			$this->update( $find['id'] );
		} else { // New
			$this->data = $this->update_data;
			$this->insert();
		}
	}
}
new OTP;