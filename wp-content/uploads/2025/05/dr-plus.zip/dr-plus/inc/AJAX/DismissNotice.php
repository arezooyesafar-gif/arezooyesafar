<?php
namespace DrPlus\AJAX;

use DrPlus\AJAX;
use DrPlus\Utils;

class DismissNotice extends AJAX {
	public static function get_instance() {
		static $instance = null;
		if( $instance === null ) {
			$instance = new self;
		}
		return $instance;
	}

	public function __construct() {
		return $this;
	}
	public function dismiss() {
		$this->set_request_data();
		$id = Utils::convert_chars( $this->data['id'], true, 'absint' );
		$user_id = get_current_user_id();

		$ids = self::get_dismissed_messages( $user_id );
		if( !in_array( $id, $ids ) ) {
			$ids[] = $id;
		}
		update_user_meta( $user_id, 'dismissed_messages', $ids );
		die;
	}

	private static function get_dismissed_messages( $user_id = 0 ) {
		$user_id = Utils::convert_chars( $user_id, true, 'absint' );
		if( $user_id === 0 && is_user_logged_in() ) {
			$user_id = get_current_user_id();
		}

		$ids = get_user_meta( $user_id, 'dismissed_messages', true );
		if( empty( $ids ) || !is_array( $ids ) ) {
			$ids = [];
		}
		return $ids;
	}
}