<?php

use DrPlus\Components\Alert;
use DrPlus\Components\Button;
use DrPlus\Components\SectionTitle;
use DrPlus\Utils;
use DrPlus\Utils\Booking;
use DrPlus\Utils\Date;
use DrPlus\Utils\Options;
use DrPlus\Utils\User;

$options = Options::get_options( [
	'booking-info-section-title'	=> esc_html__( 'Completing the information', 'drplus' ),
	'booking-info-section-icon'		=> 'drplus-icon-personalcard-bold',
	'booking-info-section-text'		=> esc_html__( 'To book an appointment, please enter your personal information.', 'drplus' ),
] );

if( !Booking::check_booking_session( ['specialist_id', 'office', 'date', 'time'] ) ) return;

// Get current year
$current_year = Utils::convert_chars( date_i18n( 'Y' ), true, 'absint' );
$specialist = Booking::get_specialist();
if( !$specialist ) return;

$office_id = $_SESSION['booking']['office'];
$office = null;
foreach( $specialist->offices as $_office ) {
	if( $_office->id == $office_id ) {
		$office = $_office;
	}
}

if( empty( $office ) ) {
	Alert::view( [
		'type'	=> 'error',
		'icon'	=> 'drplus-icon-error',
		'text'	=> esc_html__( 'Something went wrong. please try again', 'drplus' ),
		'classes'	=> ['booking-alert']
	] );
	Button::view( [
		'text'		=> esc_html__( 'Back', 'drplus' ),
		'link'		=> Booking::get_booking_page_url(),
		'type'		=> 'bordered',
		'align' 	=> 'center',
	] );
}

// Get booking date and time
$date = $_SESSION['booking']['date'];
$time = $_SESSION['booking']['time'];
$week_name = Date::jdate( 'l', $date );
$date = Date::jdate( 'd F Y', $date );
$hour = date( "H", $time/1000 );
$time = date( "H:i", $time/1000 );

$time .= " " . Date::get_time_period( $hour );

// Get user info
$user = wp_get_current_user();
$user_birthday = Utils::convert_chars( User::get_birthday( $user->ID, 'Y' ), true, 'absint' );
$user_gender = User::get_gender( $user->ID );

$user_info = [
	'first_name'	=> !empty( $_SESSION['booking']['first_name'] ) ? $_SESSION['booking']['first_name'] : $user->first_name,
	'last_name'		=> !empty( $_SESSION['booking']['last_name'] ) ? $_SESSION['booking']['last_name'] : $user->last_name,
	'phone'			=> !empty( $_SESSION['booking']['phone'] ) ? $_SESSION['booking']['phone'] : User::get_phone( $user->ID ),
	'email'			=> !empty( $_SESSION['booking']['email'] ) ? $_SESSION['booking']['email'] : $user->user_email,
	'nid'			=> !empty( $_SESSION['booking']['nid'] ) ? $_SESSION['booking']['nid'] : User::get_nid( $user->ID ),
	'birthday'		=> !empty( $_SESSION['booking']['birthday'] ) ? $_SESSION['booking']['birthday'] : $user_birthday,
	'gender'		=> !empty( $_SESSION['booking']['gender'] ) ? $_SESSION['booking']['gender'] : $user_gender,
];

wp_localize_script( 'drplus-booking', 'drplusBooking', [
	'i18n'	=> [
		'wrongEmail'	=> __( 'Please enter a valid email', 'drplus' ),
		'wrongIDCode'	=> __( 'Please enter a valid National ID', 'drplus' ),
		'wrongMobile'	=> __( 'Please enter a valid mobile', 'drplus' ),
	]
] );

?>
<div class="booking-info-wrap booking-has-sidebar">
	<div class="booking-info booking-section">
		<?php SectionTitle::view( [
			'title'	=> $options['booking-info-section-title'],
			'icon'	=> $options['booking-info-section-icon']
		] ); ?>
		<span class="booking-info-text"><?php echo esc_html( $options['booking-info-section-text'] ) ?></span>
		<div class="booking-info-customer-data-wrap">
			<div class="booking-info-customer-field-wrap">
				<label for="booking-info-customer-first-name" class="booking-info-customer-field-label">
					<?php esc_html_e( 'First name', 'drplus' ) ?>
					<span class="required">*</span>
				</label>
				<input 
					type="text"
					id="booking-info-customer-first-name"
					placeholder="<?php esc_attr_e( 'First name', 'drplus' ) ?>" 
					name="booking_customer_first_name"
					class="booking-info-customer-field"
					value="<?php echo esc_attr( $user_info['first_name'] ) ?>"
					required

					autocapitalize="off"
					autocomplete="given-name"
					spellcheck="off"
				>
				<div class="drplus_form_field_error">
					<i class="drplus-icon-error"></i>
					<div class="drplus_form_field_error-text"></div>
				</div>
			</div>
			<div class="booking-info-customer-field-wrap">
				<label for="booking-info-customer-last-name" class="booking-info-customer-field-label">
					<?php esc_html_e( 'Last name', 'drplus' ) ?>
					<span class="required">*</span>
				</label>
				<input
					type="text"
					id="booking-info-customer-last-name"
					placeholder="<?php esc_attr_e( 'Last name', 'drplus' ) ?>"
					name="booking_customer_last_name"
					class="booking-info-customer-field"
					value="<?php echo esc_attr( $user_info['last_name'] ) ?>"
					required

					autocapitalize="off"
					autocomplete="family-name"
					spellcheck="off"
				>
				<div class="drplus_form_field_error">
					<i class="drplus-icon-error"></i>
					<div class="drplus_form_field_error-text"></div>
				</div>
			</div>
			<div class="booking-info-customer-field-wrap">
				<label for="booking-info-customer-phone" class="booking-info-customer-field-label">
					<?php esc_html_e( 'Phone', 'drplus' ) ?>
					<span class="required">*</span>
				</label>
				<input
					type="text"
					id="booking-info-customer-phone"
					placeholder="<?php esc_attr_e( 'Your phone number', 'drplus' ) ?>"
					name="booking_customer_phone"
					class="booking-info-customer-field drplus-phone-input input-ltr"
					value="<?php echo esc_attr( $user_info['phone'] ) ?>"
					required

					autocapitalize="off"
					autocomplete="tel"
					spellcheck="off"
					inputmode="tel"
				>
				<div class="drplus_form_field_error">
					<i class="drplus-icon-error"></i>
					<div class="drplus_form_field_error-text"></div>
				</div>
			</div>
			<div class="booking-info-customer-field-wrap">
				<label for="booking-info-customer-email" class="booking-info-customer-field-label">
					<?php esc_html_e( 'Email', 'drplus' ) ?>
				</label>
				<input
					type="email"
					id="booking-info-customer-email"
					placeholder="example@gmail.com"
					name="booking_customer_email"
					class="booking-info-customer-field input-ltr"
					value="<?php echo esc_attr( $user_info['email'] ) ?>"

					autocapitalize="off"
					autocomplete="email"
					spellcheck="off"
				>
				<div class="drplus_form_field_error">
					<i class="drplus-icon-error"></i>
					<div class="drplus_form_field_error-text"></div>
				</div>
			</div>
			<div class="booking-info-customer-field-wrap booking-info-customer-nid-field-wrap">
				<label for="booking-info-customer-nid" class="booking-info-customer-field-label">
					<?php esc_html_e( 'National ID', 'drplus' ) ?>
					<span class="required">*</span>
				</label>
				<input
					type="text"
					id="booking-info-customer-nid"
					placeholder="<?php esc_attr_e( 'Your national ID', 'drplus' ) ?>"
					name="booking_customer_nid"
					class="booking-info-customer-field input-ltr drplus-numeric-input"
					value="<?php echo esc_attr( $user_info['nid'] ) ?>"
					required

					autocapitalize="off"
					spellcheck="off"
					inputmode="numeric"
				>
				<div class="drplus_form_field_error">
					<i class="drplus-icon-error"></i>
					<div class="drplus_form_field_error-text"></div>
				</div>
				<label class="booking-info-customer-foreign-wrap">
					<input
						type="checkbox"
						name="booking_foreign_customer"
						id="booking-info-foreign-checkbox"
					>
					<span class="booking-info-customer-foreign-checkbox-text"><?php esc_html_e( 'I am a foreign national and do not have a national ID number.', 'drplus' ) ?></span>
				</label>
			</div>
			<div class="booking-info-customer-field-wrap">
				<label for="booking-info-customer-gender" class="booking-info-customer-field-label">
					<?php esc_html_e( 'Gender', 'drplus' ) ?>
					<span class="required">*</span>
				</label>
				<select
					name="booking_customer_gender"
					id="booking-info-customer-gender"
					class="booking-info-customer-field drplus-select2"
					data-width="100%"
					required
				>
					<option value="male" <?php echo selected( $user_info['gender'], 'male' ) ?>><?php esc_html_e( 'Male', 'drplus' ) ?></option>
					<option value="female" <?php echo selected( $user_info['gender'], 'female' ) ?>><?php esc_html_e( 'Female', 'drplus' ) ?></option>
				</select>
			</div>
			<div class="booking-info-customer-field-wrap">
				<label for="booking-info-customer-birthday" class="booking-info-customer-field-label">
					<?php esc_html_e( 'Year of birth', 'drplus' ) ?>
					<span class="required">*</span>
				</label>
				<select
					name="booking_customer_birthday"
					id="booking-info-customer-birthday"
					class="booking-info-customer-field drplus-select2"
					data-width="100%" 
					required
				>
					<?php for( $i = $current_year; $i > 1300 ;$i-- ) { ?>
						<option value="<?php echo $i ?>" <?php selected( $user_info['birthday'], $i ) ?>><?php echo $i ?></option>
					<?php } ?>
				</select>
			</div>
		</div>
		<?php get_template_part( 'templates/booking/template-booking', 'nav-btns', [
			'current_step'	=> 'info',
			'prev_step'		=> "time?sid={$specialist->ID}",
			'booking_url'	=> $args['booking_url']
		] ) ?>
	</div>
	<div class="booking-info-sidebar booking-section">
		<?php Booking::specialist_info_html( $specialist ) ?>
		<?php Booking::specialist_office_html( $office, true ) ?>
		<?php  ?>
		<div class="booking-info-time-wrap">
			<div class="booking-info-date-wrap">
				<span class="booking-info-week"><?php echo esc_html( $week_name ) ?></span>
				<span class="booking-info-date"><?php echo esc_html( $date ) ?></span>
			</div>
			<span class="booking-info-time"><?php echo esc_html( $time ) ?></span>
		</div>
	</div>
</div>