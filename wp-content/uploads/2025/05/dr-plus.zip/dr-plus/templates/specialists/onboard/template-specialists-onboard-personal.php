<?php

use DrPlus\Utils\Formatters;
use DrPlus\Utils\UI;

extract( $args );

if( !is_numeric( $specialist->birthday ) ) {
	$specialist->birthday = strtotime( $specialist->birthday );
}
if( function_exists( 'drplus_wc_my_account_avatar' ) ) {
	drplus_wc_my_account_avatar();
}
UI::input_with_label( [ // Firstname
	'label'			=> __( 'Firstname', 'drplus' ),
	'placeholder'	=> __( "Your firstname", 'drplus' ),
	'value'			=> $specialist->first_name,
	'id'			=> 'onboard-first_name-input',
	'name'			=> 'specialist_first_name',
	'minlength'		=> '1',
	'autofocus'		=> 'autofocus',
	'autocomplete'	=> 'given-name',
	'required'		=> 'required',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-first_name-group'],
	'input_classes'	=> ['onboard-input'],
] );

UI::input_with_label( [ // Lastname
	'label'			=> __( 'Lastname', 'drplus' ),
	'placeholder'	=> __( "Your lastname", 'drplus' ),
	'value'			=> $specialist->last_name,
	'id'			=> 'onboard-last_name-input',
	'name'			=> 'specialist_last_name',
	'minlength'		=> '1',
	'autocomplete'	=> 'family-name',
	'required'		=> 'required',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-last_name-group'],
	'input_classes'	=> ['onboard-input'],
] );

UI::input_with_label( [ // Subtitle
	'label'			=> __( 'Subtitle', 'drplus' ),
	'placeholder'	=> __( "Subtitle for your card in website", 'drplus' ),
	'value'			=> $specialist->subtitle,
	'id'			=> 'onboard-subtitle-input',
	'name'			=> 'specialist_subtitle',
	'minlength'		=> '1',
	'required'		=> 'required',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-subtitle-group'],
	'input_classes'	=> ['onboard-input'],
] );

UI::input_with_label( [ // Slug
	'label'			=> __( 'Slug', 'drplus' ),
	'placeholder'	=> trailingslashit( home_url() ) . "specialist/...",
	'value'			=> $specialist->slug,
	'id'			=> 'onboard-slug-input',
	'name'			=> 'specialist_slug',
	'minlength'		=> '1',
	'maxlength'		=> '255',
	'required'		=> 'required',
	'disabled'		=> !empty( $disable_slug ),
	
	'group_classes'	=> ['onboard-input-group', 'onboard-slug-group'],
	'input_classes'	=> ['onboard-input', 'input-ltr', 'drplus-slug-input'],
] );

UI::input_with_label( [ // Email
	'label'			=> __( 'Email', 'drplus' ),
	'placeholder'	=> __( "Your email address", 'drplus' ),
	'type'			=> 'email',
	'value'			=> $specialist->email,
	'id'			=> 'onboard-email-input',
	'name'			=> 'specialist_email',
	'minlength'		=> '1',
	'required'		=> 'required',
	'autocomplete'	=> 'email',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-email-group'],
	'input_classes'	=> ['onboard-input', 'input-ltr'],
] );

UI::input_with_label( [ // Birthday
	'label'			=> __( 'Birthday', 'drplus' ),
	'data-time'		=> !empty( $specialist->birthday ) ? $specialist->birthday : strtotime( '-18 years' ),
	'id'			=> 'onboard-birthday-input',
	'required'		=> 'required',
	'readonly'		=> 'readonly',
	'data-options'	=> [
		'maxDate'	=> strtotime( '-18 years' )*1000,
	],
	
	'group_classes'	=> ['onboard-input-group', 'onboard-birthday-group'],
	'input_classes'	=> ['onboard-input', 'drplus-datepicker-input'],

	'alt_field'		=> [
		'id'	=> "onboard-birthday-input_alt", // Don't remove _alt
		'name'	=> "specialist_birthday",
		'value'	=> $specialist->birthday
	],
] );

UI::input_with_label( [ // National ID
	'label'			=> __( 'National ID', 'drplus' ),
	'placeholder'	=> __( "Your National ID", 'drplus' ),
	'value'			=> $specialist->nid,
	'id'			=> 'onboard-nid-input',
	'name'			=> 'specialist_nid',
	'required'		=> 'required',
	'minlength'		=> 10,
	'maxlength'		=> 10,
	'inputmode'		=> 'numeric',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-nid-group'],
	'input_classes'	=> ['onboard-input', 'input-ltr', 'drplus-numeric-input', 'drplus-nid-input'],
] );

UI::input_with_label( [ // Medical ID
	'label'			=> __( 'Medical ID', 'drplus' ),
	'placeholder'	=> __( "Your Medical ID", 'drplus' ),
	'value'			=> $specialist->specialist_code,
	'id'			=> 'onboard-specialist_code-input',
	'name'			=> 'specialist_specialist_code',
	'required'		=> 'required',
	'minlength'		=> 1,
	'inputmode'		=> 'numeric',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-specialist_code-group'],
	'input_classes'	=> ['onboard-input', 'input-ltr', 'drplus-numeric-input'],
] );

UI::input_with_label( [ // Phone number
	'label'			=> __( 'Phone number', 'drplus' ),
	'placeholder'	=> "09...",
	'value'			=> Formatters::phone( $specialist->mobile ),
	'id'			=> 'onboard-mobile-input',
	'name'			=> 'specialist_mobile',
	'required'		=> 'required',
	'minlength'		=> 13,
	'maxlength'		=> 13,
	'inputmode'		=> 'tel',
	'autocomplete'	=> 'tel',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-mobile-group'],
	'input_classes'	=> ['onboard-input', 'input-ltr', 'drplus-phone-input'],
] );

UI::select_with_label( [ // Gender
	'label'			=> __( 'Gender', 'drplus' ),
	'value'			=> $specialist->gender,
	'id'			=> 'onboard-gender-input',
	'name'			=> 'specialist_gender',
	'required'		=> 'required',
	'data-width'	=> '100%',
	'options'			=> [
		'male'		=> __( 'Male', 'drplus' ),
		'female'	=> __( 'Female', 'drplus' ),
	],
	
	'group_classes'		=> ['onboard-input-group', 'onboard-gender-group'],
	'select_classes'	=> ['onboard-input', 'drplus-select2'],
] );

UI::input_with_label( [ // Biography
	'label'			=> __( 'Biography', 'drplus' ),
	'placeholder'	=> __( "A few brief lines about yourself...", 'drplus' ),
	'value'			=> $specialist->about,
	'id'			=> 'onboard-about-input',
	'name'			=> 'specialist_about',
	
	'group_classes'	=> ['onboard-input-group', 'onboard-about-group'],
	'input_classes'	=> ['onboard-input'],

	'textarea'	=> true,
] );