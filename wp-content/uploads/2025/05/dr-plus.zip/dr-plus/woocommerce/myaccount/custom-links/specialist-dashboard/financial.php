<?php

use DrPlus\Utils\Formatters;
use DrPlus\Utils\UI;

if( !defined( 'ABSPATH' ) ) exit;
?>
<div class="drplus-specialist-form-body drplus-specialist-form-financial">
	<?php
	UI::input_with_label( [
		'label'			=> esc_html__( 'Card number', 'drplus' ),
		'type'			=> 'text',
		'value'			=> Formatters::card_number( $specialist->card_number ),
		'id'			=> "specialist_card_number",
		'name'			=> "specialist_meta[card_number]",
		'input_classes'	=> ['input-ltr', 'drplus-card-number-input'],
		'inputmode'		=> 'numeric',
		'minlength'		=> 19,
		'maxlength'		=> 19,
		'required'		=> 'required',
	] );

	UI::input_with_label( [
		'label'			=> esc_html__( 'SHABA number', 'drplus' ),
		'type'			=> 'text',
		'value'			=> Formatters::shaba_number( $specialist->shaba_number ),
		'id'			=> "specialist_shaba_number",
		'name'			=> "specialist_meta[shaba_number]",
		'input_classes'	=> ['input-ltr', 'drplus-shaba-number-input'],
		'inputmode'		=> 'numeric',
		'minlength'		=> 32,
		'maxlength'		=> 32,
		'placeholder'	=> 'IR...',
		'required'		=> 'required',
	] );
	?>
</div>