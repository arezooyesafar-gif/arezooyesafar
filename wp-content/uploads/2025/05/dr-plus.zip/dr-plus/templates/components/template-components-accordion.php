<?php

use DrPlus\Utils;
use DrPlus\Utils\Elementor;
use DrPlus\Utils\Sanitizers;

if( !defined( 'ABSPATH' ) ) exit;

$args = Utils::check_default( $args, [
	'items'			=> [],
	'open_icon'		=> 'drplus-icon-bottom',
	'close_icon'	=> 'drplus-icon-top',
	'title_tag'		=> 'div',
	'faq_schema'	=> false,
] );

$default_item_args = [
	'title'	=> '',
	'text'	=> '',
];
$items = [];
foreach( $args['items'] as $item ) {
	$item = Utils::check_default( $item, $default_item_args );
	$items[] = [
		'title'	=> wp_kses_post( $item['title'] ),
		'text'	=> wp_kses_post( $item['text'] ),
	];
}

$open_icon = Sanitizers::icon( $args['open_icon'], 'accordion-item-icon-open' );
$close_icon = Sanitizers::icon( $args['close_icon'], 'accordion-item-icon-close' );
$title_tag = Sanitizers::tag( $args['title_tag'] );

$default_item = 0;
?>
<div class="accordion-items">
	<?php foreach ( $items as $index => $item ) { 
		$is_active = $default_item === $index;
		$item_id = 'accordion-item-' . $index;
		$panel_id = $item_id . '-panel';
	?>
		<div class="accordion-item<?php echo $is_active ? ' accordion-item-default accordion-item-active' : '' ?>">
			<div class="accordion-item-head">
				<<?php echo tag_escape( $title_tag ) ?>
					class="accordion-item-title" aria-expanded="<?php echo $is_active ? 'true' : 'false' ?>"
					aria-controls="<?php echo esc_attr( $panel_id ) ?>"
					role="button"
				>
					<?php echo $item['title'] ?>
				</<?php echo tag_escape( $title_tag ) ?>>

				<div class="accordion-item-icon">
					<?php echo $open_icon ?>
					<?php echo $close_icon ?>
				</div>
			</div>

			<div
				id="<?php echo esc_attr( $panel_id ) ?>"
				class="accordion-item-content"
				role="region"
				aria-labelledby="<?php echo esc_attr( $item_id ) ?>"
				<?php echo $is_active ? '' : 'hidden' ?>
			>
				<?php echo Elementor::parse_text_editor( $item['text'] ) ?>
			</div>
		</div>
	<?php } ?>
	
	<?php
	if( $args['faq_schema'] ) {
		$json = [
			'@context' => 'https://schema.org',
			'@type' => 'FAQPage',
			'mainEntity' => [],
		];

		foreach( $items as $item ) {
			$json['mainEntity'][] = [
				'@type' => 'Question',
				'name' => wp_strip_all_tags( $item['title'] ),
				'acceptedAnswer' => [
					'@type' => 'Answer',
					'text' => Elementor::parse_text_editor( $item['text'] ),
				],
			];
		}
		?>
		<script type="application/ld+json"><?php echo wp_json_encode( $json ); ?></script>
	<?php } ?>	
</div>