<?php
namespace DrPlus\PostTypes;

if( !defined( 'ABSPATH' ) ) exit;

class Specialist {
	PRIVATE STATIC $POST_TYPE_NAME = 'specialist'; // Singular word

	public static function register() {
		$labels = [
			'name'					=> __( 'Specialists', 'drplus' ),
			'singular_name'			=> __( 'Specialist', 'drplus' ),
			'menu_name'				=> __( 'Specialists', 'drplus' ),
			'name_admin_bar'		=> __( 'Specialists', 'drplus' ),
			'add_new'				=> __( 'Add New specialist', 'drplus' ),
			'add_new_item'			=> __( 'Add New specialist', 'drplus' ),
			'new_item'				=> __( 'New specialist', 'drplus' ),
			'edit_item'				=> __( 'Edit specialist', 'drplus' ),
			'view_item'				=> __( 'View specialist', 'drplus' ),
			'view_items'			=> __( 'View specialists', 'drplus' ),
			'all_items'				=> __( 'All specialists', 'drplus' ),
			'search_items'			=> __( 'Search specialists', 'drplus' ),
			'not_found'				=> __( 'No specialist found', 'drplus' ),
			'not_found_in_trash'	=> __( 'No specialist found', 'drplus' ),
		];
		$args = [
			'labels'				=> $labels,
			'public'				=> DRPLUS_DEV,
			'show_ui'				=> DRPLUS_DEV,
			'show_in_menu'			=> DRPLUS_DEV,
			'show_in_nav_menus'		=> false,
			'show_in_admin_bar'		=> false,
			'show_in_rest'			=> false,
			'exclude_from_search'	=> true,
			'publicly_queryable'	=> true,
			'menu_icon'				=> 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( DRPLUS_DIR . 'assets/images/hospital-icon.svg' ) ),
			'capability_type'		=> 'post',
			'has_archive'			=> 'specialists',
			'hierarchical'			=> false,
			'supports'				=> ['title', 'comments'],
			'rewrite'				=> [
				'slug'	=> 'specialist'
			]
		];
		register_post_type( 'specialist', $args );
	}
}
Specialist::register();