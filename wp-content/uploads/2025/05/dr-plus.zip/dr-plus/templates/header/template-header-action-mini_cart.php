<?php

use DrPlus\Utils;

if( !defined( 'ABSPATH' ) ) exit;

$args = Utils::check_default( $args, [
	'call_mode'				=> 'template', // template | elementor
	'empty-mini-cart-text'	=> esc_html__( 'The cart is empty.', 'drplus' ),
	'cart-text'				=> '',
	'cart-icon'				=> 'drplus-icon-shopping-cart',
	'icon-align'			=> 'start',
	'show-mini-cart'		=> true,
	'show-cart-count'		=> true,
	'mobile_mode'			=> false,
	'minicart_align'		=> 'p-start'
] );

$cart_count = Utils::get_cart_count();

$wrap_classes = ['header-cart-wrap', 'header-action', 'header-action-cart'];
if( $args['call_mode'] == 'template' ) {
	if( $args['mobile_mode'] ) {
		$wrap_classes = array_merge( $wrap_classes, ['hide-desktop', 'hide-tablet'] );
	} else {
		$wrap_classes[] = 'hide-mobile';
	}
}
if( $args['mobile_mode'] ) $wrap_classes[] = 'mobile-mode';
?>
<div class="<?php echo Utils::prepare_html_classes( $wrap_classes ) ?>">
	<a href="<?php echo wc_get_cart_url() ?>" class="header-action-btn header-cart-btn">
		<?php if( Utils::to_bool( $args['show-cart-count'] ) ) { ?>
			<div class="header-cart-count-wrap">
				<span class="cart-count"><?php echo $cart_count === 0 ? "" : $cart_count ?></span>
			</div>
		<?php } ?>
		<?php
		if( $args['cart-icon'] && $args['icon-align'] == 'start' ) {
			echo $args['cart-icon'];
		}
		if( $args['cart-text'] ) {
			?>
			<span class="header-mini-cart-text">
				<?php echo $args['cart-text']; ?>
			</span> <?php
		}
		if( $args['cart-icon'] && $args['icon-align'] == 'end' ) {
			echo $args['cart-icon'];
		}
		?>
	</a>
	
	<?php if( Utils::to_bool( $args['show-mini-cart'] ) ) { ?>
		<div class="header-mini-cart-wrap header-popover <?php echo $args['minicart_align'] ?>">
			<div class="header-mini-cart-content">
				<?php woocommerce_mini_cart( [
					'empty_mini_cart_text'	=> $args['empty-mini-cart-text']
				] ) ?>
			</div>
		</div>
	<?php } ?>
</div>