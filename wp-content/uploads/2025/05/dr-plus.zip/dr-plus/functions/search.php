<?php

use DrPlus\Utils\Search;

if( !function_exists( 'drplus_exclude_search_post_types' ) ) {
	function drplus_exclude_search_post_types( $query ) {
		if( is_admin() && !wp_doing_ajax() ) return;
		if( empty( $GLOBALS['drplus'] ) ) return;

		$options = $GLOBALS['drplus'];
		if( ( $query->is_main_query() && $query->is_search() ) ) {
			$post_types = get_post_types( ['exclude_from_search' => false] );
			$excludes = !empty( $options['exclude_post_types'] ) ? $options['exclude_post_types'] : [];
			$post_types = array_diff( array_keys( $post_types ), $excludes );
			$post_types = array_values( $post_types );
			$query->set( 'post_type', $post_types );
		}
	}
}
add_action( 'pre_get_posts', 'drplus_exclude_search_post_types' );

if( !function_exists( "drplus_modify_search_query" ) ) {
	function drplus_modify_search_query( $query ) {
		if( is_admin() || !$query->is_search() || !$query->is_main_query() ) return;

		$post_type = Search::get_post_type();

		if( $post_type ) {
			$query->set( 'post_type', 'post' );
			$query->set( 'posts_per_page', get_option( 'posts_per_page' ) );
			$query->set( 'ignore_sticky_posts', true );
			$query->set( 'nopaging', false );
		} else {
			if ( $post_type == 'specialist' ) {
				$query->set( 'post__in', [0] ); // This will return no results
				$query->set( 'ignore_sticky_posts', true );
				$query->set( 'nopaging', true );
			} else {
				$query->set( 'post_type', $post_type );
			}
		}
	}
}
add_action( 'pre_get_posts', 'drplus_modify_search_query' );