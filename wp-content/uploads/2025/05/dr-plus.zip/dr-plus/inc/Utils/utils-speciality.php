<?php
namespace DrPlus\Utils;

use DrPlus\Utils;

class Speciality extends Utils {
	private static $options = [];
	private static $count_specialists = [];

	public static function default_options() {
		return [
			'icon'	=> '',
		];
	}

	public static function get_options( $post_id = 0, array $options = [] ) {
		$post_id = parent::get_post_id( $post_id );

		// Because of the self caching maybe some options doesn't get it will cause issue
		$options = [];

		if( empty( self::$options[$post_id] ) ) {
			self::$options[$post_id] = parent::get_post_options( self::default_options(), $post_id, $options );
		}
		return self::$options[$post_id];
	}

	public static function save_options( array $options, $post_id = 0 ) {
		parent::save_post_options( $options, self::default_options(), $post_id );
	}

	public static function count_specialists( $post_id = 0 ) : int {
		$post_id = parent::get_post_id( $post_id );
		if( empty( self::$count_specialists[$post_id] ) ) {
			self::$count_specialists[$post_id] = (new SpecialistSpecialitiesRel)->count( true, [
				'AND'	=> [
					'`speciality_id`=%d'	=> $post_id,
				]
			] );
		}
		return self::$count_specialists[$post_id];
	}

	public static function get_archive_link( $post = 0 ) : string {
		$post = parent::get_post( $post );
		return '#';
	}

	public static function all( array $args = [] ) : array {
		$args = parent::check_default( $args, [
			'numberposts'			=> -1,
			'ignore_sticky_posts'	=> true,
		]);
		$args['post_type'] = 'speciality';

		if( $args['numberposts'] === -1 ) {
			$args['nopaging'] = true;
		}

		return get_posts( $args );
	}

	public static function get_specialities_from_GET() : array {
		$specialities = !empty( $_GET['specialities'] ) ? $_GET['specialities'] : [];
		if( empty( $specialities ) ) return [];
		$specialities = is_array( $specialities ) ? $specialities : [$specialities];
		$specialities = array_filter( array_map( fn( $speciality ) => Utils::convert_chars( $speciality, true, 'absint' ), $specialities ) );
		return $specialities;
	}
}