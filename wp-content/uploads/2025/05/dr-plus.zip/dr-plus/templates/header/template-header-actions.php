<?php

use DrPlus\Components\Button;
use DrPlus\Utils;
use DrPlus\Utils\Notifications;
use DrPlus\Utils\Options;
use DrPlus\Utils\Sanitizers;
use DrPlus\Utils\User;

if( !defined( 'ABSPATH' ) ) exit;

$args = Utils::check_default( $args, [
	'mobile_mode'	=> false
]);

$home_url = home_url();

$options = Options::get_options( [
	'empty-mini-cart-text'	=> esc_html__( 'The cart is empty.', 'drplus' ),
	'show-cart'				=> true,
	'cart-icon'				=> 'drplus-icon-shopping-cart',
	'show-mini-cart'		=> true,
	'show-cart-count'		=> true,
	
	'show-account-btn'			=> true,

	'show-header-action-btn'		=> true,
	'header-action-btn-text'		=> esc_html__( 'Request appointment', 'drplus' ),
	'header-action-btn-icon'		=> is_rtl() ? 'drplus-icon-arrow-up-left-square' : "drplus-icon-arrow-up-right-square",
	'header-action-btn-link'		=> home_url( 'booking' ),
	'header-action-btn-link-guest'	=> home_url( "?login=true" ),
	'header-action-btn-link-newtab'	=> false,

] );

if( Utils::to_bool( $options['show-cart'] ) && Utils::is_wc_active() ) {
	get_template_part( "templates/header/template-header-action", 'mini_cart', [
		'empty-mini-cart-text'	=> $options['empty-mini-cart-text'],
		'cart-icon'				=> Sanitizers::icon( $options['cart-icon'], 'header-action-icon header-cart-icon' ),
		'show-mini-cart'		=> $options['show-mini-cart'],
		'mobile_mode'			=> $args['mobile_mode'],
		'minicart_align'		=> 'p-end'
	] );
}
if( Utils::to_bool( $options['show-account-btn'] ) ) {
	get_template_part( "templates/header/template-header-action", 'account_btn', [
		'call_mode'		=> 'template',
		'mobile_mode' 	=> $args['mobile_mode'],
	] );
}
if( !$args['mobile_mode'] ) {
	$action_btn_args = [
		'type'			=> 'primary',
		'text'			=> $options['header-action-btn-text'],
		'icon'			=> $options['header-action-btn-icon'],
		'icon_align'	=> 'end',
		'align'			=> 'end',
		'link'			=> is_user_logged_in() ? $options['header-action-btn-link'] : $options['header-action-btn-link-guest'],
		'new_tab'		=> $options['header-action-btn-link-newtab'],
		'classes'		=> ['header-action', 'header-header-action-btn'],
	];
	if( $action_btn_args['new_tab'] ) {
		$account_btn_args['atts'] = [
			'rel'	=> 'noopener noreferrer'
		];
	}
	Button::view( $action_btn_args );
}
?>