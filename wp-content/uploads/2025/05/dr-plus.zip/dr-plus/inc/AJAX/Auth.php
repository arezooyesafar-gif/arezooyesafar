<?php
namespace DrPlus\AJAX;

use DrPlus\AJAX;
use DrPlus\DB\OTP;
use DrPlus\SMS\SMS;
use DrPlus\Utils;
use DrPlus\Utils\Options;
use DrPlus\Utils\Sanitizers;
use DrPlus\Utils\SMS as UtilsSMS;
use DrPlus\Utils\User;

class Auth extends AJAX {
	public static function get_instance() {
		static $instance = null;
		if( $instance === null ) {
			$instance = new self;
		}
		return $instance;
	}

	public function __construct() {
		return $this;
	}

	private function find_user_with_everything( $entry ) {
		$user = get_user_by( 'email', $entry );
		if( !$user ) {
			$user = get_user_by( 'login', $entry );
			if( !$user ) {
				$user = User::find_user_by_mobile( $entry );
				if( $user ) {
					$user = get_user_by( 'ID', $user );
				}
			}
		}
		return $user;
	}

	private function create_user( $username, $password = '', $email = '', $mobile = '' ) {
		$mobile = Sanitizers::phone( $mobile );

		$user = get_user_by( 'login', $username );
		if( !$user ) {
			$user = get_user_by( 'email', $email );
			if( !$user ) {
				$user = User::find_user_by_mobile( $mobile );
				if( $user ) {
					return new \WP_Error( 'mobile_exists', __( "This mobile is already exists.", 'drplus' ) );
				}
			} else {
				return new \WP_Error( 'email_exists', __( "This email is already exists.", 'drplus' ) );
			}
		} else {
			return new \WP_Error( 'username_exists', __( "This username is already exists.", 'drplus' ) );
		}

		return wp_insert_user( [
			'user_login'	=> Utils::convert_chars( $username, true, 'sanitize_user' ),
			'user_pass'		=> sanitize_text_field( $password ? $password : wp_generate_password() ),
			'user_email'	=> $email ? Utils::convert_chars( $email, 'sanitize_email' ) : "",
			'meta_input'	=> [
				'mobile'			=> $mobile,
				'billing_phone'		=> $mobile,
				'shipping_phone'	=> $mobile,
			]
		] );
	}

	public function login( $args = [] ) {
		if( empty( $args ) ) {
			$this->set_request_data();
		} else {
			$this->data = $args;
		}

		$username = Utils::convert_chars( $this->data['username'], true, 'sanitize_user' );
		$password = sanitize_text_field( $this->data['password'] );
		$user = $this->find_user_with_everything( $username );
		if( !$user ) {
			$this->result( 'error', [
				'code'		=> 'user_not_found',
				'message'	=> esc_html__( 'User not found.', 'drplus' ),
			] );
		}
		if( is_wp_error( $user ) ) {
			$this->result( 'error', [
				'code'		=> array_keys( $user->errors )[0],
				'message'	=> $user->get_error_message(),
			] );
		}
		if( !wp_check_password( $password, $user->data->user_pass, $user->ID ) ) {
			$this->result( 'error', [
				'code'		=> 'wrong_password',
				'message'	=> esc_html__( 'Password is not correct.', 'drplus' ),
			] );
		}

		$login = wp_signon( [
			'user_login'	=> $username,
			'user_password'	=> sanitize_text_field( $this->data['password'] ),
			'remember'		=> Utils::to_bool( $this->data['remember'] )
		] );
		if( is_wp_error( $login ) ) {
			$this->result( 'error', [
				'code'		=> array_keys( $login->errors )[0],
				'message'	=> $login->get_error_message(),
			] );
		} else {
			$this->result( 'success', [
				'code'		=> 'login_success',
				'message'	=> esc_html__( 'Login successful. The page will reload.', 'drplus' ),
			] );
		}
	}

	public function signup() {
		$this->set_request_data();

		if( !empty( $this->data['mobile'] ) && $this->find_user_with_everything( $this->data['mobile'] ) ) {
			$this->result( 'error', [
				'code'	=> 'user_exists',
				'msg'	=> esc_html__( 'User already exists', 'drplus' ),
			] );
		}

		$user_id = $this->create_user( $this->data['username'], $this->data['password'], $this->data['email'], $this->data['mobile'] ?? '' );
		if( is_wp_error( $user_id ) ) {
			$this->result( 'error', [
				'code'		=> array_keys( $user_id->errors )[0],
				'message'	=> $user_id->get_error_message(),
			] );
		} else {
			$this->login( [
				'username'	=> $this->data['username'],
				'password'	=> $this->data['password'],
				'remember'	=> true
			] );
			$this->result( 'success', [
				'code'		=> 'user_created',
				'message'	=> esc_html__( 'Your account has been created. The page will reload.', 'drplus' ),
			] );
		}
	}

	public function send_otp() {
		$this->set_request_data();

		$options = Options::get_options( [
			'sms'	=> true,
		] );
		if( !Utils::to_bool( $options['sms'] ) ) {
			$this->result( 'error', [
				'code'		=> 'sms_not_active',
				'message'	=> esc_html__( 'SMS is not active.', 'drplus' ),
			] );
		}

		$sms_settings = UtilsSMS::get_settings();

		$mobile = Sanitizers::phone( $this->data['mobile'] );
		$user = User::find_user_by_mobile( $mobile );
		if( $user ) { // Login
			if( empty( $sms_settings['settings']['auth']['login']['enabled'] ) ) {
				$this->result( 'error', [
					'code'		=> 'login_not_active',
					'message'	=> esc_html__( 'Login via SMS is not active.', 'drplus' ),
				] );
			}
			$send = SMS::send( $mobile, 'auth.login' );
		} else { // Register
			if( empty( $sms_settings['settings']['auth']['register']['enabled'] ) ) {
				$this->result( 'error', [
					'code'		=> 'register_not_active',
					'message'	=> esc_html__( 'Register via SMS is not active.', 'drplus' ),
				] );
			}
			$send = SMS::send( $mobile, 'auth.register' );
		}

		if( !$send ) {
			$this->result( 'error', [
				'code'		=> 'send_failed',
				'message'	=> esc_html__( 'Error sending SMS', 'drplus' ),
			] );
		}
		if( is_wp_error( $send ) ) {
			$this->result( 'error', [
				'code'		=> array_key_first( $send->errors ),
				'message'	=> $send->get_error_message(),
			] );
		}

		$this->result( 'success', [
			'code'		=> 'otp_sent',
			'message'	=> esc_html__( 'The verification code has been sent to your mobile number.', 'drplus' ),
			'mode'	=> $user ? 'login' : 'register',
		] );
	}

	public function check_otp() {
		$this->set_request_data();

		$mobile = Sanitizers::phone( $this->data['mobile'] );
		$otp = Sanitizers::otp( $this->data['otp'] );

		$find_otp = (new OTP)->get_by_mobile( $mobile );

		if(
			( !$find_otp || $find_otp['otp'] != $otp ) // OTP not found or not match
			|| ( strtotime( $find_otp['expire'] ) < Utils::convert_chars( date_i18n( 'U' ) ) ) // OTP expired
		) {
			$this->result( 'error', [
				'code'		=> 'otp_not_match',
				'message'	=> esc_html__( 'OTP code does not match', 'drplus' ),
			] );
		}

		$sms_settings = UtilsSMS::get_settings();

		$user = User::find_user_by_mobile( $mobile );
		if( $user ) { // Login
			if( empty( $sms_settings['settings']['auth']['login']['enabled'] ) ) {
				$this->result( 'error', [
					'code'		=> 'login_not_active',
					'message'	=> esc_html__( 'Login via SMS is not active.', 'drplus' ),
				] );
			}
		} else { // Register
			if( empty( $sms_settings['settings']['auth']['register']['enabled'] ) ) {
				$this->result( 'error', [
					'code'		=> 'register_not_active',
					'message'	=> esc_html__( 'Register via SMS is not active.', 'drplus' ),
				] );
			}

			$user_id = $this->create_user( $mobile, '', '', $mobile );
			$user = get_user_by( 'id', $user_id );
		}
		if( !is_wp_error( $user ) ) {
			wp_set_current_user( $user->ID, $user->user_login );
			wp_set_auth_cookie( $user->ID, true );
			do_action( 'wp_login', $user->user_login, $user );

			$find_otp = (new OTP( $find_otp['id'] ))->delete( false );

			$this->result( 'success', [
				'code'		=> 'login_success',
				'message'	=> esc_html__( 'Login successful. The page will reload.', 'drplus' ),
			] );
		} else {
			$this->result( 'error', [
				'code'		=> array_keys( $user_id->errors )[0],
				'message'	=> $user_id->get_error_message(),
			] );
		}
	}

	public function lost_password() {
		$this->set_request_data();

		$user = $this->find_user_with_everything( $this->data['entry'] );
		if( $user ) {
			$user_id = $user->ID;
			$new_password = wp_generate_password( 8, false );
			$update = wp_update_user( [ 'ID' => $user_id, 'user_pass' => $new_password ] );
			if( is_wp_error( $update ) ) {
				$this->result( 'error', [
					'code'		=> array_keys( $update->errors )[0],
					'message'	=> $update->get_error_message(),
				] );
			} else {
				$options = Options::get_options( [
					'lost-password-email-subject'	=> '',
					'lost-password-email-template'	=> '',
				] );

				if( empty( $options['lost-password-email-template'] ) ) {
					$options['lost-password-email-template'] = get_bloginfo( 'name' ) . "<br>" . __( 'Your new password is: <strong>{password}</strong>', 'drplus' );
				}

				$email_msg = str_replace( "{password}", $new_password, $options['lost-password-email-template'] );

				if( $user->user_email ) {
					$send_email = wp_mail( $user->user_email, wp_strip_all_tags( $options['lost-password-email-subject'] ), $email_msg );
					if( !$send_email ) {
						$this->result( 'error', [
							'code'		=> 'send_email_failed',
							'message'	=> __( "Send email is failed", 'drplus' ),
						] );
					}
					if( is_wp_error( $send_email ) ) {
						$this->result( 'error', [
							'code'		=> array_keys( $send_email->errors )[0],
							'message'	=> $send_email->get_error_message(),
						] );
					}
				}

				$text = __( 'Your new password has been sent to your email address.', 'drplus' );

				$options = Options::get_options( [
					'sms'	=> true,
				] );
				if( Utils::to_bool( $options['sms'] ) ) {
					$sms_settings = UtilsSMS::get_settings();
					if( !empty( $sms_settings['settings']['auth']['lost_password']['enabled'] ) ) {
						$mobile = User::get_phone( $user_id );
						if( $mobile ) {
							$sms_send = SMS::send( $mobile, 'auth.lost_password', [ 'password' => $new_password ] );
							if( !$sms_send ) {
								$this->result( 'error', [
									'code'		=> 'send_failed',
									'message'	=> esc_html__( 'Error sending SMS', 'drplus' ),
								] );
							}
							if( is_wp_error( $sms_send ) ) {
								$this->result( 'error', [
									'code'		=> array_key_first( $sms_send->errors ),
									'message'	=> $sms_send->get_error_message(),
								] );
							}

							$text = __( 'Your new password has been sent to your email and mobile phone.', 'drplus' );
						}
					}
				}

				$this->result( 'success', [
					'code'		=> 'new_password_sent',
					'message'	=> $text,
				] );
			}
		} else {
			$this->result( 'error', [
				'code'		=> 'user_not_found',
				'message'	=> esc_html__( 'User not found', 'drplus' ),
			] );
		}
	}
}