<?php
namespace DrPlus\DB;

use DrPlus\Utils;
use DrPlus\DB as DB;

class SpecialistHospitalsRel extends DB {
	public string $table = 'drplus_specialist_hospitals_rel';
	public array $exclude_columns = ['creator', 'deleted'];

	public array $columns = [
		'id'			=> 'INT NOT NULL AUTO_INCREMENT',
		'user_id'		=> 'INT NOT NULL',
		'hospital_id'	=> 'INT NOT NULL',
	];
	public array $defaults = [
		'user_id'		=> 0,
		'hospital_id'	=> 0,
	];

	public function sanitize( bool $update = false ) {
		$this->user_id		= Utils::convert_chars( $this->user_id, true, 'absint' );
		$this->hospital_id	= Utils::convert_chars( $this->hospital_id, true, 'absint' );
	}
}
new SpecialistHospitalsRel;