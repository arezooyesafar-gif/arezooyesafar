<?php
namespace DrPlus\DB;

use DrPlus\Utils;
use DrPlus\DB as DB;

class SpecialistSpecialitiesRel extends DB {
	public string $table = 'drplus_specialist_speciality_rel';
	public array $exclude_columns = ['creator', 'deleted'];

	public array $columns = [
		'id'			=> 'INT NOT NULL AUTO_INCREMENT',
		'user_id'		=> 'INT NOT NULL',
		'speciality_id'	=> 'INT NOT NULL',
	];
	public array $defaults = [
		'user_id'		=> 0,
		'speciality_id'	=> 0,
	];

	public function sanitize( bool $update = false ) {
		$this->user_id			= Utils::convert_chars( $this->user_id, true, 'absint' );
		$this->speciality_id	= Utils::convert_chars( $this->speciality_id, true, 'absint' );
	}
}
new SpecialistSpecialitiesRel;