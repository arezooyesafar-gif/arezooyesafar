<?php
namespace DrPlus\DB;

use DrPlus\Utils;
use DrPlus\DB as DB;
use DrPlus\Utils\Sanitizers;
use DrPlus\Utils\UtilsSpecialists;

class Specialists extends DB {
	public string $table = 'drplus_specialists';
	public array $exclude_columns = ['deleted'];

	public array $columns = [
		'id'			=> 'INT NOT NULL AUTO_INCREMENT',
		'user_id'		=> 'INT NOT NULL UNIQUE',
		'post_id'		=> 'INT NULL DEFAULT 0',
		'slug'			=> 'VARCHAR(255) UNIQUE NULL',
		'subtitle'		=> 'TEXT NULL',
		'about'			=> 'TEXT NULL',
		'offline_visit'	=> 'BOOLEAN NULL',
		'online_visit'	=> 'BOOLEAN NULL',
		'is_verified'	=> 'BOOLEAN NULL',
		'meta'			=> 'LONGTEXT NULL',
		'offices'		=> 'LONGTEXT NULL',
		'documents'		=> 'LONGTEXT NULL',
		'status'		=> "TINYTEXT NOT NULL DEFAULT 'incomplete'",
		'reject'		=> 'TEXT NULL',
	];
	public array $defaults = [
		'user_id'		=> 0,
		'post_id'		=> 0,
		'slug'			=> '',
		'subtitle'		=> '',
		'about'			=> '',
		'offline_visit'	=> 0,
		'online_visit'	=> 0,
		'is_verified'	=> 0,
		'meta'			=> '',
		'offices'		=> '',
		'documents'		=> '',
		'status'		=> '',
		'reject'		=> '',
	];

	public function sanitize( bool $update = false ) {
		$this->user_id			= Utils::convert_chars( $this->user_id, true, 'absint' );
		$this->post_id			= Utils::convert_chars( $this->post_id, true, 'absint' );
		$this->slug				= Utils::convert_chars( $this->slug, true, 'sanitize_title_with_dashes' );
		$this->subtitle			= $this->subtitle !== null ? wp_kses_post( $this->subtitle ) : '';
		$this->about			= $this->about !== null ? wp_kses_post( $this->about ) : '';
		$this->offline_visit	= Utils::to_bool( $this->offline_visit );
		$this->online_visit		= Utils::to_bool( $this->online_visit );
		$this->is_verified		= Utils::to_bool( $this->is_verified );
		$this->status			= Utils::ensure_values_in_array( sanitize_text_field( $this->status ), array_keys( UtilsSpecialists::statuses() ), 'incomplete' );
		$this->reject			= $this->reject !== null ? wp_kses_post( $this->reject ) : '';

		$json_fields = ['meta', 'offices', 'documents'];
		foreach( $json_fields as $json_field ) {
			if( Utils::is_json( $this->{$json_field} ) ) {
				$this->{$json_field} = json_decode( $this->{$json_field} );
			}
			$this->{$json_field} = Utils::array_to_obj( $this->{$json_field} );
		}

		if( is_scalar( $this->offices ) ) {
			if( Utils::is_json( $this->offices ) ) {
				$this->offices = json_decode( $this->offices, true );
			} else {
				$this->offices = [];
			}
		}
		if( is_scalar( $this->documents ) ) {
			if( Utils::is_json( $this->documents ) ) {
				$this->documents = json_decode( $this->documents, true );
			} else {
				$this->documents = [];
			}
		}
		if( is_scalar( $this->meta ) ) {
			if( Utils::is_json( $this->meta ) ) {
				$this->meta = json_decode( $this->meta, true );
			} else {
				$this->meta = [];
			}
		}

		$this->sanitize_offices( $update );
		$this->sanitize_documents();
		$this->sanitize_meta();
		$this->sanitize_certificates();

		if( $update ) {
			foreach( $json_fields as $json_field ) {
				if( !Utils::is_json( $this->{$json_field} ) ) {
					$this->{$json_field} = wp_json_encode( $this->{$json_field} );
				}
			}
		}
	}

	private function sanitize_offices( $update ) {
		$offices = [];
		if( $this->offices === null ) {
			$this->offices = $offices;
		}
		foreach( $this->offices as $_office ) {
			$_office = Utils::obj_to_array( $_office, true );
			$_office = Utils::check_default( $_office, [
				'type'	=> '',
				'id'	=> '',
			] );

			$office = [
				'type'	=> Utils::ensure_values_in_array( sanitize_text_field( $_office['type'] ), ['hospital', 'custom', 'consultation'], '' ),
				'id'	=> Utils::convert_chars( $_office['id'] ),
			];

			if( $office['type'] == 'consultation' ) {
				$office['name'] = esc_html__( 'Online Consultation', 'drplus' );
			} else if( $office['type'] == 'custom' ) {
				if( !Utils::check_requires( $_office, ['name', 'address'] ) ) continue;
				$office['name'] = Utils::convert_chars( $_office['name'] );
				$office['phone'] = Sanitizers::phone( $_office['phone'] );
				$office['image'] = Utils::convert_chars( $_office['image'] );
				$office['province'] = Utils::convert_chars( $_office['province'] );
				$office['city'] = Utils::convert_chars( $_office['city'] );
				$office['address'] = Utils::convert_chars( $_office['address'] );
				$office['map_url'] = Utils::convert_chars( $_office['map_url'] );
				$office['map_url'] = sanitize_url( $office['map_url'], ['https', 'http'] );
				
				$office = Utils::check_array_types( $office, [
					'name'		=> 'string',
					'phone'		=> 'string',
					'image'		=> 'absint',
					'province'	=> 'string',
					'city'		=> 'string',
					'address'	=> 'string',
					'map_url'	=> 'string',
				] );
			}
			$office['visit_time'] = Utils::convert_chars( $_office['visit_time'] ?? '30', 'sanitize_text_field' );
			$office['visit_price'] = Utils::convert_chars( $_office['visit_price'] ?? "" );
			$office['main'] = Utils::to_bool( $_office['main'] ?? false );

			$offices[] = $office;
		}

		if( !$update && $this->online_visit ) {
			// check if consultation office is already in the list
			$offices = UtilsSpecialists::inject_consultation_office( $offices, $this->online_visit );
		}
		
		$this->offices = $offices;
	}

	private function sanitize_documents() {
		$documents = [];
		if( $this->documents === null ) {
			$this->documents = $documents;
		}
		foreach( $this->documents as $document ) {
			$document = Utils::obj_to_array( $document, true );
			$document = Utils::check_default( $document, [
				'attachment_id'	=> 0,
				'type'			=> '',
			] );
			
			$document = [
				'attachment_id'	=> Utils::convert_chars( $document['attachment_id'] ),
				'type'			=> Utils::convert_chars( $document['type'] ),
			];
			$document = Utils::check_array_types( $document, [
				'attachment_id'	=> 'absint',
				'type'			=> 'string',
			] );

			$documents[$document['type']] = $document;
		}

		$this->documents = $documents;
	}

	private function sanitize_meta() {
		if( isset( $this->meta->card_number ) ) {
			$this->meta->card_number = Sanitizers::card_number( $this->meta->card_number );
		}
		if( isset( $this->meta->services ) ) {
			if( is_array( $this->meta->services ) ) {
				foreach( $this->meta->services as $index => $service ) {
					if( empty( $service->title ) ) {
						unset( $this->meta->services[$index] );
					}
				}
				$this->meta->services = array_values( $this->meta->services );
			}
		}
	}

	private function sanitize_certificates() {
		if( isset( $this->meta->certificates ) ) {
			$certificates = [];
			foreach( $this->meta->certificates as $certificate ) {
				$certificate = Utils::obj_to_array( $certificate, true );
				$certificate = Utils::check_default( $certificate, [
					'title'			=> '',
					'attachment_id'	=> 0,
				] );
				$certificates[] = [
					'title'			=> Utils::convert_chars( $certificate['title'] ),
					'attachment_id'	=> Utils::convert_chars( $certificate['attachment_id'], true, 'absint' ),
				];
			}
			$this->meta->certificates = $certificates;
		}
	}
}
new Specialists;