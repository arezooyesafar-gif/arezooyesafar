<?php
namespace DrPlus\DB;

use DrPlus\Utils;
use DrPlus\DB as DB;

class SpecialistCitiesRel extends DB {
	public string $table = 'drplus_specialist_city_rel';
	public array $exclude_columns = ['creator', 'deleted'];

	public array $columns = [
		'id'		=> 'INT NOT NULL AUTO_INCREMENT',
		'user_id'	=> 'INT NOT NULL',
		'city'		=> 'TINYTEXT NOT NULL',
		'province'	=> 'TINYTEXT NOT NULL',
	];
	public array $defaults = [
		'user_id'	=> 0,
		'city'		=> '',
		'province'	=> '',
	];

	public function sanitize( bool $update = false ) {
		$this->user_id	= Utils::convert_chars( $this->user_id, true, 'absint' );
		$this->city		= Utils::convert_chars( $this->city );
		$this->province	= Utils::convert_chars( $this->province );
	}
}
new SpecialistCitiesRel;