<?php
if( !defined( 'ABSPATH' ) || !class_exists( "DrPlus\Utils" ) ) exit;

?>
<div id="sidebar" class="sidebar sidebar-single sidebar-single-hospital col-lg-3 col-md-12">
	<div id="widget-area" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 'single_hospital' ); ?>
	</div>
</div>