<?php

use DrPlus\Components\Button;
use DrPlus\Specialist;
use DrPlus\Utils;
use DrPlus\Utils\Booking;
use DrPlus\Utils\Date;
use DrPlus\Utils\Options;
use DrPlus\Utils\User;

$options = Options::get_options( [
	'booking-receipt-section-title-success'			=> esc_html__( 'Thank you. your requested appointment has been booked.', 'drplus' ),
	'booking-receipt-section-title-pending'			=> esc_html__( 'Your appointment has been reserved, but payment is still pending.', 'drplus' ),
	'booking-receipt-section-title-failed'			=> esc_html__( 'We\'re sorry; your appointment booking was unsuccessful. Please attempt your book again.', 'drplus' ),
	'booking-receipt-section-title-cancelled'		=> esc_html__( 'Your appointment has been cancelled as requested.', 'drplus' ),
	'booking-receipt-section-title-refunded'		=> esc_html__( 'Your payment has been refunded successfully.', 'drplus' ),
	'booking-receipt-section-offline-description'	=> esc_html__( 'Please arrive at the medical center 30 minutes before your scheduled appointment time.
In case of cancellation, half of the consultation fee will be deducted.', 'drplus' ),
	'booking-receipt-section-online-description'	=> esc_html__( 'At the scheduled consultation time, the specialist will contact you using the phone number you provided during the booking.
Please make sure to be available at that time and ensure your phone is turned on and has proper signal coverage.', 'drplus' )
] );

$args = Utils::check_default( $args, [
	'show_back_btn'	=> false,
	'book_data'		=> [],
	'order'			=> [],
	'view_type'		=> 'user' // user, specialist, thankyou
], ['book_data', 'order'] );
extract( $args );

$receipt_title = $options['booking-receipt-section-title-success'];
$order_status = $order->get_status();
if( in_array( $order_status, ['completed', 'processing'] ) ) {
	$receipt_title = $options['booking-receipt-section-title-success'];
} else if( in_array( $order_status, ['on-hold', 'pending'] ) ) {
	$receipt_title = $options['booking-receipt-section-title-pending'];
} else if( $order_status == 'failed' ) {
	$receipt_title = $options['booking-receipt-section-title-failed'];
} else if( $order_status == 'cancelled' ) {
	$receipt_title = $options['booking-receipt-section-title-cancelled'];
} else if( $order_status == 'refunded' ) {
	$receipt_title = $options['booking-receipt-section-title-refunded'];
}

$specialist_id = $book_data['specialist_id'];
$specialist = new Specialist( $specialist_id );
$selected_office = null;
foreach( $specialist->offices as $office ) {
	if( $office->id == $book_data['office_id'] ) {
		$selected_office = $office;
		break;
	}
}

$is_consultation = false;
if( $book_data['office_id'] == 'consultation' ) $is_consultation = true;

$customer_info = [
	'full_name' => [
		'label'	=> esc_html__( 'Full Name', 'drplus' ),
		'value'	=> "{$book_data['first_name']} {$book_data['last_name']}",
	],
	'email'		=> [
		'label'	=> esc_html__( 'Email', 'drplus' ),
		'value'	=> $book_data['email'],
		'ltr'	=> true,
	],
	'phone' => [
		'label'	=> esc_html__( 'Phone', 'drplus' ),
		'value'	=> $book_data['phone'],
		'ltr'	=> true,
	],
	'create_order_date'	=> [
		'label'	=> esc_html__( 'Submit request date', 'drplus' ),
		'value'	=> Utils\Date::jdate( 'd F Y H:i', $order->get_date_created()->getTimestamp() ),
	],
	'book_date'	=> [
		'label'	=> $is_consultation ? esc_html_x( 'Appointment date', 'online consultation', 'drplus' ) : esc_html__( 'Appointment date', 'drplus' ),
		'value'	=> "{$book_data['date']} {$book_data['start_time']}",
	],
];

// Add time suffix
if( $book_data['start_time'] ) {
	$hour = explode( ":", $book_data['start_time'] )[0];
	$hour = (int) $hour;
	$customer_info['book_date']['value'] .= " " . Date::get_time_period( $hour );
}

$transaction_info = [
	'visit_price'	=> [
		'label'	=> esc_html__( 'Visit price', 'drplus' ),
		'value'	=> sprintf( esc_html__( '%s Toman', 'drplus' ), number_format( $book_data['visit_price'], 0 ) ),
	],
	'commission_fee'	=> [
		'label'	=> esc_html__( 'Commission fee', 'drplus' ),
		'value'	=> sprintf( esc_html__( '%s Toman', 'drplus' ), number_format( $book_data['commission_value'], 0 ) ),
	],
	'discount'	=> [
		'label'	=> esc_html__( 'Discount', 'drplus' ),
		'value'	=> sprintf( esc_html__( '%s Toman', 'drplus' ), number_format( $order->get_total_discount(), 0 ) ),
	],
	'transaction_id'	=> [
		'label'	=> esc_html__( 'Transaction ID', 'drplus' ),
		'value'	=> empty( $order->get_transaction_id() ) ? esc_html__( 'N/A', 'drplus' ) : $order->get_transaction_id(),
	],
	'payment_method'	=> [
		'label'	=> esc_html__( 'Payment method', 'drplus' ),
		'value'	=> $order->get_payment_method_title(),
	],
	'payment_date'	=> [
		'label'	=> esc_html__( 'Payment date', 'drplus' ),
		'value'	=> Utils\Date::jdate( 'd F Y H:i', $order->get_date_created()->getTimestamp() ),
	],
	'payment_status'	=> [
		'label'	=> esc_html__( 'Payment status', 'drplus' ),
		'value'	=> wc_get_order_status_name( $order_status ),
	],
];

if( $view_type == 'specialist' ) {
	$customer_info['office'] = [
		'label'	=> esc_html__( 'Office', 'drplus' ),
		'value'	=> $book_data['office_name']
	];
	$transaction_info['specialist_income'] = [
		'label'	=>  esc_html__( 'Your income', 'drplus' ),
		'value'	=> sprintf( esc_html__( '%s Toman', 'drplus' ), number_format( $book_data['specialist_income'], 0 ) )
	];
	Utils::reposition_array_element( $transaction_info, 'specialist_income', 3 );
}

if( $book_data['commission_calculate_type'] != 'add_to_customer_order' ) {
	$transaction_info['commission_fee']['value'] = sprintf( esc_html__( '%s Toman', 'drplus' ), 0 );
}
?>
<div class="drplus-booking-receipt-wrap<?php echo $view_type == 'thankyou' ? ' drplus-booking-receipt-wrap-thankyou' : '' ?>">
	<?php if ( $order->has_status( 'failed' ) ) : ?>
		<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed"><?php echo $receipt_title ?></p>
	<?php else : ?>
		<?php if( $view_type == 'thankyou' ) { ?>
			<h3 class="drplus-booking-receipt-title">
				<?php echo $receipt_title ?>
			</h3>
		<?php } ?>
		<div class="drplus-booking-receipt booking-section">
			<div class="drplus-booking-receipt-head">
				<span class="drplus-booking-receipt-id"><?php printf( $is_consultation ? esc_html__( 'Online consultation appointment #%s', 'drplus' ) : esc_html__( 'Appointment #%s', 'drplus' ), $book_data['book_id'] ) ?></span>
				<span class="drplus-booking-receipt-status status-<?php echo $order_status ?>"><?php echo esc_html( Booking::get_order_statuses()[$order_status] ) ?></span>
				<span class="drplus-booking-receipt-app-type <?php echo $is_consultation ? "app-consultation" : "app-office" ?>"><?php echo $is_consultation ? esc_html__( 'Online consultation', 'drplus' ) : esc_html__( 'in-person visit', 'drplus' ) ?></span>
				

				<?php if( Utils::to_bool( $show_back_btn ) ) {
					Button::view( [
						'icon'	=> is_rtl() ? 'drplus-icon-left' : 'drplus-icon-right',
						'link'	=> remove_query_arg( 'order_id' ),
						'type'	=> 'gray',
						'small'	=> true,
						'align'	=> 'end'
					] );
				} ?>
			</div>
			<?php if( $view_type == 'specialist' ) { ?>
				<span class="drplus-specialist-apps-customer-info-title drplus-booking-receipt-part-title"><?php esc_html_e( 'Patient information', 'drplus' ) ?>:</span>
			<?php } ?>
			<div class="drplus-booking-receipt-customer-info-wrap<?php echo $view_type != 'specialist' ? ' info-has-desc' : ' booking-section' ?>">
				<div class="drplus-booking-receipt-customer-info">
					<?php foreach( $customer_info as $customer_info_item ) { ?>
						<div class="drplus-booking-receipt-customer-info-item">
							<span class="drplus-booking-receipt-customer-info-label drplus-booking-receipt-part-title"><?php echo esc_html( $customer_info_item['label'] ) ?></span>
							<span class="drplus-booking-receipt-customer-info-value<?php echo !empty( $customer_info_item['ltr'] ) ? ' ltr' : '' ?>"><?php echo esc_html( $customer_info_item['value'] ) ?></span>
						</div>
					<?php } ?>
				</div>
				<?php if( $view_type != 'specialist' ) { ?>
					<div class="drplus-booking-receipt-booking-description">
						<span class="drplus-booking-receipt-part-title">
							<?php esc_html_e( 'Description', 'drplus' ) ?>
						</span>
						<div class="drplus-booking-receipt-booking-description-text">
							<?php echo wpautop( esc_html( $is_consultation ? $options['booking-receipt-section-online-description'] : $options['booking-receipt-section-offline-description'] ) ) ?>
						</div>
					</div>
				<?php } ?>
			</div>
			<?php if( $view_type != 'specialist' ) { ?>
				<div class="drplus-booking-receipt-specialist-info-wrap">
					<span class="drplus-booking-receipt-specialist-info-title drplus-booking-receipt-part-title">
						<?php esc_html_e( 'The selected specialist\'s information:', 'drplus' ) ?>
					</span>
					<div class="drplus-booking-receipt-specialist-info booking-section">
						<?php Booking::specialist_info_html( $specialist ); ?>
						<?php Booking::specialist_office_html( $selected_office, false, true ) ?>
					</div>
				</div>
			<?php } ?>
			<div class="drplus-booking-receipt-transaction-info-wrap">
				<span class="drplus-booking-receipt-transaction-info-title drplus-booking-receipt-part-title">
					<?php esc_html_e( 'The transaction information:', 'drplus' ) ?>
				</span>
				<div class="drplus-booking-receipt-transaction-info booking-section">
					<div class="drplus-booking-receipt-transaction-info-inner booking-section">
						<?php foreach( $transaction_info as $transaction_info_item ) { ?>
							<div class="drplus-booking-receipt-transaction-info-item">
								<span class="drplus-booking-receipt-transaction-info-label drplus-booking-receipt-part-title"><?php echo esc_html( $transaction_info_item['label'] ) ?></span>
								<span class="drplus-booking-receipt-transaction-info-value<?php echo !empty( $transaction_info_item['ltr'] ) ? ' ltr' : '' ?>"><?php echo $transaction_info_item['value'] ?></span>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php if( $view_type == 'user' ) { ?>
				<?php if( $order_status == 'completed' ) { ?>
					<div class="drplus-booking-receipt-review-wrap">
						<?php
						$user_app_reviews = User::get_user_appointments_reviews();
						if( array_key_exists( $order->get_id(), $user_app_reviews ) ) { // user added a review
							// Show review
							$comment_id = $user_app_reviews[$order->get_id()];
							?>
								<div class="drplus-booking-receipt-review-title drplus-booking-receipt-part-title">
									<?php esc_html_e( 'Your review', 'drplus' ) ?>
								</div>
								<div class="drplus-booking-receipt-review-container">
									<?php get_template_part( 'templates/booking/template-booking-step-receipt-review-item', null, ['comment_id' => $comment_id] ) ?>
								</div>
							<?php
						} else {
							ob_start();
							get_template_part( "templates/components/template-components-button", null, [
								'type'			=> 'primary',
								'text'			=> 'button-text',
								'icon'			=> 'drplus-icon-arrow-up-left-square',
								'icon_align'	=> 'end',
								'align'			=> 'end',
								'small'			=> true,
								'classes'		=> ['button-class'],
								'id'			=> 'button-id',
								'atts'			=> [
									'type'	=> 'submit',
									'name'	=> 'button-name'
								],
							] );
							$submit_button = ob_get_clean();
							$submit_button = str_replace( 'button-name', '%1$s', $submit_button );
							$submit_button = str_replace( 'button-id', '%2$s', $submit_button );
							$submit_button = str_replace( 'button-class', '%3$s', $submit_button );
							$submit_button = str_replace( 'button-text', '%4$s', $submit_button );
							$submit_button = '<input type="hidden" name="drplus_comment_order_id" value="' . $order->get_id() . '">' . $submit_button;						
							
							$comment_args = [
								'logged_in_as'			=> '',
								'comment_notes_before'	=> '',
								'title_reply'			=> esc_html__( 'Add a review', 'drplus' ),
								'title_reply_before'  	=> '<span class="drplus-booking-receipt-part-title">',
								'title_reply_after'   	=> '</span>',
								'submit_button'			=> $submit_button
							];
							comment_form( $comment_args, $specialist->post_id );
						}
						?>
					</div>
				<?php } else { ?>
					<span class="drplus-booking-receipt-review-notice">
						<?php esc_html_e( 'You will be able to submit a review after the appointment is completed.', 'drplus' ) ?>
					</span>
				<?php } ?>
			<?php } ?>
		</div>
	<?php endif; ?>
</div>