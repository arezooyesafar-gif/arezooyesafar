<?php
/**
 * Product Loop End
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/loop-end.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     2.0.0
 */

use DrPlus\Utils;
use DrPlus\Utils\Product;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$props = wc_get_loop_prop( 'drplus_loop_props' );
if( !is_array( $props ) ) $props = [];
$props = Utils::check_default( $props, Product::get_default_props() );
?>
</ul>
<?php if( empty( $props['remove_swiper_div'] ) ) { ?>
</div>
<?php } ?>