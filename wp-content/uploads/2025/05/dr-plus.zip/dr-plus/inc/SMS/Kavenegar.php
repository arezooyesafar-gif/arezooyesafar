<?php
namespace DrPlus\SMS;

use DrPlus\Utils\SMS;

class Kavenegar extends Gateway {
	public function __construct( $service = false ) {
		$settings = SMS::get_settings();
		parent::__construct( [
			'id'			=> 'melipayamak',
			'url_template'	=> 'https://api.kavenegar.com/v1/{api_key}',
			'api_key'		=> $service ? $settings['melipayamak_service']['api_key'] : $settings['melipayamak']['api_key'],
			'from'			=> $service ? '' : $settings['melipayamak']['from'],
		] );

		return $this;
	}

	protected function prepare() {
		$this->set_data( [
			'request_options'	=> [
				'httpversion'	=> '1.1',
				'timeout'		=> 60,
			],
		] );

		return $this;
	}

	public function _send() {
		$request_args = $this->request_options;
		
		$url = add_query_arg( [
			'receptor'	=> implode( ",", $this->to ),
			'message'	=> urlencode( $this->text )
		], "{$this->base_url}/sms/send.json" );

		$request = wp_remote_get( $url, $request_args );
		if( is_wp_error( $request ) ) {
			$this->wp_error = $request;
		}
		return $this;
	}

	public function _send_by_pattern( string $pattern ) {
		$request_args = $this->request_options;

		$pattern_variables = array_values( $this->exploded_pattern );

		$query_args = [
			'receptor'	=> $this->to[0],
			'template'	=> $pattern,
		];
		if( !empty( $pattern_variables[0] ) ) {
			$query_args['token'] = $pattern_variables[0];
		}
		if( !empty( $pattern_variables[1] ) ) {
			$query_args['token2'] = $pattern_variables[1];
		}
		if( !empty( $pattern_variables[2] ) ) {
			$query_args['token3'] = $pattern_variables[2];
		}
		$url = add_query_arg( $query_args, "{$this->base_url}/verify/lookup.json" );

		$request = wp_remote_get( $url, $request_args );
		if( is_wp_error( $request ) ) {
			$this->wp_error = $request;
		}
		return $this;
	}
}