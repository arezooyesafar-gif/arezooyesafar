<?php
/**
 * Related Products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/related.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     9.6.0
 */

use DrPlus\Utils;
use DrPlus\Utils\Elementor;
use DrPlus\Utils\Product;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $related_products ) :
	$props = [
		'desktop_slider'		=> true,
		'desktop_slides_type'	=> 'count',
		'desktop_slides_space'	=> 24,
		'tablet_slider'			=> true,
		'tablet_slides_type'	=> 'auto',
		'tablet_slides_space'	=> 24,
		'mobile_slider'			=> true,
		'mobile_slides_type'	=> 'auto',
		'mobile_slides_space'	=> 24,
	];
	$props = Utils::check_default( $props, Product::get_default_props() );

	$display_attributes = Elementor::get_display_attributes( $props );
	$attributes = [
		'class'			=> [
			'drplus-slider-wrap',
			'drplus-products-slider',
			'related_inner',
		],
		'data-settings'	=> $display_attributes['args'],
		'style'			=> $display_attributes['style'],
	];
	$attributes['class'] = array_merge( $attributes['class'], $display_attributes['wrap_classes'] );
?>

	<section class="related">
		<div <?php echo Utils::get_html_attributes( $attributes ) ?>>

			<?php
			$heading = apply_filters( 'woocommerce_product_related_products_heading', __( 'Related products', 'woocommerce' ) );

			$shop_page = get_permalink( wc_get_page_id( 'shop' ) );
			if ( $heading ) {
				get_template_part( "templates/components/template-components-section_title", null, [
					'icon'			=> DRPLUS_URI . "/assets/images/diamond.svg",
					'icon_has_bg'	=> false,
					'title'			=> esc_html( $heading ),
					'nav_btns'		=> true,
					'classes'		=> ['related-product-title'],
				] );
			}
			?>
			
			<?php
			$props['remove_swiper_div'] = true;
			wc_set_loop_prop( 'drplus_loop_props', $props );
			woocommerce_product_loop_start();
			?>

				<?php foreach ( $related_products as $related_product ) : ?>

						<?php
						$post_object = get_post( $related_product->get_id() );

						setup_postdata( $GLOBALS['post'] = $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found

						wc_get_template_part( 'content', 'product' );
						?>

				<?php endforeach; ?>

			<?php woocommerce_product_loop_end(); ?>

			<?php
			get_template_part( "templates/components/button", null, [
				'type'		=> 'action',
				'small'		=> true,
				'text'		=> esc_html__( "View all", 'drplus' ),
				'link'		=> $shop_page,
				'align'		=> 'center',
				'id'		=> 'related-products-view-mobile',
				'classes'	=> ['hide-desktop-1024'],
			] );
			?>
		</div>
	</section>
	<?php
endif;

wp_reset_postdata();
