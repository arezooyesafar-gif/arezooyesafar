<?php

namespace DrPlus\Backend\Specialists;

class All extends Settings {
	protected static $PREFIX = '';
	public static function view() {
		self::$PREFIX = parent::$PREFIX;

		?>
		<div class="<?php echo self::$PREFIX ?>specialists-list">
			<form action="" method="POST">
				<?php
				parent::$table->prepare_items();
				parent::$table->views();
				parent::$table->search_box( __( 'Search Specialist', 'drplus' ), 'search_specialist' );
				parent::$table->display();
				?>
			</form>
		</div>
		<?php
	}
}