<?php

use DrPlus\Utils;

if( !function_exists( "drplus_setup" ) ) {
	function drplus_setup() {
		$supports = ['title-tag', 'post-thumbnails', 'automatic-feed-links', 'menus', 'widgets', 'woocommerce'];
		foreach( $supports as $support ) {
			add_theme_support( $support );
		}
	}
}
add_action( 'after_setup_theme', 'drplus_setup' );

if( !function_exists( "drplus_init" ) ) {
	function drplus_init() {
		load_theme_textdomain( 'drplus',  DRPLUS_DIR . 'languages' );

		include( DRPLUS_DIR . "inc/Utils.php" );
		include( DRPLUS_DIR . "inc/Utils/utils-options.php" );

		// Nav menus
		register_nav_menus( [
			'main-menu'		=> esc_html__( 'Header (Main menu)', 'drplus' ),
			'mobile-menu'	=> esc_html__( 'Mobile menu (Main menu)', 'drplus' ),
			'footer-menu'	=> esc_html__( 'Footer', 'drplus' ),
			'account-menu'	=> esc_html__( 'Account menu (Logged in users)', 'drplus' ),
		] );

		include_once( DRPLUS_DIR . "inc/TGM/tgm.php" );

		include( DRPLUS_DIR . "inc/Includes.php" );
	}
}
add_action( 'init', 'drplus_init', 0 );

if( !function_exists( "drplus_admin_enqueue" ) ) {
	function drplus_admin_enqueue() {
		$screen = get_current_screen();
		if( $screen->base === 'toplevel_page_drplus' ) {
			if( is_rtl() ) {
				wp_enqueue_style( 'drplus-options', DRPLUS_URI . "assets/css/backend/options.rtl.min.css", [], DRPLUS_VERSION );
			}
		}
		wp_enqueue_style( "drplus-icon", DRPLUS_URI . "assets/css/iconly.min.css", [], DRPLUS_VERSION );

		if( DRPLUS_DEV ) {
			wp_enqueue_script( 'drplus-utils', DRPLUS_URI . "assets/js/utils.js", ['jquery'], DRPLUS_VERSION, true );
			wp_enqueue_script( 'drplus', DRPLUS_URI . "assets/js/drplus.js", ['jquery'], DRPLUS_VERSION, true );
		} else {
			wp_enqueue_script( 'drplus-utils', DRPLUS_URI . "assets/js/utils.min.js", ['jquery'], DRPLUS_VERSION, true );
			wp_enqueue_script( 'drplus', DRPLUS_URI . "assets/js/drplus.min.js", ['jquery'], DRPLUS_VERSION, true );
		}

		Utils::drplus_vars_localize();

		if( DRPLUS_DEV ) {
			wp_enqueue_script( 'drplus-backend', DRPLUS_URI . "assets/js/backend/backend.js", ['jquery'], DRPLUS_VERSION, true );
		} else {
			wp_enqueue_script( 'drplus-backend', DRPLUS_URI . "assets/js/backend/backend.min.js", ['jquery'], DRPLUS_VERSION, true );
		}
		
		include( DRPLUS_DIR . "inc/AdminScripts.php" );
	}
}
add_action( 'admin_enqueue_scripts', "drplus_admin_enqueue", 9 );

if( !function_exists( "drplus_enqueue" ) ) {
	function drplus_enqueue() {
		include( DRPLUS_DIR . "inc/Scripts.php" );
	}
}
add_action( 'wp_enqueue_scripts', "drplus_enqueue" );

if( !function_exists( "drplus_load_taxonomies" ) ) {
	function drplus_load_taxonomies() {
		$taxonomies = [
			'Product'	=> [
				'product-service',
				'product-badge',
			],
			'Hospital'	=> [
				'hospital_category',
				'hospital-service',
			],
			'Specialist'	=> [
				'insurance',
				'identity_types'
			]
		];
		foreach( $taxonomies as $dir => $files ) {
			if( is_array( $files ) ) {
				foreach( $files as $filename ) {
					if( file_exists( DRPLUS_DIR . "inc/Taxonomies/{$dir}/taxonomy-{$filename}.php" ) ) {
						include( DRPLUS_DIR . "inc/Taxonomies/{$dir}/taxonomy-{$filename}.php" );
					}
				}
			} else {
				$filename = $files;
				if( file_exists( DRPLUS_DIR . "inc/Taxonomies/taxonomy-{$filename}.php" ) ) {
					include( DRPLUS_DIR . "inc/Taxonomies/taxonomy-{$filename}.php" );
				}
			}
		}
	}
}
add_action( 'init', 'drplus_load_taxonomies' );

// MARK: Shortcodes
if( !function_exists( "drplus_include_shortcodes" ) ) {
	function drplus_include_shortcodes() {
		$shortcodes = [
			'post-views',
			'booking'
		];
		foreach( $shortcodes as $index => $shortcode ) {
			if( !Utils::should_include_module( $index, $shortcode ) ) continue;
			$shortcode = Utils::get_module_name( $index, $shortcode );
			if( file_exists( DRPLUS_DIR . "inc/Shortcodes/shortcode-{$shortcode}.php" ) ) {
				include( DRPLUS_DIR . "inc/Shortcodes/shortcode-{$shortcode}.php" );
			}
		}
	}
}
add_action( 'wp_loaded', 'drplus_include_shortcodes' );

if( !function_exists( 'drplus_custom_head_code' ) ) {
	function drplus_custom_head_code() {
		if( empty( $GLOBALS['drplus'] ) ) return;
		
		$options = $GLOBALS['drplus'];
		echo isset( $options['header_custom_code'] ) ? $options['header_custom_code'] : '';
	}
}
add_action( 'wp_head', 'drplus_custom_head_code' );

if( !function_exists( 'drplus_custom_footer_code' ) ) {
	function drplus_custom_footer_code() {
		if( empty( $GLOBALS['drplus'] ) ) return;

		$options = $GLOBALS['drplus'];
		echo isset( $options['footer_custom_code'] ) ? $options['footer_custom_code'] : '';
	}
}
add_action( 'wp_footer', 'drplus_custom_footer_code' );

// Add custom select html
if( !function_exists( "drplus_custom_select_html" ) ) {
	function drplus_custom_select_html() {
		?>
		<div class="drplus-custom-select-popover">
			<div class="drplus-custom-select-popover-search-wrap">
				<input type="search" class="drplus-custom-select-popover-search" placeholder="<?php esc_attr_e( "Search...", 'drplus' ) ?>">
			</div>

			<div class="drplus-custom-select-popover-list"></div>
		</div>
		<?php
	}
}
add_action( 'wp_footer', 'drplus_custom_select_html', 9999 );

// Add search input html
if( !function_exists( "drplus_search_input_html" ) ) {
	function drplus_search_input_html() {
		?>
		<div class="drplus-search-input-popover loading">
			<?php get_template_part( "templates/components/template-components-loading", null, [
				'text'		=> esc_html__( "Searching...", 'drplus' ),
				'classes'	=> ['drplus-search-input-popover-loading'],
			] ) ?>

			<div class="drplus-search-input-popover-list"></div>

			<div class="drplus-search-input-popover-empty">
				<i class="drplus-icon-search-2"></i>
				<span class="drplus-search-input-popover-empty-text"><?php esc_html_e( 'No results. Please try again with a different text.', 'drplus' ) ?></span>
			</div>
		</div>
		<?php
	}
}
add_action( 'wp_footer', 'drplus_search_input_html', 9999 );

// Add overlay
if( !function_exists( "drplus_overlay" ) ) {
	function drplus_overlay() {
		?>
		<div id="drplus-overlay" class="drplus-overlay"></div>
		<?php
	}
}
add_action( 'wp_footer', 'drplus_overlay' );

if( !function_exists( "drplus_redux_prevent_icons_request" ) ) {
	function drplus_redux_prevent_icons_request( $response, $parsed_args, $url ) {
		if( !is_admin() ) {
			return $url === DRPLUS_URI . "assets/css/iconly.min.css";
		}
		return $response;
	}
}
add_filter( 'pre_http_request', 'drplus_redux_prevent_icons_request', 10, 3 );

if( !function_exists( 'drplus_flush_rewrite' ) ) {
	function drplus_flush_rewrite() {
		flush_rewrite_rules();
	}
}
add_action( 'after_switch_theme', 'drplus_flush_rewrite' );