<?php
namespace DrPlus\Utils;

use DrPlus\DB\SpecialistsStatics as DBSpecialistsStatics;
use DrPlus\Utils;

class UtilsDBSpecialistsStatics extends Utils {
	public static function all( $only_actives = true ) {
		$statics = new DBSpecialistsStatics;
		$where = [];
		if( $only_actives ) {
			$where = [
				'AND'	=> [
					'`status`=%s'	=> 'active'
				]
			];
		}
		return $statics->find( $where )->data;
	}

	public static function get( $id ) {
		$statics = new DBSpecialistsStatics( absint( $id ) );
		return $statics->data;
	}

	public static function get_by_user_id( $user_id = 0 ) {
		$user_id = Utils::get_user_id( $user_id );
		if( empty( $user_id ) ) return false;
		$statics = new DBSpecialistsStatics;
		$where = [];
		$where = [
			'AND'	=> [
				'`user_id`=%d'	=> $user_id
			]
		];
		return $statics->find( $where )->data ?? false;
	}

	public static function new( $data ) {
		$statics = new DBSpecialistsStatics;
		foreach( $data as $key => $value ) {
			$statics->$key = $value;
		}
		return $statics->insert();
	}

	public static function update( $id, $data ) {
		$statics = new DBSpecialistsStatics( absint( $id ) );
		if( empty( $statics->data ) ) return false;

		foreach( $data as $key => $value ) {
			$statics->$key = $value;
		}
		return $statics->update()->data;
	}

	public static function delete( $id ) {
		$statics = new DBSpecialistsStatics( absint( $id ) );
		if( empty( $statics->data ) ) return false;
		return $statics->delete();
	}
}