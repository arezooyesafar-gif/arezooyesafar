<?php

add_filter( 'cron_schedules', 'drplus_update_booking_statuses_interval' );
function drplus_update_booking_statuses_interval( $schedules ) { 
    $schedules['drplus_five_minutes'] = [
        'interval' => 5 * 60,
        'display'  => esc_html__( 'Every Five Minutes', 'drplus' )
	];
    return $schedules;
}

if ( !wp_next_scheduled( 'drplus_update_booking_statuses_hook' ) ) {
    wp_schedule_event( time(), 'drplus_five_minutes', 'drplus_update_booking_statuses_hook' );
}

function drplus_update_booking_statuses_exec() {
	global $wpdb;

	// Update booking statuses to 'cancelled' if they are 'on-hold' and older than 30 minutes
	$expired_time = date( 'Y-m-d H:i:s', strtotime( '-30 minutes' ) );
	$table_name = "{$wpdb->prefix}drplus_booking";
	$query = $wpdb->prepare(
		"UPDATE $table_name SET order_status = %s WHERE order_status = %s AND created_at < %s",
		'cancelled',
		'on-hold',
		$expired_time
	);
	$wpdb->query( $query );
	
	// Get booking 'order_id' from booking table where date is in the past
	$past_date = date( 'Y-m-d' );
	$timezone = wp_timezone(); // Gets the timezone set in WordPress settings
	$current_time = new DateTime( 'now', $timezone );
	$current_time->modify( '-1 hour' );
	$past_time = $current_time->format( 'H:i:s' );
	$exclude_statuses = ['cancelled', 'refunded', 'failed', 'on-hold'];
	$where['AND'] = [
		'`date`<=%s' => $past_date,
		'`start_time`<=%s' => $past_time,
		'order_status NOT IN (' . Drplus\DB::placeholder( $exclude_statuses, '%s' ) . ')' => $exclude_statuses,
	];
	// Update order statuses to 'completed'
	$past_apps = (new Drplus\DB\Booking)->find( $where, ['order_id'] )->data;
	if( !empty( $past_apps ) ) {
		foreach( $past_apps as $app ) {
			$order = wc_get_order( $app['order_id'] );
			if( $order ) {
				$order->update_status( 'completed' );
			}
		}
	}
}
add_action( 'drplus_update_booking_statuses_hook', 'drplus_update_booking_statuses_exec' );