<?php

use DrPlus\Utils;
use DrPlus\Utils\Booking;

if( !defined( 'ABSPATH' ) ) exit;

if( empty( $args['specialist'] ) ) return;

$specialist = $args['specialist'];

// Get consultation visit time
$consultation_time = 0;
$specialist->offices = Utils::obj_to_array( $specialist->offices, true );
foreach( $specialist->offices as $office ) {
	if( $office['type'] == 'consultation' ) {
		$consultation_time = $office['visit_time'];
		break;
	}
}
?>
<?php if( !empty( $consultation_time ) ) { ?>
	<a href="<?php echo $args['page_link'] ?>" class="specialist-meta specialist-meta-consulting-duration">
		<div class="specialist-meta-title"><?php esc_html_e( 'Duration of consultation', 'drplus' ) ?></div>
		<div class="specialist-meta-value"><?php echo Booking::reserve_time_chunks()[$consultation_time] ?></div>
	</a>
<?php } ?>

<?php if( false ) { ?>
	<a href="<?php echo $args['page_link'] ?>" class="specialist-meta specialist-meta-response-status">
		<div class="specialist-meta-title"><?php esc_html_e( 'Response status', 'drplus' ) ?></div>
		<div class="specialist-meta-value">آماده پاسخگویی</div>
	</a>
<?php } ?>