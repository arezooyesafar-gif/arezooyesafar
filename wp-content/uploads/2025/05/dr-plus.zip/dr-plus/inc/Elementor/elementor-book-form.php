<?php
namespace DrPlus\Elementor;

use DrPlus\ElementorControls;

class BookForm extends \Elementor\Widget_Base {
	public function get_name() {
		return 'drplus_book_form';
	}

	public function get_title() {
		return esc_html__( 'Book form (Doctor Plus)', 'drplus' );
	}

	public function get_icon() {
		return 'eicon-calendar';
	}

	public function get_categories() {
		return ['drplus', 'basic'];
	}

	public function get_keywords() {
		return ['book', 'reserve', 'appointment', 'visit', 'form', 'نوبت', 'رزرو', 'ویزیت', 'پذیرش', 'فرم'];
	}

	private function settings_controls() {
		$this->start_controls_section( // content_section
			"settings_section",
			[
				'label'	=> esc_html__( 'General settings', 'drplus' ),
				'tab'	=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control( // columns
			'columns',
			[
				'label'				=> esc_html__( 'Columns', 'drplus' ),
				'type'				=> \Elementor\Controls_Manager::NUMBER,
				'default'			=> 2,
				'tablet_default'	=> 2,
				'mobile_default'	=> 1,
				'min'				=> 1,
				'ai'				=> [
					'type'	=> 'text',
				],
				'dynamic'			=> [
					'active'	=> true,
				],
			]
		);

		$this->end_controls_section();
	}

	private function fields_settings( $field_key, $label ) {
		$prefix = "{$field_key}_";
		$this->start_controls_section( // content_section
			$prefix . "settings_section",
			[
				'label'	=> sprintf( esc_html__( '%s Settings', 'drplus' ), $label ),
				'tab'	=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control( // status
			$prefix . 'status',
			[
				'label'			=> sprintf( esc_html__( 'Activate %s field', 'drplus' ), $label ),
				'type'			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on'		=> esc_html__( 'Show', 'drplus' ),
				'label_off'		=> esc_html__( 'Hide', 'drplus' ),
				'return_value'	=> 'yes',
				'default'		=> 'yes',
			]
		);

		if( !in_array( $field_key, ['birthday', 'gender'] ) ) {
			$this->add_control( // placeholder
				$prefix . 'placeholder',
				[
					'label'			=> sprintf( esc_html__( '%s field placeholder', 'drplus' ), $label ),
					'label_block'	=> true,
					'type'			=> \Elementor\Controls_Manager::TEXT,
					'default'		=> $label,
					'ai'			=> [
						'type'		=> 'text',
					],
					'dynamic'		=> [
						'active'	=> true,
					],
					'condition'		=> [
						$prefix . 'status'	=> 'yes'
					],
				]
			);
		}

		$this->end_controls_section();
	}

	protected function register_controls() {
		$this->settings_controls();
		// If you want to change the fields list, also change them in template part file
		$fields = [
			'first_name'	=> __( 'Firstname', 'drplus' ),
			'last_name'		=> __( 'Lastname', 'drplus' ),
			'nid'			=> __( 'National ID', 'drplus' ),
			'gender'		=> __( 'Gender', 'drplus' ),
			'birthday'		=> __( 'Year of birth', 'drplus' ),
			'phone'			=> __( 'Phone', 'drplus' ),
			'email'			=> __( 'Email', 'drplus' ),
			'specialist'	=> __( "Specialist", 'drplus' ),
		];
		foreach( $fields as $field_key => $label ) {
			$this->fields_settings( $field_key, $label );
		}
		ElementorControls::button_settings( $this, [
			'excludes'	=> ['link', 'new_tab'],
			'controls'	=> [
				'text'	=> [
					'default'	=> esc_html__( 'Submit appointment request', 'drplus' )
				],
				'icon'	=> [
					'default'	=> [
						'value'		=> is_rtl() ? 'drplus-icon-arrow-up-left-square' : 'drplus-icon-arrow-up-right-square',
						'library'	=> 'drplus-icon'
					]
				],
				'icon_align'	=> [
					'default'	=> 'end',
				],
				'align'	=> [
					'default'	=> 'end'
				],
			],
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'form_',
			'base_selector'	=> '.drplus-book-form-widget',
			
			'section'	=> [
				'name'	=> 'form_styles',
				'label'	=> esc_html__( 'Form style', 'drplus' ),
			],

			'mode'	=> 'wrap',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'input_wrap_',
			'base_selector'	=> '.input-wrap',
			
			'section'	=> [
				'name'	=> 'input_wrap_styles',
				'label'	=> esc_html__( 'Input wrap style', 'drplus' ),
			],

			'mode'	=> 'wrap',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'input_',
			'base_selector'	=> '.input-wrap',
			'selector'		=> 'input',
			
			'section'	=> [
				'name'	=> 'input_styles',
				'label'	=> esc_html__( 'Input style', 'drplus' ),
			],

			'mode'	=> 'text',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'select_',
			'base_selector'	=> '.input-wrap',
			'selector'		=> '.select2-container .select2-selection--single .select2-selection__rendered.select2-selection__rendered',
			
			'section'	=> [
				'name'	=> 'select_styles',
				'label'	=> esc_html__( 'Dropdown lists style', 'drplus' ),
			],

			'mode'	=> 'text',
		] );

		ElementorControls::general_style_controls( $this, [ // button
			'prefix'	=> 'button_',
			'selector'	=> '.button',
			
			'section'	=> [
				'name'	=> 'button_section',
				'label'	=> esc_html__( 'Button', 'drplus' ),
			],

			'mode'	=> 'wrapper',
		] );
		ElementorControls::general_style_controls( $this, [ // button_text
			'prefix'		=> 'button_text_',
			'base_selector'	=> '.button',
			'selector'		=> '.button-text',
			
			'section'	=> [
				'name'	=> 'button_text_section',
				'label'	=> esc_html__( 'Button text', 'drplus' ),
			],

			'mode'	=> 'text',
		] );
		ElementorControls::general_style_controls( $this, [ // button_icon
			'prefix'		=> 'button_icon_',
			'base_selector'	=> '.button',
			'selector'		=> '.button-icon',
			
			'section'	=> [
				'name'	=> 'button_icon_section',
				'label'	=> esc_html__( 'Button icon', 'drplus' ),
			],

			'mode'	=> 'icon',
		] );
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		
		get_template_part( "templates/components/template-components-book-form", null, $settings );
	}
}