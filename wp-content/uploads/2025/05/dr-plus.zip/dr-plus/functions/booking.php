<?php

use DrPlus\Utils\Booking;
use DrPlus\Utils\Options;

if( !function_exists( 'drplus_booking_check_logged_in' ) ) {
	function drplus_booking_check_logged_in() {
		if( is_user_logged_in() ) return;
		if( get_the_ID() != Booking::get_booking_page_id() ) return;

		// Check user login. if guest redirect to login page
		$active_auth = Options::get_options( [
			'auth'	=> true,
		] )['auth'];
		if( $active_auth ) {
			global $wp;
			wp_redirect( add_query_arg( ['login' => true, 'redirect_to' => home_url( $wp->request ) ] ) ); die;
		} else {
			// redirect to myaccount page
			wp_redirect( get_permalink( get_option( 'woocommerce_myaccount_page_id' ) ) ); die;
		}
	}
}
add_action( 'wp_head', 'drplus_booking_check_logged_in' );

if( !function_exists( 'drplus_booking_breadcrumb' ) ) {
	function drplus_booking_breadcrumb( $parts ) {
		if( get_the_ID() != Booking::get_booking_page_id() ) return $parts;

		$active_step = Booking::get_current_step();
		$booking_page_url = Booking::get_booking_page_url();
		if( $active_step == 'receipt' ) {
			$parts[Booking::booking_steps()[$active_step]] = '#';
		} else {
			foreach( Booking::booking_steps() as $key => $value ) {
				if( $key == $active_step ) {
					$parts[$value] = '#';
					break;
				} else {
					$parts[$value] = esc_url( trailingslashit( $booking_page_url ) . $key );
				}
			}
		}

		return $parts;
	}
}
add_filter( 'drplus/breadcrumb/parts', 'drplus_booking_breadcrumb' );

if( !function_exists( 'drplus_add_booking_endpoints' ) ) {
	function drplus_add_booking_endpoints() {
		if( !Booking::is_booking_active() ) return;
		$steps = Booking::booking_steps();

		foreach( array_keys( $steps ) as $step ) {
			add_rewrite_endpoint( $step, EP_PAGES );
		}
	}
}
add_action( 'init', 'drplus_add_booking_endpoints' );

if( !function_exists( 'drplus_booking_start_session' ) ) {
	function drplus_booking_start_session() {
		if( get_the_ID() != Booking::get_booking_page_id() ) return;

		if( !session_id() ) {
			session_start();
		}
	}
}
add_action( 'init', 'drplus_booking_start_session' );

if( !function_exists( 'drplus_create_booking_product' ) ) {
	function drplus_create_booking_product() {
		// Call get product id to check if product already created
		Booking::get_booking_product_id();
	}
}
add_action( 'after_switch_theme', 'drplus_create_booking_product' );