<?php

use DrPlus\Components\Button;
/**
 * Empty cart page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart-empty.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="woocommerce-page-content empty-page" id="empty-cart-content">
	<?php
	/*
	* @hooked wc_empty_cart_message - 10
	*/
	do_action( 'woocommerce_cart_is_empty' );

	if ( wc_get_page_id( 'shop' ) > 0 ) : ?>
		<p class="return-to-shop">
			<?php
				/**
				 * Filter "Return To Shop" text.
				 *
				 * @since 4.6.0
				 * @param string $default_text Default text.
				 */

				echo Button::view( [
					'link'		=> apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ),
					'text'		=> esc_html( apply_filters( 'woocommerce_return_to_shop_text', __( 'Return to Shop', 'drplus' ) ) ),
					'small'		=> true,
					'type'		=> 'bordered',
					'classes'	=> explode( ' ', 'button wc-backward' . ( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ) ),
				] );
			?>
		</p>
		
	<?php endif; ?>
</div>