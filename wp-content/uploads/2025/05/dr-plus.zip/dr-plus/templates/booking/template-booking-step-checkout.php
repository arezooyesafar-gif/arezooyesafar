<?php

use DrPlus\Specialist;
use DrPlus\Utils\Booking;
use DrPlus\Utils\Date;

$book_data = $args['book_data'];

$specialist_id = $book_data['specialist_id'];
$specialist = new Specialist( $specialist_id );

foreach( $specialist->offices as $office ) {
	if( $office->id == $book_data['office_id'] ) {
		$selected_office = $office;
		break;
	}
}

$date = $book_data['raw_date'];
$time = $book_data['raw_time'];
$week_name = Date::jdate( 'l', $date );
$date = Date::jdate( 'd F Y', $date );
$hour = date( "H", $time/1000 );
$time = date( "H:i", $time/1000 );
$time .= " " . Date::get_time_period( $hour );

$customer_info = [
	'full_name' => [
		'label'	=> esc_html__( 'Full Name', 'drplus' ),
		'value'	=> "{$book_data['first_name']} {$book_data['last_name']}",
	],
	'phone' => [
		'label'	=> esc_html__( 'Phone', 'drplus' ),
		'value'	=> $book_data['phone'],
		'ltr'	=> true,
	],
	'nid'	=> [
		'label'	=> esc_html__( 'National ID', 'drplus' ),
		'value'	=> $book_data['nid'],
		'ltr'	=> true,
	],
	'email'	=> [
		'label'	=> esc_html__( 'Email', 'drplus' ),
		'value'	=> $book_data['email'],
		'ltr'	=> true,
	],
	'gender'	=> [
		'label'	=> esc_html__( 'Gender', 'drplus' ),
		'value'	=> $book_data['gender'] == 'male' ? esc_html__( 'Male', 'drplus' ) : esc_html__( 'Female', 'drplus' ),
	],
	'birthday'	=> [
		'label'	=> esc_html__( 'Year of birth', 'drplus' ),
		'value'	=> $book_data['birthday'],
		'ltr'	=> true,
	],
];

?>
<div class="booking-section booking-checkout-customer-info">
	<?php foreach( $customer_info as $customer_info_item ) { ?>
		<div class="booking-checkout-customer-info-item">
			<span class="booking-checkout-customer-info-label"><?php echo esc_html( $customer_info_item['label'] ) ?></span>
			<span class="booking-checkout-customer-info-value<?php echo !empty( $customer_info_item['ltr'] ) ? ' ltr' : '' ?>"><?php echo esc_html( $customer_info_item['value'] ) ?></span>
		</div>
	<?php } ?>
</div>

<div class="booking-section booking-checkout-specialist-info">
	<?php Booking::specialist_info_html( $specialist ) ?>
	<?php Booking::specialist_office_html( $selected_office ) ?>
	<div class="booking-checkout-book-info">
		<div class="booking-info-date-wrap">
			<span class="booking-info-week"><?php echo esc_html( $week_name ) ?></span>
			<span class="booking-info-date"><?php echo esc_html( $date ) ?></span>
		</div>
		<span class="booking-info-time"><?php echo esc_html( $time ) ?></span>
	</div>
</div>