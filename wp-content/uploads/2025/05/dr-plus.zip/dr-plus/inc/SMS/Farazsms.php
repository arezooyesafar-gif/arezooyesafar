<?php
namespace DrPlus\SMS;

use DrPlus\Utils\SMS;

class Farazsms extends Gateway {
	public function __construct( $service = false ) {
		$settings = SMS::get_settings();
		parent::__construct( [
			'id'			=> 'farazsms',
			'variable_mode'	=> true,
			'url_template'	=> 'https://api2.ippanel.com/api/v1/sms',
			'api_key'		=> $service ? $settings['farazsms_service']['api_key'] : $settings['farazsms']['api_key'],
			'from'			=> $service ? $settings['farazsms_service']['from'] : $settings['farazsms']['from'],
		] );

		return $this;
	}

	protected function prepare() {
		$this->set_data( [
			'request_options'	=> [
				'httpversion'	=> '1.1',
				'timeout'		=> 60,
				'headers'		=> [
					'apikey'		=> $this->api_key,
					'Content-Type'	=> 'application/json',
					'accept'		=> '*/*',
				],
			],
		] );

		return $this;
	}

	public function _send() {
		$request_args = $this->request_options;
		$request_args['body'] = wp_json_encode( [
			'recipient'	=> $this->to,
			'sender'	=> $this->from,
		] );
		$request = wp_remote_post( "{$this->base_url}/send/webservice/single", $request_args );
		if( is_wp_error( $request ) ) {
			$this->wp_error = $request;
		}
		return $this;
	}

	public function _send_by_pattern( string $pattern ) {
		$request_args = $this->request_options;

		$request_args['body'] = wp_json_encode( [
			'code'		=> $pattern,
			'sender'	=> $this->from,
			'recipient'	=> $this->to[0],
			'variable'	=> $this->exploded_pattern,
		] );

		$request = wp_remote_post( "{$this->base_url}/pattern/normal/send", $request_args );
		if( is_wp_error( $request ) ) {
			$this->wp_error = $request;
		}
		return $this;
	}
}