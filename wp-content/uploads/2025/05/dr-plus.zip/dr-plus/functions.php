<?php

use DrPlus\DB;
use DrPlus\DB\Booking;
use DrPlus\Utils;
use DrPlus\Utils\User;
use DrPlus\Utils\UtilsSpecialists;

if( !defined( 'ABSPATH' ) ) exit;

// Define constants
if( !defined( 'DRPLUS_DIR' ) ) {
	define( 'DRPLUS_DIR', trailingslashit( get_template_directory() ) );
}

if( !defined( 'DRPLUS_URI' ) ) {
	define( 'DRPLUS_URI', trailingslashit( get_template_directory_uri() ) );
}

if( !defined( 'DRPLUS_VERSION' ) ) {
	define( 'DRPLUS_VERSION', "1.0.0.0" );
}

if( !defined( 'DRPLUS_DEV' ) ) {
	define( 'DRPLUS_DEV', true );
}

include( DRPLUS_DIR . "functions/init.php" );
include( DRPLUS_DIR . "functions/widgets.php" );
include( DRPLUS_DIR . "functions/elementor.php" );
include( DRPLUS_DIR . "functions/comments.php" );
include( DRPLUS_DIR . "functions/archive.php" );
include( DRPLUS_DIR . "functions/search.php" );
include( DRPLUS_DIR . "functions/hospitals.php" );
include( DRPLUS_DIR . "functions/users.php" );
include( DRPLUS_DIR . "functions/auth.php" );
include( DRPLUS_DIR . "functions/onboard.php" );
include( DRPLUS_DIR . "functions/specialists.php" );
include( DRPLUS_DIR . "functions/booking.php" );

add_action( 'init', function() {
	
} );