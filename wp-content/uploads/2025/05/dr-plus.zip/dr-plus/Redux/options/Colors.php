<?php
defined( 'ABSPATH' ) || exit;

Redux::set_section( // General colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'General colors', 'drplus' ),
		'id'			=> 'colors-general-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'body_color',
				'type'			=> 'color',
				'title'			=> __( 'Body color', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#ffffff' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#ffffff',
			],
			[
				'id'			=> 'text_main_color',
				'type'			=> 'color',
				'title'			=> __( 'Default text color', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#383838' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#383838',
			],
		),
	)
);

Redux::set_section( // Primary colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Primary colors', 'drplus' ),
		'id'			=> 'colors-primary-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'primary_color_100',
				'type'			=> 'color',
				'title'			=> __( 'Primary', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#1DBAB5' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#1DBAB5',
			],
			[
				'id'			=> 'primary_color_200',
				'type'			=> 'color',
				'title'			=> __( 'Primary 2', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#159F9B' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#159F9B',
			],
		),
	)
);

Redux::set_section( // Secondary colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Secondary colors', 'drplus' ),
		'id'			=> 'colors-secondary-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'secondary_color_100',
				'type'			=> 'color',
				'title'			=> __( 'Secondary', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#114B5F' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#114B5F',
			],
			[
				'id'			=> 'secondary_color_200',
				'type'			=> 'color',
				'title'			=> __( 'Secondary 2', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#0F3E4F' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#0F3E4F',
			],
		),
	)
);

Redux::set_section( // Heading colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Heading colors', 'drplus' ),
		'id'			=> 'colors-heading-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'heading_color_100',
				'type'			=> 'color',
				'title'			=> __( 'Heading 1', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#373434' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#373434',
			],
			[
				'id'			=> 'heading_color_200',
				'type'			=> 'color',
				'title'			=> __( 'Heading 2', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#181616' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#181616',
			],
		),
	)
);

Redux::set_section( // Gray colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Gray colors', 'drplus' ),
		'id'			=> 'colors-gray-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // gray_color_100
				'id'			=> 'gray_color_100',
				'type'			=> 'color',
				'title'			=> __( 'Gray 1', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#F7F7F7' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#F7F7F7',
			],
			[ // gray_color_200
				'id'			=> 'gray_color_200',
				'type'			=> 'color',
				'title'			=> __( 'Gray 2', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#E6E6E6' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#E6E6E6',
			],
			[ // gray_color_300
				'id'			=> 'gray_color_300',
				'type'			=> 'color', 
				'title'			=> __( 'Gray 3', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#DBDBDB' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#DBDBDB',
			],
			[ // gray_color_400
				'id'			=> 'gray_color_400',
				'type'			=> 'color',
				'title'			=> __( 'Gray 4', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#A7A7A7' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#A7A7A7',
			],
		),
	)
);

Redux::set_section( // Text colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Text colors', 'drplus' ),
		'id'			=> 'colors-text-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'text_color_100',
				'type'			=> 'color',
				'title'			=> __( 'Text 1', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#E7E7E7' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#E7E7E7',
			],
			[
				'id'			=> 'text_color_200',
				'type'			=> 'color',
				'title'			=> __( 'Text 2', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#A6A6A6' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#A6A6A6',
			],
			[
				'id'			=> 'text_color_300',
				'type'			=> 'color',
				'title'			=> __( 'Text 3', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#888888' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#888888',
			],
			[
				'id'			=> 'text_color_400',
				'type'			=> 'color',
				'title'			=> __( 'Text 4', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#848484' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#848484',
			],
			[
				'id'			=> 'text_color_500',
				'type'			=> 'color',
				'title'			=> __( 'Text 5', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#747474' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#747474',
			],
			[
				'id'			=> 'text_color_600',
				'type'			=> 'color',
				'title'			=> __( 'Text 6', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#383838' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#383838',
			],
		),
	)
);

Redux::set_section( // Form colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Form colors', 'drplus' ),
		'id'			=> 'colors-form-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'input_bg',
				'type'			=> 'color',
				'title'			=> __( 'Input background', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#f5f6f7' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#f5f6f7',
			],
			[
				'id'			=> 'input_secondary_bg',
				'type'			=> 'color',
				'title'			=> __( 'Input secondary background', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#ffffff' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#ffffff',
			],
			[
				'id'			=> 'input_text',
				'type'			=> 'color',
				'title'			=> __( 'Input text color', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#383838' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#383838',
			],
		),
	)
);

Redux::set_section( // Widget colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Widget colors', 'drplus' ),
		'id'			=> 'colors-widget-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'widget_bg',
				'type'			=> 'color',
				'title'			=> __( 'Widget background', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#F7F7F7' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#F7F7F7',
			],
			[
				'id'			=> 'widget_title_bg',
				'type'			=> 'color',
				'title'			=> __( 'Widget title background color', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#1dbab5' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#1dbab5',
			],
			[
				'id'			=> 'widget_title',
				'type'			=> 'color',
				'title'			=> __( 'Widget title color', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#ffffff' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#ffffff',
			],
			[
				'id'			=> 'widget_text_color',
				'type'			=> 'color',
				'title'			=> __( 'Widget text color', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#383838' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#383838',
			],
			[
				'id'			=> 'widget_links_color',
				'type'			=> 'color',
				'title'			=> __( 'Widget links color', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#383838' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#383838',
			],
		),
	)
);

Redux::set_section( // Other colors
	$opt_name,
	array(
		'title'			=> esc_html__( 'Other colors', 'drplus' ),
		'id'			=> 'colors-other-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'			=> 'green',
				'type'			=> 'color',
				'title'			=> __( 'Green', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#1dbab5' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#1dbab5',
			],
			[
				'id'			=> 'yellow',
				'type'			=> 'color',
				'title'			=> __( 'Yellow', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#FFBD12' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#FFBD12',
			],
			[
				'id'			=> 'red',
				'type'			=> 'color',
				'title'			=> __( 'Red', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '#d60043' ),
				'compiler'		=> true,
				'validate'		=> 'color',
				'transparent'	=> false,
				'default'		=> '#d60043',
			],
		),
	)
);