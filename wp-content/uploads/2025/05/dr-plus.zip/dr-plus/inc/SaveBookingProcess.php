<?php
namespace Drplus;

use DrPlus\DB\Booking as DBBooking;
use DrPlus\Specialist;
use DrPlus\Utils;
use Drplus\Utils\Booking;
use DrPlus\Utils\Date;
use DrPlus\Utils\Hospital;
use DrPlus\Utils\Options;
use DrPlus\Utils\Sanitizers;

class SaveBookingProcess {
	private static $active_step = "";
	public static function save_step() {
		if( get_the_ID() == Booking::get_booking_page_id() ) {
			self::check_error();

			if( Booking::get_current_step() == 'time' ) {
				if( !empty( $_SESSION['booking']['error'] ) ) {
					$_SESSION['booking'] = [
						'error'			=> $_SESSION['booking']['error'],
						'error_message'	=> $_SESSION['booking']['error_message'],
					];
				} else if( Utils::convert_chars( $_GET['refer'] ?? "" ) != 'widget' ) {
					// remove session
					if( isset( $_SESSION['booking'] ) ) {
						unset( $_SESSION['booking'] );
					}
				}
				return;
			}
		}

		if( !empty( $_POST['booking_widget_nonce'] ) && isset( $_POST['booking_widget_submit'] ) ) {
			// Coming from Widget
			// Check nonce
			$nonce = sanitize_text_field( $_POST['booking_widget_nonce'] );
			if( !wp_verify_nonce( $nonce, "booking_widget_nonce_value" ) ) return;

			// reset booking session
			if( isset( $_SESSION['booking'] ) ) {
				$_SESSION['booking'] = [];
			}

			// save data in cookies
			self::info( true );

			if( !empty( $_POST['sid'] ) ) {
				$specialist_id = Utils::convert_chars( $_POST['sid'] );
				$booking_url = stripslashes( Booking::get_booking_page_url() ) . 'time';
				$redirect_url = add_query_arg( [
					'sid'					=> $specialist_id,
					'drplus_save_recent'	=> 1,
					'refer'					=> 'widget',
					'consultation'			=> 1,
				], $booking_url );
				wp_safe_redirect( $redirect_url ); die;
			}

		} else if( !empty( $_POST['booking_nonce'] ) && !empty( $_POST['booking_step_submit'] ) ) {
			$nonce = sanitize_text_field( $_POST['booking_nonce'] );
			
			$steps = Booking::booking_steps();
			$active_step = Utils::convert_chars( $_POST['booking_step_submit'] );
			if( !in_array( $active_step, array_keys( $steps ) ) ) return;
			
			if( !wp_verify_nonce( $nonce, "booking_step_{$active_step}" ) ) return;

			self::$active_step = $active_step;
			
			if( !session_id() ) {
				session_start();
			}

			$_SESSION['booking']['error'] = "";
			$_SESSION['booking']['error_message'] = "";
	
			if( method_exists( 'Drplus\SaveBookingProcess', $active_step ) ) {
				self::$active_step();
			}
		}
		return;
	}

	public static function time() {
		$specialist_id = Utils::convert_chars( $_POST['booking_specialist_id'] ?? "", true, 'absint' );
		$time = Utils::convert_chars( $_POST['booking_time'] ?? "" );
		$date = Utils::convert_chars( $_POST['booking_date'] ?? "" );
		$office = Utils::convert_chars( $_POST['booking_office'] ?? "" );

		if( empty( $specialist_id ) ) {
			return self::set_error( 'specialist', __( 'Please select a Specialist first.', 'drplus' ) );
		}
		$_SESSION['booking']['specialist_id'] = $specialist_id;

		if( empty( $office ) ) {
			return self::set_error( 'time', __( 'Please select a office first.', 'drplus' ) );
		}
		$_SESSION['booking']['office'] = $office;

		if( empty( $time ) ) {
			return self::set_error( 'time', __( 'Please select time.', 'drplus' ) );
		}
		$_SESSION['booking']['time'] = $time;

		if( empty( $date ) ) {
			return self::set_error( 'time', __( 'Please select date.', 'drplus' ) );
		}
		$_SESSION['booking']['date'] = $date;	

		$user_id = get_current_user_id();
		if( !$user_id ) {
			return self::set_error( 'specialist', __( 'Please logged in to continue', 'drplus' ) );
		}

		$insert_book_record = empty( $_SESSION['booking']['book_id'] );
		if( !$insert_book_record ) {
			// Get book data to check prev data with current
			$book = new DBBooking( $_SESSION['booking']['book_id'] );
			if( $book->customer_id != $user_id ) {
				return self::set_error( 'specialist', __( 'You are not allowed to change this booking.', 'drplus' ) );
			}
			if(
				( $book->specialist_id != $specialist_id
				|| $book->office_id != $office
				|| $book->date != date( 'Y-m-d', $date )
				|| $book->start_time != date( "H:i", $time/1000 ) )
				&& $book->order_status == 'on-hold'
			) {
				$specialist = new Specialist( $_SESSION['booking']['specialist_id'] );
				$visit_price = 0;
				foreach( $specialist->offices as $office ) {
					if( $office->id == $_SESSION['booking']['office'] ) {
						$duration = $office->visit_time;
						$visit_price = $office->visit_price;
		
						if( $office->type == 'hospital' ) {
							$office_data = Hospital::get_options( $office->id, false, ['address'] );
							$office_name = get_the_title( $office->id );
							$office_address = $office_data['address'];
						} else {
							$office_name = $office->name;
							$office_address = $office->address ?? "";
						}
					}
				}
				if( empty( $duration ) ) {
					return self::set_error( 'time' );
				}
				$duration_timestamp = $duration * 60;
		
				$start_time = date( "H:i", $_SESSION['booking']['time']/1000 );
				$end_time = date( "H:i", $_SESSION['booking']['time']/1000 + $duration_timestamp );
				// update booking data
				$book_data = [
					'customer_id'	=> $user_id,
					'specialist_id'	=> $specialist_id,
					'office_id'		=> $_SESSION['booking']['office'],
					'date'			=> date( 'Y-m-d', $date ),
					'start_time'	=> date( "H:i", $time/1000 ),
					'end_time'		=> $end_time,
					'price'			=> $visit_price,
					'order_status'	=> 'on-hold'
				];
				$book = Booking::update( $book->book_id, $book_data );
			} else if( $book->order_status != 'on-hold' ) {
				unset( $_SESSION['booking'] );
				return self::set_error( 'specialist', __( 'This booking is already confirmed.', 'drplus' ) );
			}
		}

		if( $insert_book_record ) {
			$specialist = new Specialist( $_SESSION['booking']['specialist_id'] );
			$visit_price = 0;
			$office_name = "";
			$office_address = "";
			foreach( $specialist->offices as $office ) {
				if( $office->id == $_SESSION['booking']['office'] ) {
					$duration = $office->visit_time;
					$visit_price = $office->visit_price;
	
					if( $office->type == 'hospital' ) {
						$office_data = Hospital::get_options( $office->id, false, ['address'] );
						$office_name = get_the_title( $office->id );
						$office_address = $office_data['address'];
					} else {
						$office_name = $office->name;
						$office_address = $office->address ?? "";
					}
				}
			}
			if( empty( $duration ) ) {
				return self::set_error( 'time' );
			}
			$duration_timestamp = $duration * 60;
	
			$start_time = date( "H:i", $_SESSION['booking']['time']/1000 );
			$end_time = date( "H:i", $_SESSION['booking']['time']/1000 + $duration_timestamp );
	
			$_SESSION['booking']['office_name'] = $office_name;
			$_SESSION['booking']['office_address'] = $office_address;
			$_SESSION['booking']['specialist_name'] = $specialist->display_name;
			$_SESSION['booking']['specialist_subtitle'] = $specialist->subtitle;
			$_SESSION['booking']['price'] = $visit_price;

			$book_data = [
				'customer_id'	=> $user_id,
				'specialist_id'	=> $_SESSION['booking']['specialist_id'],
				'office_id'		=> $_SESSION['booking']['office'],
				'date'			=> date( 'Y-m-d', $_SESSION['booking']['date'] + 12600 ), // + 03:30
				'start_time'	=> "{$start_time}:00",
				'end_time'		=> "{$end_time}:00",
				'total_price'	=> $visit_price,
				'order_status'	=> 'on-hold'
			];
			$book = Booking::new( $book_data );
			if( !$book ) return self::set_error( 'time', __( 'Booking failed', 'drplus' ) );
	
			$_SESSION['booking']['book_id'] = $book;
		}

	}

	public static function info( $is_widget = false ) {
		$first_name = Utils::convert_chars( $_POST['booking_customer_first_name'] ?? "" );
		$last_name = Utils::convert_chars( $_POST['booking_customer_last_name'] ?? "" );
		$phone = Sanitizers::phone( $_POST['booking_customer_phone'] ?? "" );
		$email = Utils::convert_chars( $_POST['booking_customer_email'] ?? "" );
		$nid = Utils::convert_chars( $_POST['booking_customer_nid'] ?? "" );
		$foreign = Utils::to_bool( Utils::convert_chars( $_POST['booking_foreign_customer'] ?? false ) );
		$gender = Utils::convert_chars( $_POST['booking_customer_gender'] ?? "" );
		$gender = Utils::ensure_values_in_array( $gender, ['male', 'female'], 'male' );
		$birthday = Utils::convert_chars( $_POST['booking_customer_birthday'] ?? "", true, 'absint' );

		if( !$is_widget ) {
			$requires = ['first_name', 'last_name', 'phone', 'gender', 'birthday'];
			if( !$foreign ) $requires[] = 'nid';
	
			foreach( $requires as $require ) {
				if( empty( $$require ) ) return self::set_error( 'info' );
			}
		}

		$_SESSION['booking']['first_name'] = $first_name;
		$_SESSION['booking']['last_name'] = $last_name;
		$_SESSION['booking']['phone'] = $phone;
		$_SESSION['booking']['gender'] = $gender;
		$_SESSION['booking']['birthday'] = $birthday;
		$_SESSION['booking']['nid'] = $nid;
		$_SESSION['booking']['email'] = $email;

		// Save phone as user meta
		if( !empty( $phone ) ) {
			$user_id = get_current_user_id();
			$user_billing_phone = get_user_meta( $user_id, 'billing_phone', true );
			if( empty( $user_billing_phone ) ) {
				$user_phone = get_user_meta( $user_id, 'mobile', true );
				if( empty( $user_phone ) ) {
					$user_phone = $phone;
				}
				update_user_meta( $user_id, 'billing_phone', $user_phone );
			}
		}

		if( !$is_widget ) {
			self::payment();
		}
	}

	public static function payment() {
		// check session book data
		if( empty( $_SESSION['booking'] ) ) return self::set_error( self::$active_step );

		$requires = [
			'time'	=> ['date', 'time', 'specialist_id', 'office', 'book_id', 'office_name', 'specialist_name', 'specialist_subtitle'],
			'info'	=> ['first_name', 'last_name', 'phone', 'gender', 'birthday']
		];

		if( $_SESSION['booking']['office'] != 'consultation' ) {
			$requires['time'][] = 'office_address';
		}

		foreach( $requires as $step => $step_requires ) {
			foreach( $step_requires as $require ) {
				if( empty( $_SESSION['booking'][$require] ) ) {
					return self::set_error( $step );
				}
			}
		}
		if( !empty( $_SESSION['booking']['error'] ) ) return self::set_error( self::$active_step );


		$start_time = date( "H:i", $_SESSION['booking']['time']/1000 );

		$order_book_data = [
			'book_id'				=> $_SESSION['booking']['book_id'],
			'start_time'			=> $start_time,
			'first_name'			=> $_SESSION['booking']['first_name'],
			'last_name'				=> $_SESSION['booking']['last_name'],
			'specialist_id'			=> $_SESSION['booking']['specialist_id'],
			'specialist_name'		=> $_SESSION['booking']['specialist_name'],
			'specialist_subtitle'	=> $_SESSION['booking']['specialist_subtitle'],
			'office_id'				=> $_SESSION['booking']['office'],
			'office_name'			=> $_SESSION['booking']['office_name'],
			'office_address'		=> $_SESSION['booking']['office_address'],
			'phone'					=> $_SESSION['booking']['phone'],
			'gender'				=> $_SESSION['booking']['gender'],
			'birthday'				=> $_SESSION['booking']['birthday'],
			'nid'					=> $_SESSION['booking']['nid'],
			'email'					=> $_SESSION['booking']['email'],
			'date'					=> Date::jdate( "d F Y", $_SESSION['booking']['date'] ),
			'visit_price'			=> $_SESSION['booking']['price'],
			'raw_date'				=> $_SESSION['booking']['date'],
			'raw_time'				=> $_SESSION['booking']['time'],
		];

		$commission_data = self::calculate_booking_price( Utils::convert_chars( $_SESSION['booking']['price'], true, 'floatval' ) );
		$order_book_data['commission_value'] = $commission_data['commission_value'];
		$order_book_data['commission_calculate_type'] = $commission_data['commission_calculate_type'];
		$order_book_data['customer_paid'] = $commission_data['final_price_for_user'];
		$order_book_data['specialist_income'] = $commission_data['specialist_income'];
		
		$book_data = [
			'total_price'		=> $commission_data['final_price_for_user'],
			'commission'		=> $commission_data['commission_value'],
			'specialist_income'	=> $commission_data['specialist_income'],
		];
		Booking::update( $_SESSION['booking']['book_id'], $book_data );

		$booking_product_id = Booking::get_booking_product_id();
		WC()->cart->empty_cart();
		WC()->cart->add_to_cart( $booking_product_id, 1, 0, [], ['is_booking' => true, 'book_data' => $order_book_data] );
		WC()->session->set( 'book_data', $order_book_data );

		// redirect to wc checkout page
		wp_safe_redirect( wc_get_checkout_url() );
		exit;
	}

	public static function set_error( $step, $message = "" ) {
		$_SESSION['booking']['error'] = $step;

		if( empty( $message ) ) {
			$message = esc_html__( 'Something went wrong. please try again', 'drplus' );
		}
		$_SESSION['booking']['error_message'] = $message;

		self::check_error();
	}

	public static function check_error() {
		if( !empty( $_SESSION['booking']['error'] ) && Booking::get_current_step() != $_SESSION['booking']['error'] ) {
			$booking_url = Booking::get_booking_page_url( $_SESSION['booking']['error'] );
			wp_safe_redirect( esc_url( $booking_url ) );
			exit;
		}
	}

	public static function process_book_product( $cart ) {
		if( empty( $cart->get_cart() ) ) return;

		// Set price
		if( is_admin() && !defined('DOING_AJAX') ) return;
		$ir_currencies = [ // Array of Iranian currencies for convert to rial
			'IRR'	=> 10, // Rial
			'IRT'	=> 1, // Toman
			'IRHR'	=> 0.01, // 1000 Rial
			'IRHT'	=> 0.001, // 1000 Toman
		];

		// check if there is more than one booking product in cart
		if( count( WC()->cart->get_cart() ) > 1 ) {
			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				if( !empty( $cart_item['is_booking'] ) ) {
					WC()->cart->remove_cart_item( $cart_item_key );
				}
			}
		}

		
		// We have session data here
		foreach( $cart->get_cart() as $cart_item ) {
			if ( !empty( $cart_item['is_booking'] ) ) {

				$book_data = WC()->session->get( 'book_data' );
				if( empty( $book_data ) ) return;

				$visit_price = Utils::convert_chars( $book_data['visit_price'], true, 'floatval' );

				$woocommerce_currency = get_woocommerce_currency();
				if( $book_data['commission_calculate_type'] == 'add_to_customer_order' ) {
					$cart->add_fee( __( 'Booking commission', 'drplus' ), $book_data['commission_value'] * $ir_currencies[$woocommerce_currency], false, '' );
				}
				// Set price
				$price = $visit_price * $ir_currencies[$woocommerce_currency];
				$cart_item['data']->set_price( $price );

				// translators: 1: specialist name, 2: specialist subtitle
				$name = sprintf( __( 'Reserve time for %1$s (%2$s)', 'drplus' ), $book_data['specialist_name'], $book_data['specialist_subtitle'] );
				$cart_item['data']->set_name( $name );

			}
		}
	}

	public static function is_purchasable( $is_purchasable, $product ) {
		if( $product->get_id() == Booking::get_booking_product_id() ) {
			return true;
		}
		return $is_purchasable;
	}

	public static function update_book_item( $order_id, $old_status, $new_status, $order ) {
		$booking_product_id = Booking::get_booking_product_id();
		foreach ( $order->get_items() as $item ) {
			$product_id = $item->get_product_id();
			
            if ( $product_id == $booking_product_id ) {
				$book_id = $item->get_meta( '__book_id' );
				if( empty( $book_id ) ) return;
                Booking::update( $book_id, [
					'order_status'	=> $new_status,
					'order_id'		=> $order_id
				] );
                break;
            }
        }
	}

	public static function add_custom_meta_to_order_item( $item, $cart_item_key, $values, $order ) {
		if( !empty( $values['is_booking'] ) ) {
			$book_data = WC()->session->get( 'book_data' );
			if( empty( $book_data ) ) return;
			$item->add_meta_data( __( 'Book ID', 'drplus' ), $book_data['book_id'], true );
			$item->add_meta_data( __( 'Specialist name', 'drplus' ), sprintf( '%s (%s)', $book_data['specialist_name'] ,$book_data['specialist_subtitle'] ), true );
			$item->add_meta_data( __( 'Date', 'drplus' ), $book_data['date'], true );
			$item->add_meta_data( __( 'Time', 'drplus' ), $book_data['start_time'], true );
			if( $book_data['office_id'] == 'consultation' ) {
				$item->add_meta_data( __( 'Appointment type', 'drplus' ), esc_html__( 'Online consultation', 'drplus' ), true );
			} else {
				$item->add_meta_data( __( 'Appointment type', 'drplus' ), esc_html__( 'in-person visit', 'drplus' ), true );
				$item->add_meta_data( __( 'Office', 'drplus' ), $book_data['office_name'], true );
				$item->add_meta_data( __( 'Office Address', 'drplus' ), $book_data['office_address'], true );
			}
			$item->add_meta_data( __( 'Patient name', 'drplus' ), sprintf( '%s %s', $book_data['first_name'], $book_data['last_name'] ), true );
			$item->add_meta_data( __( 'Patient gender', 'drplus' ), $book_data['gender'] , true );
			$item->add_meta_data( __( 'Patient phone', 'drplus' ), $book_data['phone'] , true );
			$item->add_meta_data( __( 'Patient national code', 'drplus' ), $book_data['nid'] , true );
			$item->add_meta_data( __( 'Patient email', 'drplus' ), $book_data['email'] , true );
			$item->add_meta_data( '__' . __( 'Visit Price', 'drplus' ), sprintf( esc_html__( '%s Toman', 'drplus' ), number_format( $book_data['visit_price'] ), 0, '', ',' ), true );
			$item->add_meta_data( '__' . __( 'Commission', 'drplus' ), sprintf( esc_html__( '%s Toman', 'drplus' ), number_format( $book_data['commission_value'] ), 0, '', ',' ), true );
			$item->add_meta_data( '__book_id', $book_data['book_id'], true );
		}
	}

	public static function set_book_data_to_order( $order ) {
		// check is booking product
		$booking_data = WC()->session->get( 'book_data' );
		if( empty( $booking_data ) ) return;
		$order->update_meta_data( '_booking_data', $booking_data );
		
		// remove session
		WC()->session->__unset( 'book_data' );
	}

	public static function change_cart_item_name( $name, $cart_item ) {
		if( empty( $cart_item['is_booking'] ) ) return $name;

		$book_data = WC()->session->get( 'book_data' );
		if( is_checkout() ) {
			if( !empty( $book_data ) && $book_data['office_id'] == 'consultation' ) {
				$name = esc_html__( 'Consultation price', 'drplus' );
			} else {
				$name = esc_html__( 'Visit price', 'drplus' );
			}
		} else {
			if( empty( $book_data ) ) return $name;
			if( $book_data['office_id'] == 'consultation' ) {
				// translators: 1: specialist name, 2: specialist subtitle
				$name = sprintf( esc_html__( 'Consultation with %1$s (%2$s)', 'drplus' ), $book_data['specialist_name'], $book_data['specialist_subtitle'] );
			} else {
				// translators: 1: specialist name, 2: specialist subtitle
				$name = sprintf( esc_html__( 'Reserve %1$s (%2$s)', 'drplus' ), $book_data['specialist_name'], $book_data['specialist_subtitle'] );
			}
		}
		return $name;
	}

	public static function change_cart_item_price( $price, $cart_item ) {
		if( empty( $cart_item['is_booking'] ) ) return $price;
		$book_data = WC()->session->get( 'book_data' );

		$ir_currencies = [ // Array of Iranian currencies for convert to rial
			'IRR'	=> 10, // Rial
			'IRT'	=> 1, // Toman
			'IRHR'	=> 0.01, // 1000 Rial
			'IRHT'	=> 0.001, // 1000 Toman
		];
		if( empty( $book_data['book_id'] ) ) return $price;
		$woocommerce_currency = get_woocommerce_currency();
		$price = Utils::convert_chars( $book_data['visit_price'], true, 'floatval' ) * $ir_currencies[$woocommerce_currency];
		return wc_price( $price );
	}

	public static function change_cart_item_thumbnail( $thumbnail, $cart_item ) {
		if( empty( $cart_item['is_booking'] ) ) return $thumbnail;
		
		$book_data = WC()->session->get( 'book_data' );
		if( empty( $book_data['specialist_id'] ) ) return $thumbnail;

		$specialist = new Specialist( $book_data['specialist_id'] );
		$avatar_url = DRPLUS_URI . 'assets/images/user.svg';
		if( !empty( $specialist->avatar ) ) {
			$avatar_url = get_avatar_url( $specialist->user_id );
		}
		$thumbnail = "<img src='{$avatar_url}' alt=''>";
		
		return $thumbnail;
	}

	public static function unset_booking_session() {
		// start session
		if( !session_id() ) {
			session_start();
		}
		if( empty( $_SESSION['booking'] ) ) return;
		unset( $_SESSION['booking'] );
	}

	public static function calculate_booking_price( $visit_price ) {
		$visit_price = Utils::convert_chars( $visit_price, true, 'floatval' );
		$commission_settings = Options::get_options( [
			'booking-commission-type'				=> 'none',
			'booking-commission-calculate-type'		=> 'add_to_customer_order',
			'booking-commission-fixed-amount'		=> 0,
			'booking-commission-percentage-amount'	=> 0,
		] );

		$commission_value = 0;
		$final_price_for_user = $visit_price;
		$specialist_income = $visit_price;

		if( $commission_settings['booking-commission-type'] != 'none' ) {
			if( $commission_settings['booking-commission-calculate-type'] == 'add_to_customer_order' ) {
				if( $commission_settings['booking-commission-type'] == 'fixed' ) {
					$commission_value = $commission_settings['booking-commission-fixed-amount'];
					$final_price_for_user = $visit_price + $commission_value;
				} else if( $commission_settings['booking-commission-type'] == 'percentage' ) {
					$commission_value = ( $visit_price * $commission_settings['booking-commission-percentage-amount'] ) / 100;
					$final_price_for_user = $visit_price + $commission_value;
				}
			} else if( $commission_settings['booking-commission-calculate-type'] == 'deduction_from_specialist_income' ) {
				if( $commission_settings['booking-commission-type'] == 'fixed' ) {
					$specialist_income = $visit_price - $commission_settings['booking-commission-fixed-amount'];
				} else if( $commission_settings['booking-commission-type'] == 'percentage' ) {
					$specialist_income = ( 100 - $commission_settings['booking-commission-percentage-amount'] ) * ( $visit_price / 100 );
				}
			}
		}

		return [
			'final_price_for_user' 		=> $final_price_for_user,
			'specialist_income'        	=> $specialist_income,
			'commission_value'     		=> $commission_value,
			'commission_type'      		=> $commission_settings['booking-commission-type'],
			'commission_calculate_type' => $commission_settings['booking-commission-calculate-type'],
		];
	}

	public static function apply_specialist_income( $order_id ) {
		
	}

	public static function wc_checkout_unset_field_in_booking_order( $fields ) {
		foreach( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			if( !empty( $cart_item['is_booking'] ) ) {
				$fields = Utils::unset( $fields, ['billing', 'shipping', 'order'] );
				return $fields;
			}
		};
		return $fields;
	}

	public static function wc_checkout_show_book_data() {
		// Get booking data
		$book_data = WC()->session->get( 'book_data' );
		if( empty( $book_data ) ) return;

		get_template_part( "templates/booking/template-booking-step", 'checkout', [
			'book_data'		=> $book_data,
		] );
	}

	public static function wc_checkout_edit_pay_button_text( $text ) {
		$book_data = WC()->session->get( 'book_data' );
		if( empty( $book_data ) ) $text = esc_html__( 'Submit appointment', 'drplus' );
		return $text;
	}

	public static function remove_pwc_checkout_validation() {
		if(class_exists( 'PW_Tools_General' ) ) {
			// Remove phone validation
			$instance_PW_Tools_General = new \PW_Tools_General;
			remove_action( 'woocommerce_after_checkout_validation', [ $instance_PW_Tools_General, 'validate_phone' ], 10 );
		}
	}
}
add_action( 'template_redirect', [SaveBookingProcess::class, 'save_step'] );
add_filter( 'woocommerce_before_calculate_totals', [SaveBookingProcess::class, 'process_book_product'], 10, 1 );
add_filter( 'woocommerce_is_purchasable', [SaveBookingProcess::class, 'is_purchasable'], 10, 2 );
add_action( 'woocommerce_order_status_changed', [SaveBookingProcess::class, 'update_book_item'], 10, 4 );
add_action( 'woocommerce_checkout_create_order_line_item', [SaveBookingProcess::class, 'add_custom_meta_to_order_item'], 10, 4 );
add_filter( 'woocommerce_cart_item_name', [SaveBookingProcess::class, 'change_cart_item_name'], 10, 2 );
add_filter( 'woocommerce_cart_item_price', [SaveBookingProcess::class, 'change_cart_item_price'], 10, 2 );
add_filter( 'woocommerce_cart_item_thumbnail', [SaveBookingProcess::class, 'change_cart_item_thumbnail'], 10, 2 );
add_filter( 'woocommerce_thankyou', [SaveBookingProcess::class, 'unset_booking_session'], 10, 2 );
add_action( 'woocommerce_order_status_completed', [SaveBookingProcess::class, 'apply_specialist_income'], 10, 2 );
add_action( 'woocommerce_checkout_create_order', [SaveBookingProcess::class, 'set_book_data_to_order'], 10, 3 );
add_filter( 'woocommerce_checkout_fields', [SaveBookingProcess::class, 'wc_checkout_unset_field_in_booking_order'], 10, 1 );
add_action( 'drplus/booking/checkout/before_form', [SaveBookingProcess::class, 'wc_checkout_show_book_data'], 10 );
add_filter( 'woocommerce_order_button_text', [SaveBookingProcess::class, 'wc_checkout_edit_pay_button_text'], 10, 2 );
add_action( 'drplus/booking/checkout/before_form', [SaveBookingProcess::class, 'remove_pwc_checkout_validation'], 10 );