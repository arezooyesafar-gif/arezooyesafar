<?php

use DrPlus\Components\Button;
use DrPlus\Components\SectionTitle;
use DrPlus\DB;
use DrPlus\Specialist;

use DrPlus\Utils;
use DrPlus\Utils\Booking;
use DrPlus\Utils\Elementor;
use DrPlus\Utils\Hospital;
use DrPlus\Utils\Options;
use DrPlus\Utils\Sanitizers;
use DrPlus\Utils\SpecialistSpecialitiesRel;
use DrPlus\Utils\UI;
use DrPlus\Utils\UtilsSpecialists;

if( !defined( 'ABSPATH' ) ) exit;

$prefix = "specialist_";
$primary_classes = ['content-area', 'content-area-empty', 'site-content'];

$options = Options::get_options( [
	'single_specialist_title_tag'							=> 'h1',
	'single_specialist_subtitle_tag'						=> 'h2',
	'single_specialist_sections_tag'						=> 'h3',
	'single_specialist_show_breadcrumb'						=> true,
	'single_specialist_show_reviews'						=> true,
	'single_specialist_show_reviews_count'					=> true,
	'single_specialist_show_specialist_code'				=> true,
	'single_specialist_show_reserve_btn'					=> true,
	'single_specialist_show_services'						=> true,
	'single_specialist_show_insurances'						=> true,
	'single_specialist_show_offices'						=> true,
	'single_specialist_show_stats'							=> true,
	'single_specialist_show_introduction'					=> true,
	'single_specialist_show_certificates'					=> true,
	'single_specialist_show_faqs'							=> true,
	'single_specialist_show_related_specialists'			=> true,
	'specialist-code-label'									=> esc_html__( 'Medical system number', 'drplus' ),
	'single_specialist_not_available_reserve_text'			=> esc_html__( 'Online appointment booking is not yet available for {name}', 'drplus' ),
	'single_specialist_related_specialists_name_tag'		=> 'h3',
	'single_specialist_related_specialists_short_bio_tag'	=> 'div',
	'single_specialist_related_specialists_verified_text'	=> sprintf( esc_html__( 'Verified by %s', 'drplus' ), get_bloginfo( 'name' ) ),
] );

$post_classes = ['entry-content', $prefix . "article"];

get_header();

while ( have_posts() ) :
	the_post();
	$specialist_id = get_post_meta( get_the_ID(), '_drplus_specialist_id', true );
	$specialist = new Specialist( $specialist_id );
	if( empty( $specialist ) ) {
		wp_redirect( home_url() ); die;
	}

	$avatar_url = DRPLUS_URI . 'assets/images/user.svg';
	if( !empty( $specialist->avatar ) ) {
		$avatar_url = get_avatar_url( $specialist->user_id, [
			'size'	=> 132
		] );
	}

	if( Utils::to_bool( $options['single_specialist_show_stats'] ) ) {
		if( comments_open() ) {
			$comments = get_comments( [
				'fields'		=> 'ids',
				'post_id'		=> get_the_ID(),
				'meta_key'		=> '_drplus_patient_review',
				'meta_value'	=> true,
				'status'		=> 'approve',
			] );
			$comments_count = count( $comments );
			$full_avg_score = Utils::get_post_avg( get_the_ID(), false, $comments_count );
		}
		$appointments_number = Booking::get_specialist_appointments_count( $specialist->ID );
		$stats = [
			'patients_review'	=> [
				'title'	=> esc_html__( 'Patient satisfaction', 'drplus' ),
				'value'	=> round( $full_avg_score/5*100 ) . "%",
				'icon'	=> 'drplus-icon-like'
			],
			'visits_count'		=> [
				'title'	=> esc_html__( 'Visits count', 'drplus' ),
				'value'	=> sprintf( esc_html__( '%s people', 'drplus' ), number_format_i18n( $appointments_number, 0 ) ),
				'icon'	=> 'drplus-icon-user-check'
			],
			'articles'			=> [
				'title'	=> esc_html__( 'Number of articles', 'drplus' ),
				'value'	=> number_format_i18n( $specialist->articles, 0 ) . ( $specialist->articles > 0 ? "+" : '' ),
				'icon'	=> 'drplus-icon-document-text'
			]
		];
		if( !comments_open() ) {
			unset( $stats['patients_review'] );
		}
	}
	if( Utils::to_bool( $options['single_specialist_show_faqs'] ) && !empty( $specialist->faqs ) ) {
		$faqs = [];
		foreach( $specialist->faqs as $faq ) {
			if( empty( $faq['question'] ) || empty( $faq['answer'] ) ) continue;
			$faqs[] = [
				'title'	=> $faq['question'],
				'text'	=> $faq['answer'],
			];
		}
	}
	if( Utils::to_bool( $options['single_specialist_show_related_specialists'] ) ) {
		if( !empty( $specialist->specialities ) ) {
			$speciality_id_placeholder = DB::placeholder( $specialist->specialities, '%d' );
			$related_where['AND'] = [
				'`user_id`!=%d'	=> $specialist->user_id,
				"`speciality_id` IN ({$speciality_id_placeholder})" => $specialist->specialities,
			];
			$db_related_specialists = SpecialistSpecialitiesRel::find( $related_where );
		}
		$related_specialists = [];

		if( !empty( $db_related_specialists ) ) {
			$related_specialists_user_id = array_map( fn($sp) => $sp['user_id'], $db_related_specialists );
			$related_specialists_user_id = array_slice( array_unique( $related_specialists_user_id ), 0, 8 );
			foreach( $related_specialists_user_id as $related_specialist_user_id ) {
				$related_specialists[] = new Specialist( null, $related_specialist_user_id );
			}
		}
	}

	// Get specialities name
	$specialities = get_posts( [
		'include'	=> $specialist->specialities,
		'post_type'	=> 'speciality'
	] );

	// Create schema for the specialist
	$specialist_schema = [
		"@context"	=> "https://schema.org",
		"@type"		=> "Physician",
		"name"		=> esc_js( $specialist->display_name ),
		"subtitle"	=> esc_js( $specialist->subtitle ),
		"specialty"	=> implode(', ', wp_list_pluck( $specialities, 'post_title' )),
	];

	if( !empty( $specialist->avatar ) ) {
		$specialist_schema['image'] = $avatar_url;
	}

	// Add schema for services
	$services = [];
	$services_schema = [];
	if( Utils::to_bool( $options['single_specialist_show_services'] ) && !empty( $specialist->services ) ) {
		foreach( $specialist->services as $service ) {
			$services_schema[] = [
				"@type" => "Service",
				"name" => esc_js( $service['title'] ),
				"description" => esc_js( $service['desc'] ),
			];
		}
		$specialist_schema['offers'] = wp_json_encode( $services_schema );
	}

	// Add schema for office locations
	$offices_schema = [];
	$specialist_offices = [];
	if( Utils::to_bool( $options['single_specialist_show_offices'] ) && !empty( $specialist->offices ) ) {
		foreach( $specialist->offices as $office ) {
			if( $office->type == 'consultation' ) continue;
			if( $office->type == 'hospital' ) {
				$hospital_settings = Hospital::get_options( $office->id );
				$office->name = get_the_title( $office->id );
				$office->phone = $hospital_settings['phones'][0]['phone'] ?? "";
				$office->address = $hospital_settings['address'];
				$office->map_url = $hospital_settings['map_address'];
				$office->image = get_the_post_thumbnail_url( $office->id );
			} else {
				$office->image = wp_get_attachment_image_url( $office->image );
			}
			if( empty( $office->image ) ) {
				$office->image = DRPLUS_URI . 'assets/images/hospital-placeholder.webp';
			}
			$specialist_offices[] = $office;
			$offices_schema[] = [
				"@type"		=> "Place",
				"name"		=> $office->name,
				"address"	=> [
					"@type"				=> "PostalAddress",
					"streetAddress"		=> $office->address,
					"addressLocality"	=> $office->city ?? 'Tehran', // Modify as needed
					"addressCountry"	=> "IR",
				],
				"telephone"	=> $office->phone,
			];
			if( empty( $specialist_schema['hasMap'] ) && !empty( $office->map_url ) ) {
				$specialist_schema['hasMap'] = $office->map_url;
			}
			if( empty( $specialist_schema['telephone'] ) && !empty( $office->phone ) ) {
				$specialist_schema['telephone'] = $office->phone;
			}
		}
		$specialist_schema['address'] = wp_json_encode( $offices_schema );
	}

	// Add schema for FAQs
	$faqs_schema = [];
	if( Utils::to_bool( $options['single_specialist_show_faqs'] ) && !empty( $specialist->faqs ) ) {
		foreach( $specialist->faqs as $faq ) {
			$faqs_schema[] = [
				"@type"				=> "Question",
				"name"				=> $faq['question'],
				"acceptedAnswer"	=> [
					"@type"			=> "Answer",
					"text"			=> $faq['answer'],
				],
			];
		}
		$specialist_schema['faqPage'] = [
			"@type"			=> "FAQPage",
			"mainEntity"	=> wp_json_encode( $faqs_schema )
		];
	}

	?>
	<div id="page-body" class="page-width">
		<main id="page-main">
			
			<?php
			if( Utils::to_bool( $options['single_specialist_show_breadcrumb'] ) ) {
				drplus_breadcrumb();
			}
			?>

			<div id="primary" <?php echo Utils::prepare_html_classes( $primary_classes, true ) ?>>
				<div id="post-content" class="row">
					<div class="entry-container col-12">
						<div id="page-content" class="site-content single" role="main">
							<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?> aria-labelledby="<?php echo $prefix ?>name" itemscope itemtype="https://schema.org/Person">
								<div class="<?php echo $prefix ?>sidebar">
									<section class="<?php echo $prefix ?>bio <?php echo $prefix ?>section" role="region" aria-label="<?php printf( __( 'Information of %s', 'drplus' ), $specialist->display_name ) ?>">
										<div class="<?php echo $prefix ?>avatar-wrap">
											<img src="<?php echo $avatar_url ?>" class="<?php echo $prefix ?>avatar" alt="<?php echo esc_attr( $specialist->display_name ) ?>" role="presentation" itemprop="image">
										</div>
										<<?php echo $options['single_specialist_title_tag'] ?> class="<?php echo $prefix ?>name" itemprop="name"><?php echo esc_html( $specialist->display_name ) ?></<?php echo $options['single_specialist_title_tag'] ?>>
										<?php
										if( comments_open() ) {
											$avg_score = Utils::get_post_avg( 0, 1, $comments_count );
											?>
											<div class="<?php echo $prefix ?>sidebar-comments-wrap">
												<?php UI::stars( absint( $avg_score ), 5 ) ?>
												<div class="sidebar-comments-count"><?php echo $comments_count == 0 ? esc_html__( "No comment", 'drplus' ) : sprintf( esc_html__( "%d comments", 'drplus' ), $comments_count ) ?></div>
											</div>
											<?php
										}
										?>
										<<?php echo $options['single_specialist_subtitle_tag'] ?> class="<?php echo $prefix ?>subtitle"><?php echo esc_html( $specialist->subtitle ) ?></<?php echo $options['single_specialist_subtitle_tag'] ?>>
										<?php if( Utils::to_bool( $options['single_specialist_show_specialist_code'] ) ) { ?>
											<div class="<?php echo $prefix ?>code-wrap">
												<?php if( $specialist->is_verified ) { ?>
													<i class="<?php echo $prefix ?>verified-icon drplus-icon-verify-fill"></i>
													<span class="screen-reader-text"><?php esc_html_e( 'Verified specialist', 'drplus' ) ?></span>
												<?php } ?>
												<span class="<?php echo $prefix ?>code"><?php printf( '%s: %s', $options['specialist-code-label'], !empty( $specialist->specialist_code ) ? $specialist->specialist_code : esc_html__( 'Unknown', 'drplus' ) ) ?></span>
											</div>											
										<?php } ?>
										<?php if( Utils::to_bool( $options['single_specialist_show_reserve_btn'] ) ) { ?>
											<div class="<?php echo $prefix ?>booking">
												<?php if( ( Utils::to_bool( $specialist->offline_visit ) || Utils::to_bool( $specialist->online_visit ) ) && Booking::is_booking_active() ) { ?>
													<?php if( Utils::to_bool( $specialist->offline_visit ) ) {
														Button::view( [
															'icon'			=> 'drplus-icon-arrow-up-left-square',
															'text'			=> esc_html__( 'Book an appointment', 'drplus' ),
															'title'			=> esc_html__( 'Book an appointment', 'drplus' ),
															'align'			=> 'center',
															'icon_align'	=> 'end',
															'fullwidth'		=> true,
															'id'			=> $prefix . "booking-btn",
															'link'			=> Booking::get_booking_page_url( 'time?sid=' . $specialist->ID ),
															'atts'			=> [
																'aria_label'	=> esc_html__( 'Book an appointment with ' . $specialist->display_name, 'drplus' )
															]
														] );
													} ?>
													<?php if( Utils::to_bool( $specialist->online_visit ) ) {
														Button::view( [
															'icon'			=> 'drplus-icon-arrow-up-left-square',
															'text'			=> esc_html__( 'Consultation appointment', 'drplus' ),
															'title'			=> esc_html__( 'Consultation appointment', 'drplus' ),
															'align'			=> 'center',
															'icon_align'	=> 'end',
															'fullwidth'		=> true,
															'type'			=> 'bordered',
															'id'			=> $prefix . "consultation-btn",
															'link'			=> add_query_arg( ['sid' => $specialist->ID, 'consultation' => 1], Booking::get_booking_page_url( 'time' ) ),
															'atts'			=> [
																'aria_label'	=> esc_html__( 'Book an appointment for online consultation with ' . $specialist->display_name, 'drplus' )
															]
														] );
													} ?>									
												<?php } else { ?>
													<p class="<?php echo $prefix ?>not-available-reserve"><?php echo str_replace( '{name}', $specialist->display_name, $options['single_specialist_not_available_reserve_text'] ) ?></p>
												<?php } ?>
											</div>							
										<?php } ?>
									</section>
									<?php if( Utils::to_bool( $options['single_specialist_show_services'] ) && !empty( $specialist->services ) ) { ?>
										<section class="<?php echo $prefix ?>section <?php echo $prefix ?>services" role="region" aria-label="<?php printf( esc_html__( 'Specialized services of %s', 'drplus' ), $specialist->display_name ) ?>">
											<?php SectionTitle::view( [
												'icon'		=> 'drplus-icon-mental-health',
												'tag'		=> $options['single_specialist_sections_tag'],
												'title'		=> sprintf( esc_html__( 'Specialized services of %s', 'drplus' ), $specialist->display_name ),
												'classes'	=> [$prefix . "side-section-title"]
											] ); ?>
											<?php foreach( $specialist->services as $service ) { ?>
												<div class="<?php echo $prefix ?>service">
													<?php SectionTitle::view( [
														'icon'			=> 'drplus-icon-diamond',
														'icon_has_bg'	=> false,
														'tag'			=> 'span',
														'title'			=> esc_html( $service['title'] ),
														'classes'		=> [$prefix . "service-title"]
													] ); ?>
													<?php if( !empty( $service['desc'] ) ) { ?>
														<span class="<?php echo $prefix ?>service-desc"><?php echo esc_html( $service['desc'] ) ?></span>
													<?php } ?>
												</div>
											<?php } ?>
										</section>
									<?php } ?>
									<?php if( Utils::to_bool( $options['single_specialist_show_insurances'] ) && !empty( $specialist->insurances ) ) { ?>								
										<section class="<?php echo $prefix ?>section <?php echo $prefix ?>insurances" role="complementary" aria-label="<?php echo esc_html__( 'Covered insurances', 'drplus' ) ?>">
											<?php SectionTitle::view( [
												'icon'		=> 'drplus-icon-archive-book-bold',
												'tag'		=> $options['single_specialist_sections_tag'],
												'title'		=> esc_html__( 'Covered insurances', 'drplus' ),
												'classes'	=> [$prefix . "side-section-title"]
											] ); ?>
											<div class="<?php echo $prefix ?>insurances-list">
												<?php foreach( $specialist->insurances as $insurance ) { ?>
													<?php
													$insurance_term = get_term( $insurance, 'insurance' );
													$insurance_icon = get_term_meta( $insurance, 'icon', true );
													?>
													<div class="<?php echo $prefix ?>insurance">
														<?php if( !empty( $insurance_icon ) ) { ?>
															<i class="<?php echo esc_attr( $insurance_icon ) ?> <?php echo $prefix ?>insurance-icon"></i>
														<?php } ?>
														<span class="<?php echo $prefix ?>insurance-name"><?php echo esc_html( $insurance_term->name ) ?></span>
													</div>
												<?php } ?>
											</div>
										</section>
									<?php } ?>
									<?php if( Utils::to_bool( $options['single_specialist_show_offices'] ) && !empty( $specialist_offices ) ) { ?>								
										<section class="<?php echo $prefix ?>section <?php echo $prefix ?>offices" role="complementary" aria-label="<?php sprintf( esc_html__( 'Clinic address of %s', 'drplus' ), $specialist->display_name ) ?>">
											<?php SectionTitle::view( [
												'icon'		=> 'drplus-icon-location-fill',
												'tag'		=> $options['single_specialist_sections_tag'],
												'title'		=> sprintf( esc_html__( 'Clinic address of %s', 'drplus' ), $specialist->display_name ),
												'classes'	=> [$prefix . "side-section-title"]
											] ); ?>
											<div class="<?php echo $prefix ?>offices-list">
												<?php foreach( $specialist_offices as $office ) { ?>
													<div class="<?php echo $prefix ?>office">
														<div class="<?php echo $prefix ?>office-head">
															<div class="<?php echo $prefix ?>office-img-wrap">
																<img src="<?php echo $office->image ?>" class="<?php echo $prefix ?>office-img" alt="<?php echo esc_attr( $office->name ) ?>">
															</div>
															<div class="<?php echo $prefix ?>office-info">																
																<div class="<?php echo $prefix ?>office-name-wrap">
																	<?php if( $office->type == 'hospital' ) { ?>
																		<a href="<?php echo get_permalink( $office->id ) ?>" class="<?php echo $prefix ?>office-link" title="<?php echo esc_attr( $office->name ) ?>">
																			<span class="<?php echo $prefix ?>office-name line-clamp line-clamp-1"><?php echo esc_html( $office->name ) ?></span>
																			<i class="drplus-icon-square-arrow-right"></i>
																		</a>
																	<?php } else { ?>
																		<span class="<?php echo $prefix ?>office-name"><?php echo esc_html( $office->name ) ?></span>
																	<?php } ?>
																</div>
																<?php if( !empty( $office->phone ) ) { ?>
																	<a href="tel:<?php echo $office->phone ?>" class="<?php echo $prefix ?>office-phone">
																		<i class="drplus-icon-calling"></i>
																		<?php echo esc_html( $office->phone ) ?>
																	</a>
																<?php } ?>
															</div>
														</div>
														<?php if( !empty( $office->address || !empty( $office->map_url ) ) ) { ?>
															<div class="<?php echo $prefix ?>office-address-wrap">
																<?php if( !empty( $office->address ) ) { ?>
																	<p class="<?php echo $prefix ?>office-address"><?php echo esc_html( $office->address ) ?></p>
																<?php } ?>
																<?php if( !empty( $office->map_url ) ) { ?>
																	<a href="<?php echo esc_url( $office->map_url ) ?>" class="<?php echo $prefix ?>office-map" target="_blank" title="<?php echo esc_attr( $office->name ) ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Show %s on the map', 'drplus' ), $office->name ) ) ?>">
																		<i class="drplus-icon-routing"></i>
																		<?php esc_html_e( 'Show on the map', 'drplus' ) ?>
																	</a>
																<?php } ?>
															</div>													
														<?php } ?>
													</div>
												<?php } ?>
											</div>
										</section>
									<?php } ?>
								</div>
								<div class="<?php echo $prefix ?>main_section">
									<?php if( Utils::to_bool( $options['single_specialist_show_stats'] ) ) { ?>
										<section class="<?php echo $prefix ?>stats" role="region" aria-label="<?php printf( esc_html__( 'Stats of %s', 'drplus' ), $specialist->display_name ) ?>">
											<<?php echo tag_escape( $options['single_specialist_sections_tag'] ) ?> class="screen-reader-text">
												<?php printf( esc_html__( 'Stats of %s', 'drplus' ), $specialist->display_name ) ?>
											</<?php echo tag_escape( $options['single_specialist_sections_tag'] ) ?>>
											<?php foreach( $stats as $stat ) { ?>
												<div class="<?php echo $prefix ?>stat">
													<div class="<?php echo $prefix ?>stat-data">
														<span class="<?php echo $prefix ?>stat-title"><?php echo esc_html( $stat['title'] ) ?></span>
														<span class="<?php echo $prefix ?>stat-value"><?php echo esc_html( $stat['value'] ) ?></span>
													</div>
													<?php echo Sanitizers::icon( $stat['icon'], "{$prefix}stat-icon" ) ?>
												</div>
											<?php } ?>
										</section>
									<?php } ?>
									<?php if( Utils::to_bool( $options['single_specialist_show_introduction'] ) && !empty( $specialist->about ) ) { ?>
										<section class="<?php echo $prefix ?>section <?php echo $prefix ?>introduction" role="region" aria-label="<?php echo esc_html__( 'Introduction and Speciality', 'drplus' ) ?>" itemprop="description">
											<?php SectionTitle::view( [
												'icon'		=> 'drplus-icon-stethoscope',
												'tag'		=> $options['single_specialist_sections_tag'],
												'title'		=> esc_html__( 'Introduction and Speciality', 'drplus' ),
												'classes'	=> [$prefix . "section-title"]
											] ); ?>
											<div class="<?php echo $prefix ?>about-wrap">
												<?php echo wpautop( $specialist->about, true ) ?>
											</div>
										</section>										
									<?php } ?>
									<?php if( Utils::to_bool( $options['single_specialist_show_certificates'] ) && !empty( $specialist->certificates ) ) { ?>										
										<section class="<?php echo $prefix ?>section <?php echo $prefix ?>certificates" role="complementary" aria-label="<?php echo esc_html__( 'Certificates and Courses', 'drplus' ) ?>">
											<?php SectionTitle::view( [
												'icon'		=> 'drplus-icon-personalcard-bold',
												'tag'		=> $options['single_specialist_sections_tag'],
												'title'		=> esc_html__( 'Certificates and Courses', 'drplus' ),
												'classes'	=> [$prefix . "section-title"]
											] ); ?>
											<ul class="<?php echo $prefix ?>certificates-list">
												<?php foreach( $specialist->certificates as $certificate ) { ?>
													<li class="<?php echo $prefix ?>certificate-item"><?php echo esc_html( $certificate['title'] ) ?></li>	
												<?php } ?>
											</ul>
											<div class="<?php echo $prefix ?>certificates-verified">
												<i class="drplus-icon-verify-fill"></i>
												<span class="<?php echo $prefix ?>certificates-verified-text">
													<?php printf( esc_html__( "All of %s's credentials have been verified by %s.", 'drplus' ), $specialist->display_name, get_bloginfo( 'name' ) ) ?>
												</span>
											</div>
										</section>
									<?php } ?>
									<?php if( Utils::to_bool( $options['single_specialist_show_faqs'] ) && !empty( $faqs ) ) { ?>									
										<section class="<?php echo $prefix ?>section <?php echo $prefix ?>faqs" role="region" aria-label="<?php echo esc_html__( 'Frequently Asked Questions (FAQs)', 'drplus' ) ?>">
											<?php SectionTitle::view( [
												'icon'		=> 'drplus-icon-faq',
												'tag'		=> $options['single_specialist_sections_tag'],
												'title'		=> esc_html__( 'Frequently Asked Questions (FAQs)', 'drplus' ),
												'classes'	=> [$prefix . "side-section-title"]
											] ); ?>
											<div class="<?php echo $prefix ?>faqs-list">
												<?php get_template_part( "templates/components/template-components-accordion", null, [
													'items'			=> array_slice( $faqs, 0, round( count( $faqs ) / 2 ) ),
													'title_tag'		=> 'span',
													'faq_schema'	=> false,
												] ); ?>
												<?php get_template_part( "templates/components/template-components-accordion", null, [
													'items'			=> array_slice( $faqs, round( count( $faqs ) / 2 ) ),
													'title_tag'		=> 'span',
													'faq_schema'	=> false,
												] ); ?>
											</div>
										</section>
									<?php } ?>
									<?php if( Utils::to_bool( $options['single_specialist_show_reviews'] ) && comments_open() ) { ?>									
										<section class="<?php echo $prefix ?>reviews" role="region" aria-label="<?php echo esc_html_e( 'User reviews', 'drplus' ) ?>">
											<?php comments_template(); ?>
										</section>
									<?php } ?>
								</div>
							</article>
						</div>
					</div>
				</div>
				<?php if( !empty( $related_specialists ) ) {
					$devices = ['desktop', 'tablet', 'mobile'];
					$display_settings = [
						'style'					=> 'card-1',
						'desktop_slider'		=> true,
						'desktop_cols'			=> 5,
						'desktop_slides_type'	=> 'auto',
						'desktop_slides_space'	=> 16,
						'tablet_slider'			=> true,
						'tablet_cols'			=> 3,
						'tablet_slides_type'	=> 'auto',
						'tablet_slides_space'	=> 16,
						'mobile_slides_type'	=> 'auto',
						'mobile_slider'			=> true,
						'mobile_cols'			=> 1,
						'mobile_slides_space'	=> 16,

						'name-tag'		=> $options['single_specialist_related_specialists_name_tag'],
						'short_bio-tag'	=> $options['single_specialist_related_specialists_short_bio_tag'],
						'verified-text'	=> $options['single_specialist_related_specialists_verified_text'],
					];
					$display_attributes = Elementor::get_display_attributes( $display_settings );
					$attributes = [
						'class'	=> array_merge( [
							'drplus-slider-wrap',
							$prefix . 'related-specialists-slider-wrap',
							$prefix . "related-specialists",
							$prefix . "related-specialists-wrap",
						], $display_attributes['wrap_classes'] ),
						'data-settings'	=> $display_attributes['args'],
						'style'			=> $display_attributes['style'],
					];
					?>
					<div <?php echo Utils::get_html_attributes( $attributes ) ?>>
						<div class="drplus-slider-head <?php echo $prefix ?>related-specialists-slider-head">
							<?php
							SectionTitle::view( [
								'icon'		=> 'drplus-icon-stethoscope',
								'tag'		=> $options['single_specialist_sections_tag'],
								'title'		=> esc_html__( 'Related Specialists', 'drplus' ),
								'classes'	=> [$prefix . "section-title"],
								'nav_btns'	=> true,
							] );							
							?>
						</div>
						<?php UtilsSpecialists::list( $display_settings, 'offline_visits', $related_specialists ) ?>
					</div>
					<?php
				} ?>
				
			</div>
		</main>
		<script type="application/ld+json"><?php echo wp_json_encode( $specialist_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ?></script>
	</div>
	<?php
endwhile;

get_footer();