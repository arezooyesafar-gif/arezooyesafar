<?php

use DrPlus\Utils;
use DrPlus\Utils\Search;

if( !function_exists( "drplus_hospitals_city_filter" ) ) {
	function drplus_hospitals_city_filter( $query ) {
		if( is_admin() || $query->get( 'post_type' ) != 'hospital' ) return;
		$city = Search::get_city_from_GET();
		if( !$city ) return;

		$meta_query = $query->get( 'meta_query' );
		if( !is_array( $meta_query ) ) {
			$meta_query = [];
		}
		if( $query->get( 'meta_key' ) ) {
			$custom_meta_args = [
				'key'	=> $query->get( 'meta_key' ),
			];
			if( $query->get( 'meta_value' ) !== null ) {
				$custom_meta_args['value'] = $query->get( 'meta_value' );
			}
			if( $query->get( 'meta_compare' ) !== null ) {
				$custom_meta_args['compare'] = $query->get( 'meta_compare' );
			}
			$meta_query[] = $custom_meta_args;
		}
		$meta_query[] = [
			'key'	=> '_city',
			'value'	=> $city
		];
		$query->set( 'meta_query', $meta_query );
	}
}
add_action( 'pre_get_posts', 'drplus_hospitals_city_filter' );