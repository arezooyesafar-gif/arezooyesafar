<?php

use DrPlus\Components\Alert;
use DrPlus\Components\Button;
use DrPlus\Components\Loading;
use DrPlus\Components\SectionTitle;
use DrPlus\Utils;
use DrPlus\Utils\Booking;
use DrPlus\Utils\Options;

$specialist = Booking::get_specialist();
if( !$specialist ) {
	return; // Exit from file
}

if( empty( $specialist->offices ) ) {
	Alert::view( [
		'type'	=> 'warning',
		'icon'	=> 'drplus-icon-error',
		'text'	=> sprintf( esc_html__( '%s has not registered any offices for appointment booking.', 'drplus' ), $specialist->display_name ),
		'classes'	=> ['booking-alert']
	] );
	// Get prev page url
	$prev_page_url = wp_get_referer();
	if( empty( $prev_page_url ) ) {
		$prev_page_url = Booking::get_booking_page_url();
	}
	Button::view( [
		'text'		=> esc_html__( 'Return to previous page', 'drplus' ),
		'link'		=> esc_url( $prev_page_url ),
		'type'		=> 'bordered',
		'align' 	=> 'center',
	] );
	return;
}

$options = Options::get_options( [
	'booking-time-section-title'	=> esc_html__( 'Select visit time', 'drplus' ),
	'booking-time-section-icon'	=> 'drplus-icon-clock-fill'
] );

// Set first office as main as temp
$main_office_id = $specialist->offices[0]->id;

$show_only_consultation_office = false;
if( !empty( $_GET['consultation'] ) && Utils::to_bool( $_GET['consultation'] ) && $specialist->online_visit ) {
	$show_only_consultation_office = true;
	$main_office_id = 'consultation';
}

// Get offices available days
$offices_off_days = [];
foreach( $specialist->offices as $office ) {
	if( $show_only_consultation_office && $office->id != 'consultation' ) continue;
	$off_days = [];
	if( Utils::to_bool( $office->main ) ) $main_office_id = $office->id;
	$office_time = Booking::get_times_by_office( $office->id, $specialist );
	foreach( $office_time['days'] as $day ) {
		if( empty( $day['times'] ) || !Utils::to_bool( $day['status'] ) ) $off_days[] = $day['day'];
	}
	sort($off_days);
	$offices_off_days[$office->id] = $off_days;
}

// Set nearest date for main office
$now = new \DateTime();
// Adjust the weekday index to start from Saturday
$current_day_index = ((int)$now->format('w') + 7) % 7;

$nearest_date_timestamps = [];
foreach( $specialist->offices as $office ) {
	if( $show_only_consultation_office && $office->id != 'consultation' ) continue;
	$nearest_date = null;
	for( $day_index = 0; $day_index <= 6; $day_index++ ) {
		if( in_array( $day_index, $offices_off_days[$office->id] ) ) continue;
		// Calculate days until the next occurrence of the target day
		$days_until_next = ($day_index - $current_day_index + 7) % 7;
		$next_date = clone $now;
		$next_date->modify("+$days_until_next days");
	
		// Set the nearest date if it's null or if we find a closer date
		if ($nearest_date === null || $next_date < $nearest_date) {
			$nearest_date = $next_date;
		}
	}
	
	if( $nearest_date === null ) {
		$nearest_date_timestamp = "";
	} else {
		// Return timestamp of the nearest date
		$nearest_date_timestamp = $nearest_date->getTimestamp() - 12600;
	}
	$nearest_date_timestamps[$office->id] = $nearest_date_timestamp;
}

wp_localize_script( 'drplus-booking', 'drplusBooking', [
	'specialistID'			=> $specialist->ID,
	'mainOffice'			=> $main_office_id,
	'offDays'				=> $offices_off_days,
	'chunkTimes'			=> wp_list_pluck( $specialist->offices, 'visit_time', 'id' ),
	'nearestDateTimestamps'	=> $nearest_date_timestamps
] );


$specialist_id = Utils::convert_chars( $_GET['sid'] ?? 0, true, 'absint' );
if( empty( $specialist_id ) && !empty( $_SESSION['booking']['specialist_id'] ) ) {
	$specialist_id = $_SESSION['booking']['specialist_id'];
}

$selected_office_id = !empty( $_SESSION['booking']['office'] ) ? $_SESSION['booking']['office'] : $main_office_id;

?>
<input type="hidden" name="booking_specialist_id" value="<?php echo $specialist_id ?>">
<div class="booking-section booking-specialist-offices-section">
	<?php Booking::specialist_info_html( $specialist ) ?>
	<div class="booking-specialist-offices">
		<?php foreach( $specialist->offices as $office ) { ?>
			<?php if( $show_only_consultation_office && $office->id != 'consultation' ) continue; ?>
			<?php if( $office->id == 'consultation' ) {
				$office->image = DRPLUS_URI . 'assets/images/online-consultation.webp';
			} ?>
			<label for="booking_office_<?php echo esc_attr( $office->id ) ?>" class="booking-specialist-office-wrap">
				<input type="radio" name="booking_office" id="booking_office_<?php echo esc_attr( $office->id ) ?>" class="booking-specialist-office-radio" value="<?php echo esc_attr( $office->id ) ?>" <?php checked( $office->id, $selected_office_id ) ?>>
				<?php Booking::specialist_office_html( $office ); ?>
			</label>
		<?php } ?>
	</div>
</div>

<div class="booking-section booking-time-section">
	<?php SectionTitle::view( [
		'title'	=> $options['booking-time-section-title'],
		'icon'	=> $options['booking-time-section-icon']
	] ); ?>

	<div class="booking-calendar-wrap">
		<input type="hidden" name="booking_date" class="booking-date-calendar" id="booking-date" required>
	</div>

	<div class="booking-times-wrap">
		<?php
		Loading::view( [
			'classes'	=> ['booking-times-loading']
		] );
		?>
		<input type="hidden" name="booking_time" class="booking-time" id="booking-time" data-nonce="<?php echo wp_create_nonce( 'booking_available_times' ) ?>" required>
		<div class="booking-time-slots"></div>
	</div>

	<?php get_template_part( 'templates/booking/template-booking', 'nav-btns', [
		'current_step'	=> 'time',
		'prev_step'		=> 'specialist',
		'booking_url'	=> $args['booking_url'],
	] ) ?>
</div>

<script type="text/html" id="tmpl-drplus-time-slot">
	<#
		var disabledClass = ( !data.available ) ? ' disabled' : '';
		var ariaDisabled = ( !data.available ) ? 'true' : 'false';
		var ariaLabel = data.time + ' - ' + data.label;
	#>
	<div
		class="booking-time-slot{{ disabledClass }}"
		data-timestamp="{{{data.timestamp}}}"
		role="button"
		tabindex="{{ !data.available ? '-1' : '0' }}"
		aria-disabled="{{ ariaDisabled }}"
		aria-label="{{ ariaLabel }}"
	>
		<span class="booking-time-slot-time">{{{data.time}}}</span>
		<span class="booking-time-slot-divider" aria-hidden="true"></span>
		<span class="booking-time-slot-label">{{{data.label}}}</span>
		<i class="drplus-icon-tick booking-time-slot-selected-icon" aria-hidden="true"></i>
	</div>
</script>