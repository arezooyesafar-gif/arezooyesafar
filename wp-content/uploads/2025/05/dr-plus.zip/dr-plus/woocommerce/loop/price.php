<?php
/**
 * Loop Price
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     1.6.4
 */

use DrPlus\Utils;
use Automattic\WooCommerce\Enums\ProductType;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

if( $product->get_stock_status() !== 'outofstock' && ( $product->is_type( ProductType::VARIABLE ) || $product->get_regular_price() !== "" ) ) {
	if( $product->is_type( ProductType::VARIABLE ) ) {
		echo '<div class="price">' . $product->get_price_html() . '</div>';
	} else {
		$regular_price = wc_get_price_to_display( $product, [
			'price'	=> $product->get_regular_price()
		] );
		echo '<span class="regular-price price">' . wc_price( $product->get_price() ) . '</span>';

		if( $product->is_on_sale() ) {
			$sale_price = $product->get_sale_price();
			$sale_price = wc_get_price_to_display( $product, ['price' => $sale_price] );
			$sale_price_formatted = wc_format_sale_price( $regular_price, $sale_price );
			?>
			<div class="sale-price-wrap">
				<span class="sale-price price"><?php echo $sale_price_formatted ?></span>
				<span class="price-discount-percentage">%<?php echo Utils::calc_product_discount_percentage( $regular_price, $sale_price ) ?></span>
			</div>
			<?php
		}
	}
} else {
	echo wc_get_stock_html( $product );
}