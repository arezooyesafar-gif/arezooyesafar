<?php

use DrPlus\Utils;
use DrPlus\Utils\Archive;

defined( 'ABSPATH' ) || exit;

$separator = is_rtl() ? ' &rsaquo; ' : ' &lsaquo; ';
$max_upload_size_bytes = Utils::get_max_upload_size();

Redux::set_section( // Specialists settings
	$opt_name,
	array(
		'title'			=> esc_html__( 'Specialists settings', 'drplus' ),
		'id'			=> 'specialists-general-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // specialist_identity_max_upload_size
				'id'		=> 'specialist_identity_max_upload_size',
				'type'		=> 'spinner',
				'title'		=> esc_html__( "Max upload size for identity files (MB)", 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), Utils::convert_bytes_to_mb( $max_upload_size_bytes ) ),
				'min'		=> 1,
				'max'		=> Utils::convert_bytes_to_mb( $max_upload_size_bytes, false ),
				'default'	=> Utils::convert_bytes_to_mb( $max_upload_size_bytes, false ),
			],
		),
	)
);

Redux::set_section( // Onboard settings
	$opt_name,
	array(
		'title'			=> esc_html__( 'Onboard settings', 'drplus' ),
		'id'			=> 'specialists-onboard-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // specialist_onboard
				'id'		=> 'specialist_onboard',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Onboarding', 'drplus' ),
				'desc'		=> esc_html__( 'Allow users to submit requests for specialist profiles', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Enabled', 'drplus' ) ),
				'on'		=> esc_html__( 'Enabled', 'drplus' ),
				'off'		=> esc_html__( 'Disabled', 'drplus' ),
				'default'	=> true,
			],
			[ // onboard_my_account_nav
				'id'		=> 'onboard_my_account_nav',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show onboard item in my account navigation (non specialist)', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Show', 'drplus' ) ),
				'on'		=> esc_html__( 'Show', 'drplus' ),
				'off'		=> esc_html__( 'Hide', 'drplus' ),
				'default'	=> true,
				'required'	=> [
					['specialist_onboard','=',true],
				],
			],
			[ // onboard_page_title
				'id'			=> 'onboard_page_title',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Page title', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), get_bloginfo( 'name', 'display' ) . $separator . __( "Onboarding", "drplus" ) ),
				'default'		=> get_bloginfo( 'name', 'display' ) . $separator . __( "Onboarding", "drplus" ),
				'placeholder'	=> get_bloginfo( 'name', 'display' ) . $separator . __( "Onboarding", "drplus" ),
				'required'		=> [
					['specialist_onboard','=',true],
				],
			],
			[ // onboard_title
				'id'			=> 'onboard_title',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Form title', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), __( "Onboarding", "drplus" ) ),
				'default'		=> __( "Onboarding", "drplus" ),
				'placeholder'	=> __( "Onboarding", "drplus" ),
				'required'		=> [
					['specialist_onboard','=',true],
				],
			],
			[ // onboard_show_bg_pattern
				'id'		=> 'onboard_show_bg_pattern',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show background pattern', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Show', 'drplus' ) ),
				'on'		=> esc_html__( 'Show', 'drplus' ),
				'off'		=> esc_html__( 'Hide', 'drplus' ),
				'default'	=> true,
				'required'	=> [
					['specialist_onboard','=',true],
				],
			],
			[ // onboard_show_logo
				'id'		=> 'onboard_show_logo',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show logo', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Show', 'drplus' ) ),
				'on'		=> esc_html__( 'Show', 'drplus' ),
				'off'		=> esc_html__( 'Hide', 'drplus' ),
				'default'	=> true,
				'required'	=> [
					['specialist_onboard','=',true],
				],
			],
			[ // onboard_logo_type
				'id'		=> 'onboard_logo_type',
				'type'		=> 'radio',
				'title'		=> esc_html__( 'Logo type', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Image', 'drplus' ) ),
				'data'		=> [
					'text'	=> esc_html__( 'Text', 'drplus' ),
					'img'	=> esc_html__( 'Image', 'drplus' ),
				],
				'default'	=> 'img',
				'required'	=> [
					['specialist_onboard','=',true],
					['onboard_show_logo','=',true],
				]
			],
			[ // onboard_logo_text_type
				'id'		=> 'onboard_logo_text_type',
				'type'		=> 'radio',
				'title'		=> esc_html__( 'Text type', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Site title', 'drplus' ) ),
				'data'		=> [
					'title'		=> esc_html__( 'Site title', 'drplus' ),
					'custom'	=> esc_html__( 'Custom', 'drplus' ),
				],
				'default'	=> 'title',
				'required'	=> [
					['specialist_onboard','=',true],
					['onboard_show_logo','=',true],
					['onboard_logo_type','=','text'],
				],
			],
			[ // onboard_logo_text_custom
				'id'		=> 'onboard_logo_text_custom',
				'type'		=> 'text',
				'title'		=> esc_html__( 'Logo text', 'drplus' ),
				'required'	=> [
					['specialist_onboard','=',true],
					['onboard_show_logo','=',true],
					['onboard_logo_type','=','text'],
					['onboard_logo_text_type','=','custom'],
				],
			],
			[ // onboard_logo_img
				'id'				=> 'onboard_logo_img',
				'type'		 		=> 'media',
				'title'				=> esc_html__( 'Logo image file', 'drplus' ),
				'compiler'	 		=> true,
				'url'				=> true,
				'preview_size'		=> 'full',
				'library_filter'	=> ['jpeg', 'gif', 'png', 'bmp', 'tiff', 'x-icon', 'svg', 'svg+xml', 'webp'],
				'default'			=> [
					'url'	=> DRPLUS_URI . "assets/images/logo.svg",
				],
				'required'			=> [
					['specialist_onboard','=',true],
					['onboard_show_logo','=',true],
					['onboard_logo_type','=','img'],
				],
			],
			[ // onboard_logo_img_size
				'id'		=> 'onboard_logo_img_size',
				'type'		=> 'dimensions',
				'title'		=> esc_html__( 'Logo size', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), 'W: 160 & H: 60' ),
				'desc'		=> esc_html__( 'Leave empty for full size', 'drplus' ),
				'default'	=> [
					'width'		=> 91,
					'height'	=> 51
				],
				'required'	=> [
					['specialist_onboard','=',true],
					['onboard_show_logo','=',true],
					['onboard_logo_type','=','img'],
				],
			],
			[ // onboard_logo_link
				'id'			=> 'onboard_logo_link',
				'type'			=> 'text',
				'validate'		=> ['url'],
				'title'			=> esc_html__( 'Logo URL', 'drplus' ),
				'subtitle'		=> sprintf( esc_html__( 'Default: %s', 'drplus' ), home_url() ),
				'default'		=> home_url(),
				'placeholder'	=> home_url(),
				'required'		=> [
					['specialist_onboard','=',true],
					['onboard_show_logo','=',true],
				],
			],
			[ // onboard_show_back
				'id'		=> 'onboard_show_back',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show back link', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Yes', 'drplus' ) ),
				'desc'		=> esc_html__( 'Show back link in footer of the form', 'drplus' ),
				'on'		=> esc_html__( 'Yes', 'drplus' ),
				'off'		=> esc_html__( 'No', 'drplus' ),
				'default'	=> true,
				'required'		=> [
					['specialist_onboard','=',true],
				],
			],
			[ // onboard_back_label
				'id'			=> 'onboard_back_label',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Back link text', 'drplus' ),
				'subtitle'		=> sprintf( esc_html__( 'Default: %s', 'drplus' ), __( "Return to home page", 'drplus' ) ),
				'default'		=> __( "Return to home page", 'drplus' ),
				'placeholder'	=> __( "Return to home page", 'drplus' ),
				'required'		=> [
					['specialist_onboard','=',true],
					['onboard_show_back','=',true],
				],
			],
			[ // onboard_back_url
				'id'			=> 'onboard_back_url',
				'type'			=> 'text',
				'validate'		=> ['url'],
				'title'			=> esc_html__( 'Back link', 'drplus' ),
				'subtitle'		=> sprintf( esc_html__( 'Default: %s', 'drplus' ), home_url() ),
				'default'		=> home_url(),
				'placeholder'	=> home_url(),
				'required'		=> [
					['specialist_onboard','=',true],
					['onboard_show_back','=',true],
				],
			],
		)
	)
);

Redux::set_section( // Specialists archive settings
	$opt_name,
	array(
		'title'			=> esc_html__( 'Specialists archive settings', 'drplus' ),
		'id'			=> 'specialists-archive-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // archive_specialist_breadcrumb
				'id'		=> 'archive_specialist_breadcrumb',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show breadcrumb', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Enabled', 'drplus' ) ),
				'on'		=> esc_html__( 'Enabled', 'drplus' ),
				'off'		=> esc_html__( 'Disabled', 'drplus' ),
				'default'	=> true,
			],
			[ // archive_specialist_show_title
				'id'		=> 'archive_specialist_show_title',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show archive title', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Enabled', 'drplus' ) ),
				'on'		=> esc_html__( 'Enabled', 'drplus' ),
				'off'		=> esc_html__( 'Disabled', 'drplus' ),
				'default'	=> true,
			],
			[ // archive_specialist_title_icon
				'id'			=> 'archive_specialist_title_icon',
				'type'			=> 'icon_select',
				'title'			=> esc_html__( 'Archive title icon', 'drplus' ),
				'compiler'		=> true,
				'default'		=> 'drplus-icon-stethoscope',
				'enqueue_frontend'	=> false,
				'stylesheet'	=> [
					[
						'url'		=> DRPLUS_URI . 'assets/css/iconly.min.css',
						'title'		=> __( 'Doctor plus icons', 'drplus' ),
						'prefix'	=> 'drplus-icon',
					],
				],
				'required'		=> [
					['archive_specialist_show_title','=',true]
				]
			],
			[ // archive_specialist_show_sidebar
				'id'		=> 'archive_specialist_show_sidebar',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show archive sidebar', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Enabled', 'drplus' ) ),
				'on'		=> esc_html__( 'Enabled', 'drplus' ),
				'off'		=> esc_html__( 'Disabled', 'drplus' ),
				'default'	=> true,
			],
			[ // archive_specialist_sidebar
				'id'		=> 'archive_specialist_sidebar',
				'type'		=> 'select',
				'title'		=> esc_html__( 'Archive sidebar', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Specialist archive sidebar', 'drplus' ) ),
				'data'		=> 'sidebars',
				'default'	=> 'archive_specialist',
				'required'	=> [
					['archive_specialist_show_sidebar','=',true],
				]
			],
			[ // archive_specialist_desktop_cols
				'id'		=> 'archive_specialist_desktop_cols',
				'type'		=> 'spinner',
				'title'		=> esc_html__( "Desktop columns", 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), '3' ),
				'min'		=> 1,
				'max'		=> 6,
				'default'	=> 4,
			],
			[ // archive_specialist_desktop_gap
				'id'		=> 'archive_specialist_desktop_gap',
				'type'		=> 'spinner',
				'title'		=> esc_html__( "Desktop gap (px)", 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), '24' ),
				'min'		=> 1,
				'max'		=> 64,
				'default'	=> 16,
			],
			[ // archive_specialist_tablet_cols
				'id'		=> 'archive_specialist_tablet_cols',
				'type'		=> 'spinner',
				'title'		=> esc_html__( "Tablet columns", 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), '2' ),
				'min'		=> 1,
				'max'		=> 6,
				'default'	=> 2,
			],
			[ // archive_specialist_tablet_gap
				'id'		=> 'archive_specialist_tablet_gap',
				'type'		=> 'spinner',
				'title'		=> esc_html__( "Tablet gap (px)", 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), '24' ),
				'min'		=> 1,
				'max'		=> 64,
				'default'	=> 16,
			],
			[ // archive_specialist_mobile_cols
				'id'		=> 'archive_specialist_mobile_cols',
				'type'		=> 'spinner',
				'title'		=> esc_html__( "Mobile columns", 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), '1' ),
				'min'		=> 1,
				'max'		=> 6,
				'default'	=> 1,
			],
			[ // archive_specialist_mobile_gap
				'id'		=> 'archive_specialist_mobile_gap',
				'type'		=> 'spinner',
				'title'		=> esc_html__( "Mobile gap (px)", 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), '24' ),
				'min'		=> 1,
				'max'		=> 64,
				'default'	=> 16,
			],
			[ // archive_specialist_card_type
				'id'		=> 'archive_specialist_card_type',
				'type'		=> 'image_select',
				'title'		=> esc_html__( "Specialists display type", 'bijan' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( "Card 2", 'bijan' ) ),
				'options'	=> [
					'card-1'	=> [
						'alt'	=> esc_html__( "Card 1", 'bijan' ),
						'img'	=> DRPLUS_URI . "assets/images/backend/specialist-card-1.jpg",
						'title'	=> esc_html__( "Card 1", 'bijan' ),
					],
					'card-2'	=> [
						'alt'	=> esc_html__( "Card 2", 'bijan' ),
						'img'	=> DRPLUS_URI . "assets/images/backend/specialist-card-2.jpg",
						'title'	=> esc_html__( "Card 2", 'bijan' ),
					],
					'list'	=> [
						'alt'	=> esc_html__( "List", 'bijan' ),
						'img'	=> DRPLUS_URI . "assets/images/backend/specialist-list.jpg",
						'title'	=> esc_html__( "List", 'bijan' ),
					],
				],
				'default'	=> 'card-2',
			],
			[ // archive_specialist_verified_text
				'id'			=> 'archive_specialist_verified_text',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Verified text', 'drplus' ),
				'desc'			=> esc_html__( 'If you leave it empty, the verified badge will not be shown.', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), sprintf( esc_html__( 'Verified by %s', 'drplus' ), get_bloginfo( 'name' ) ) ),
				'default'		=> sprintf( esc_html__( 'Verified by %s', 'drplus' ), get_bloginfo( 'name' ) ),
				'placeholder'	=> sprintf( esc_html__( 'Verified by %s', 'drplus' ), get_bloginfo( 'name' ) ),
			],
		),
	)
);