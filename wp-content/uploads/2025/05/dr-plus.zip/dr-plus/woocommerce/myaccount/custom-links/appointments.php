<?php

use DrPlus\Components\Button;
use DrPlus\Utils;
use DrPlus\Utils\Booking;
use DrPlus\Utils\Date;
use DrPlus\Utils\Options;

if( !empty( $_GET['order_id'] ) ) {
	$order_id = Utils::convert_chars( $_GET['order_id'], true, 'absint' );
	$order = wc_get_order( $order_id );

	if( !empty( $order ) ) {
		$order_meta = $order->get_meta_data();
		foreach( $order_meta as $meta ) {
			if( $meta->key == '_booking_data' ) {
				$book_data = $meta->value;
				break;
			}
		}
	}


	if( empty( $order ) || empty( $book_data ) || $order->get_customer_id() != get_current_user_id() ) { ?>
		<div class="drplus-app-empty-order">
			<?php echo esc_html__( 'You have no access to this order.', 'drplus' ) ?>
		</div>
		<?php return; ?>
	<?php }

	if( !empty( $order ) ) {
		get_template_part( "templates/booking/template-booking-step", 'receipt', [
			'book_data'			=> $book_data,
			'order'				=> $order,
			'show_back_btn'		=> true,
			'view_type'			=> 'user',
		] );
		return;
	}
}

$current_filter = !empty( $_GET['filter'] ) ? Utils::convert_chars( $_GET['filter'] ) : "all";
$current_filter = Utils::ensure_values_in_array( $current_filter, ['ongoing', 'cancelled', 'completed', 'all', 'pending'], 'all' );

$all_order_statuses = Booking::get_order_statuses();

$cols = ['book_id', 'date', 'start_time', 'order_status', 'order_id', 'office_id'];
$statuses = ['completed', 'pending', 'processing', 'failed', 'cancelled', 'refunded'];
$appointments = Booking::get_customer_appointments( get_current_user_id(), $statuses, [], $cols, 0 );

$current_page_link = strtok( $_SERVER["REQUEST_URI"], '?' );

$status_filters = Booking::get_status_filters();
$status_filters['all']['value'] = count( $appointments );

$appointments_to_show = [];

if( !empty( $appointments ) ) {
	// filter appointments by status
	foreach( $appointments as $appointment ) {	
		if( in_array( $appointment['order_status'], ['failed', 'cancelled', 'refunded'] ) ) {

			$status_filters['cancelled']['value']++;
			$appointment['status_label'] = $status_filters['cancelled']['text'];
			if( $current_filter == 'cancelled' || $current_filter == 'all' ) $appointments_to_show[] = $appointment;

		} elseif( $appointment['order_status'] == 'pending' ) {

			$status_filters['pending']['value']++;
			$appointment['status_label'] = $status_filters['pending']['text'];
			if( $current_filter == 'pending' || $current_filter == 'all' ) $appointments_to_show[] = $appointment;

		} elseif( $appointment['date'] > date( 'Y-m-d H:i:s' ) ) {

			$status_filters['ongoing']['value']++;
			$appointment['status_label'] = $status_filters['ongoing']['text'];
			if( $current_filter == 'ongoing' || $current_filter == 'all' ) $appointments_to_show[] = $appointment;

		} elseif( "{$appointment['date']} {$appointment['start_time']}" < date( 'Y-m-d H:i:s' ) ) {

			$status_filters['completed']['value']++;
			$appointment['status_label'] = $status_filters['completed']['text'];
			if( $current_filter == 'completed' || $current_filter == 'all' ) $appointments_to_show[] = $appointment;
			
		} else {

			$status_filters['ongoing']['value']++;
			$appointment['status_label'] = $status_filters['ongoing']['text'];
			if( $current_filter == 'ongoing' || $current_filter == 'all' ) $appointments_to_show[] = $appointment;

		}
	}
}

?>
<h2 class="drplus-myaccount-page-title"><?php esc_html_e( 'Your appointments', 'drplus' ) ?></h2>

<div id="appointments-filters">
	<?php if( !empty( $status_filters['all']['value'] ) ) { ?>
		<?php foreach( $status_filters as $filter_key => $filter ) { ?>
			<a href="<?php echo $filter['link'] ?>" class="appointments-filter-item<?php echo $current_filter == $filter_key ? ' current-filter' : "" ?>"><?php printf( '%s (%s)', esc_html( $filter['text'] ), esc_html( $filter['value'] ) ) ?></a>
		<?php } ?>
	<?php } ?>
</div>
<?php if( empty( $appointments_to_show ) ) : ?>
	<?php
	$options = Options::get_options( [
		'wc_empty_appointments_text'	=> esc_html__( 'You have not booked any appointments yet.', 'drplus' ),
	] );	
	?>
	<div class="empty-page">
		<i class="empty-page-icon empty-cart-icon drplus-icon-calendar-2"></i>
		<div class='empty-page-text'>
			<?php echo esc_html( $options['wc_empty_appointments_text']  ) ?>
		</div>
	</div>
<?php else : ?>
	<div id="appointments-content">
		<table id="appointments" class="drplus-appointments-table">
			<thead>
				<tr>
					<th>
						<span><?php echo esc_html__( 'Visit ID', 'drplus' ) ?></span>
					</th>
					<th>
						<span><?php echo esc_html__( 'Appointment type', 'drplus' ) ?></span>
					</th>
					<th>
						<span><?php echo esc_html__( 'Status', 'drplus' ) ?></span>
					</th>
					<th>
						<span><?php echo esc_html__( 'Visit date', 'drplus' ) ?></span>
					</th>
					<th>
						<span><?php echo esc_html__( 'Actions', 'drplus' ) ?></span>
					</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach( $appointments_to_show as $appointment ) { ?>
					<tr>
						<td>
							<span class="woocommerce-orders-table__cell-col-name"><?php echo esc_html__( 'Visit ID', 'drplus' ) ?></span>
							<span><?php echo $appointment['book_id'] ?></span>
						</td>
						<td>
							<span class="woocommerce-orders-table__cell-col-name"><?php echo esc_html__( 'Appointment type', 'drplus' ) ?></span>
							<span><?php echo $appointment['office_id'] == 'consultation' ? esc_html__( 'Online consultation', 'drplus' ) : esc_html__( 'in-person visit', 'drplus' ) ?></span>
						</td>
						<td class="order-status-is-<?php echo $appointment['order_status'] ?>">
							<span class="woocommerce-orders-table__cell-col-name"><?php echo esc_html__( 'Status', 'drplus' ) ?></span>
							<span><?php echo $appointment['status_label'] ?></span>
						</td>
						<td>
							<span class="woocommerce-orders-table__cell-col-name"><?php echo esc_html__( 'Visit date', 'drplus' ) ?></span>
							<span><?php echo Date::jdate( 'Y/m/d', strtotime( $appointment['date'] ) ) ?></span>
						</td>
						<td>
							<?php Button::view( [
								'text'		=> esc_html__( 'View', 'drplus' ),
								'link'		=> add_query_arg( 'order_id', $appointment['order_id'], $current_page_link ),
								'small'		=> true,
								'type'		=> 'gray',
								'fullwidth'	=> true,
								'disabled'	=> in_array( $appointment['order_status'], $status_filters['cancelled']['statuses'] ),
							] ) ?>
						</td>
					</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>