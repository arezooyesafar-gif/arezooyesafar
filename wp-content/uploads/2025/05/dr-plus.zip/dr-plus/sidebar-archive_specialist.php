<?php
if( !defined( 'ABSPATH' ) || !class_exists( "DrPlus\Utils" ) ) exit;

?>
<div id="sidebar" class="sidebar sidebar-archive_specialist col-lg-3 col-md-12">
	<div id="widget-area" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 'archive_specialist' ); ?>
	</div>
</div>