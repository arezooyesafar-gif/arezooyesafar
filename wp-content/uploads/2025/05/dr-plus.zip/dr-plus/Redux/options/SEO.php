<?php
defined( 'ABSPATH' ) || exit;

Redux::set_section( // General
	$opt_name,
	array(
		'title'			=> esc_html__( 'Title tags', 'drplus' ),
		'id'			=> 'seo-title-tags-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // homepage-site-title-tag
				'id'		=> 'homepage-site-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Home page site title', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags
			],
			[ // otherpage-site-title-tag
				'id'		=> 'otherpage-site-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Other pages site title', 'drplus' ),
				'default'	=> 'div',
				'options'	=> $tags
			],
			[ // archive-title-tag
				'id'		=> 'archive-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Archive page title', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags
			],
			[ // shop-page-title-tag
				'id'		=> 'shop-page-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Shop page title', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags
			],
			[ // page-title-tag
				'id'		=> 'page-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Pages title', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags
			],
			[ // post-title-tag
				'id'		=> 'post-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Single post title', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags
			],
			[ // product-title-tag
				'id'		=> 'product-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Single product title', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags
			],
			[ // hospital-single-title-tag
				'id'		=> 'hospital-single-title-tag',
				'type'		=> 'select',
				'title'		=> __( 'Single hospital title', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags,
				'required'	=> [
					['single_hospital_head_title','=',true]
				]
			],
			[ // hospital-single-subtitle-tag
				'id'		=> 'hospital-single-subtitle-tag',
				'type'		=> 'select',
				'title'		=> __( 'Single hospital subtitle', 'drplus' ),
				'default'	=> 'h2',
				'options'	=> $tags,
				'required'	=> [
					['single_hospital_head_subtitle','=',true]
				]
			],
			[ // archive_specialist_title_tag
				'id'		=> 'archive_specialist_title_tag',
				'type'		=> 'select',
				'title'		=> __( 'Specialist archive item title', 'drplus' ),
				'default'	=> 'h2',
				'options'	=> $tags,
				'required'	=> [
					['archive_specialist_show_title','=',true]
				]
			],
		),
	)
);