<?php
namespace DrPlus\Elementor;

use DrPlus\ElementorControls;
use DrPlus\Utils;
use DrPlus\Utils\Options;
use DrPlus\Utils\Sanitizers;

class AccountButton extends \Elementor\Widget_Base {
	public function get_name() {
		return 'drplus_account_button';
	}

	public function get_title() {
		return esc_html__( 'Account button (Doctor Plus)', 'drplus' );
	}

	public function get_icon() {
		return 'eicon-my-account';
	}

	public function get_categories() {
		return ['drplus'];
	}

	public function get_keywords() {
		return ['text', 'my account', 'woocommerce', 'wc', 'داشبورد', 'حساب کاربری', 'پروفایل', 'ووکامرس'];
	}

	private function settings_controls() {
		$this->start_controls_section( // content_section
			'settings_section',
			[
				'label'	=> esc_html__( 'Settings', 'drplus' ),
				'tab'	=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'text_type',
			[
				'type'		=> \Elementor\Controls_Manager::SELECT,
				'label'		=> esc_html__( 'Text type', 'drplus' ),
				'default'	=> 'username',
				'options'	=> [
					'username'		=> __( 'User name', 'drplus' ),
					'custom_text'	=> __( 'Custom text', 'drplus' ),
					'none'			=> __( 'None', 'drplus' )
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'			=> esc_html__( 'Button text', 'drplus' ),
				'description'	=> esc_html__( 'HTML tags allowed', 'drplus' ),
				'label_block'	=> true,
				'type'			=> \Elementor\Controls_Manager::TEXT,
				'default'		=> esc_html__( 'Account', 'drplus' ),
				'dynamic'		=> [
					'active'	=> true,
				],
				'condition'	=> [
					'text_type'	=> 'custom_text',
				],
			]
		);

		$this->add_control(
			'attachment_type',
			[
				'type'		=> \Elementor\Controls_Manager::SELECT,
				'label'		=> esc_html__( 'Attachment type', 'drplus' ),
				'default'	=> 'avatar',
				'options'	=> [
					'avatar'	=> __( 'User avatar', 'drplus' ),
					'icon'		=> __( 'Icon', 'drplus' ),
					'none'		=> __( 'None', 'drplus' )
				],
			]
		);

		$this->add_control(
			'button_icon',
			[
				'label'		=> esc_html__( 'Icon', 'drplus' ),
				'type'		=> \Elementor\Controls_Manager::ICONS,
				'default'	=> [
					'value'		=> 'drplus-icon-user',
					'library'	=> 'drplus-icon',
				],
				'condition'	=> [
					'attachment_type'	=> 'icon',
				],
			]
		);

		$this->add_control(
			'attachment_align',
			[
				'label'		=> esc_html__( 'Attachment Position', 'drplus' ),
				'type'		=> \Elementor\Controls_Manager::CHOOSE,
				'default'	=> 'end',
				'options'	=> [
					'start'	=> [
						'title'	=> esc_html__( 'Start', 'drplus' ),
						'icon'	=> 'eicon-h-align-left',
					],
					'end'	=> [
						'title'	=> esc_html__( 'End', 'drplus' ),
						'icon'	=> 'eicon-h-align-right',
					],
				],
				'condition'	=> [
					'attachment_type!'	=> 'none',
				],
			],
		);

		$this->add_control(
			'show_menu',
			[
				'label'			=> esc_html__( 'Show Menu', 'drplus' ),
				'type'			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on'		=> esc_html__( 'Show', 'drplus' ),
				'label_off'		=> esc_html__( 'Hide', 'drplus' ),
				'return_value'	=> 'yes',
				'default'		=> 'yes',
			]
		);

		$this->add_control(
			'menu_align',
			[
				'label'		=> esc_html__( 'Menu Position', 'drplus' ),
				'type'		=> \Elementor\Controls_Manager::CHOOSE,
				'default'	=> 'end',
				'options'	=> [
					'p-start'	=> [
						'title'	=> esc_html__( 'Start', 'drplus' ),
						'icon'	=> 'eicon-h-align-left',
					],
					'p-center'	=> [
						'title'	=> esc_html__( 'Center', 'drplus' ),
						'icon'	=> 'eicon-h-align-center',
					],
					'p-end'	=> [
						'title'	=> esc_html__( 'End', 'drplus' ),
						'icon'	=> 'eicon-h-align-right',
					],
				],
				'condition'	=> [
					'show_menu'	=> 'yes',
				],
			],
		);

		$this->add_control(
			'show_notif_count',
			[
				'label'			=> esc_html__( 'Show notification count', 'drplus' ),
				'type'			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on'		=> esc_html__( 'Show', 'drplus' ),
				'label_off'		=> esc_html__( 'Hide', 'drplus' ),
				'return_value'	=> 'yes',
				'default'		=> 'yes',
			]
		);

		$this->add_control(
			'btn_arrow',
			[
				'label'			=> esc_html__( 'Button arrow', 'drplus' ),
				'type'			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on'		=> esc_html__( 'Show', 'drplus' ),
				'label_off'		=> esc_html__( 'Hide', 'drplus' ),
				'return_value'	=> 'yes',
				'default'		=> 'no',
			]
		);

		$this->end_controls_section();
	}

	protected function register_controls() {
		$this->settings_controls();
		
		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'btn_wrap_',
			'selector'		=> '.header-account-wrap .header-account',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'btn_wrap_',
				'label'	=> esc_html__( 'Button', 'drplus' ),
			],

			'mode'	=> 'wrap',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_text_',
			'base_selector'		=> '.header-account-wrap .header-account',
			'selector'			=> '.header-account-display_name',
			'hover_type'		=> 'base',
			
			'section'	=> [
				'name'	=> 'btn_text_',
				'label'	=> esc_html__( 'Button text', 'drplus' ),
				'condition'	=> [
					'text_type!'	=> 'none',
				],
			],

			'mode'	=> 'text',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_avatar_',
			'base_selector'		=> '.header-account-wrap .header-account',
			'selector'			=> 'img',
			'hover_type'		=> 'base',
			
			'section'	=> [
				'name'	=> 'btn_avatar',
				'label'	=> esc_html__( 'User avatar', 'drplus' ),
				'condition'	=> [
					'attachment_type'	=> 'avatar',
				],
			],

			'mode'	=> 'image',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_icon_',
			'base_selector'		=> '.header-account-wrap .header-account',
			'selector'			=> '.header-account-icon',
			'hover_type'		=> 'base',
			
			'section'	=> [
				'name'	=> 'btn_icon',
				'label'	=> esc_html__( 'Button icon', 'drplus' ),
				'condition'	=> [
					'attachment_type'	=> 'icon',
				],
			],

			'mode'	=> 'icon',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_icon_arrow_',
			'base_selector'		=> '.header-account-wrap .header-account',
			'selector'			=> '.header-account-active-icon',
			'hover_type'		=> 'base',
			
			'section'	=> [
				'name'	=> 'btn_icon_arrow',
				'label'	=> esc_html__( 'Button arrow icon', 'drplus' ),
				'condition'	=> [
					'btn_arrow'	=> 'yes',
				],
			],

			'mode'	=> 'icon',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_menu_wrap_',
			'base_selector'		=> '.header-account-wrap',
			'selector'			=> '.header-account-items',
			'hover_type'		=> 'normal',
			
			'section'	=> [
				'name'	=> 'btn_menu_wrap',
				'label'	=> esc_html__( 'Account menu', 'drplus' ),
				'condition'	=> [
					'show_menu'	=> 'yes',
				],
			],

			'mode'	=> 'wrap',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_menu_item_',
			'base_selector'		=> '.header-account-wrap',
			'selector'			=> '.account-item-link',
			'hover_type'		=> 'normal',
			
			'section'	=> [
				'name'	=> 'btn_menu_item',
				'label'	=> esc_html__( 'Account menu item', 'drplus' ),
				'condition'	=> [
					'show_menu'	=> 'yes',
				],
			],

			'mode'	=> 'wrap',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_menu_item_text_',
			'base_selector'		=> '.header-account-wrap .account-item-link',
			'selector'			=> '.account-item-label',
			'hover_type'		=> 'base',
			
			'section'	=> [
				'name'	=> 'btn_menu_item_text',
				'label'	=> esc_html__( 'Account menu item text', 'drplus' ),
				'condition'	=> [
					'show_menu'	=> 'yes',
				],
			],

			'mode'	=> 'text',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_menu_item_icon_',
			'base_selector'		=> '.header-account-wrap .account-item-link',
			'selector'			=> '.account-item-icon',
			'hover_type'		=> 'base',
			
			'section'	=> [
				'name'	=> 'btn_menu_item_icon',
				'label'	=> esc_html__( 'Account menu item icon', 'drplus' ),
				'condition'	=> [
					'show_menu'	=> 'yes',
				],
			],

			'mode'	=> 'icon',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'			=> 'btn_menu_item_arrow_',
			'base_selector'		=> '.header-account-wrap .account-item-link',
			'selector'			=> '.account-item-hover-icon',
			'hover_type'		=> 'base',
			
			'section'	=> [
				'name'	=> 'btn_menu_item_arrow',
				'label'	=> esc_html__( 'Account menu item arrow', 'drplus' ),
				'condition'	=> [
					'show_menu'	=> 'yes',
				],
			],

			'mode'	=> 'icon',
		] );
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		get_template_part( "templates/header/template-header-action", 'account_btn', [
			'call_mode'						=> 'elementor',
			'account-btn-text-type'			=> $settings['text_type'],
			'account-btn-text'				=> $settings['button_text'] ?? __( 'Account', 'drplus' ),
			'account-btn-attachment-type'	=> $settings['attachment_type'],
			'account-btn-attachment-align'	=> $settings['attachment_align'] ?? 'start',
			'account-btn-icon'				=> Sanitizers::icon( $settings['button_icon'] ?? 'drplus-icon-user', 'header-action-icon header-account-icon' ),
			'show-account-btn-menu'			=> Utils::to_bool( $settings['show_menu'] ),
			'account-btn-menu-align'		=> $settings['menu_align'] ?? 'p-start',
			'show-notif-count'				=> $settings['show_notif_count'],
			'show_arrow'					=> Utils::to_bool( $settings['btn_arrow'] )
		] );
	}
}