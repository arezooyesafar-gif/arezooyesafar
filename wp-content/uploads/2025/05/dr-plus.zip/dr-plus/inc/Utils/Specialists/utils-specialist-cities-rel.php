<?php
namespace DrPlus\Utils;

use DrPlus\DB\SpecialistCitiesRel as DBSpecialistCitiesRel;
use DrPlus\Utils;

class SpecialistCitiesRel extends Utils {
	public static function all( $where = [], $columns = [], $attrs = [] ) {
		$specialists_rel = new DBSpecialistCitiesRel;
		return $specialists_rel->find( $where, $columns, $attrs )->data;
	}

	public static function get( $id ) {
		$specialists_rel = new DBSpecialistCitiesRel( absint( $id ) );
		return $specialists_rel->data;
	}

	public static function find( $where = [], $attr = [] ) {
		$specialists_rel = new DBSpecialistCitiesRel;
		return $specialists_rel->find( $where, [], $attr )->data;
	}

	public static function new( $data ) {
		$specialists_rel = new DBSpecialistCitiesRel;
		foreach( $data as $key => $value ) {
			$specialists_rel->$key = $value;
		}
		return $specialists_rel->insert();
	}

	public static function update( $id, $data ) {
		$specialists_rel = new DBSpecialistCitiesRel( absint( $id ) );
		if( empty( $specialists_rel->data ) ) return false;

		foreach( $data as $key => $value ) {
			$specialists_rel->$key = $value;
		}
		return $specialists_rel->update()->data;
	}

	public static function delete( $id ) {
		$specialists_rel = new DBSpecialistCitiesRel( absint( $id ) );
		if( empty( $specialists_rel->data ) ) return false;
		return $specialists_rel->delete();
	}

	/**
	 * Add user cities
	 *
	 * @param int $user_id
	 * @param array $data array cities. each city is an array with the following keys:
	 *                      - city
	 *                      - province
	 * @return void
	 */
	public static function add_user_cities( $user_id, $data ) {
		foreach( $data as $item ) {
			self::new( [
				'user_id'	=> $user_id,
				'city'		=> $item['city'],
				'province'	=> $item['province'],
			] );
		}

	}

	public static function get_user_cities( $user_id ) {
		$user_id = Utils::get_user_id( $user_id );
		if( empty( $user_id ) ) return false;
		$specialists_rel = new DBSpecialistCitiesRel;
		$where = [];
		$where = [
			'AND'	=> [
				'`user_id`=%d'	=> $user_id
			]
		];
		return $specialists_rel->find( $where )->data ?? [];
	}

	public static function count( bool $only_actives = true, $where = [], $attrs = [] ) : int {
		$specialists_rel = new DBSpecialistCitiesRel;
		if( $only_actives ) {
			global $wpdb;
			$where['AND']["`{$wpdb->prefix}drplus_specialists`.`status`=%s"] = 'active';

			$attrs = Utils::unset( $attrs, ['LIMIT', 'OFFSET'] );

			$query = "SELECT COUNT(`{$specialists_rel->table}`.`{$specialists_rel->key}`) as counts FROM `{$specialists_rel->table}` LEFT JOIN `{$wpdb->prefix}drplus_specialists` ON `{$specialists_rel->table}`.`user_id` = `{$wpdb->prefix}drplus_specialists`.`user_id`";
			$query = $specialists_rel->query_creator( $query, $where, $attrs );
			return $wpdb->get_row( $query )->counts ?? 0;
		} else {
			return $specialists_rel->count( $where, $attrs );
		}
	}
}