<?php
namespace DrPlus\Utils;

use DrPlus\Utils;

class WC extends Utils {
	public static function default_attribute_settings() {
		return [
			'display_type'	=> 'select',
			'icon'			=> '',
		];
	}
	
	public static function get_attribute_settings( int $id ) {
		$settings = get_option( "drplus_wc_attr_{$id}", self::default_attribute_settings() );
		if( !is_array( $settings ) ) $settings = [];
		return parent::check_default( $settings, self::default_attribute_settings() );
	}

	public static function update_attribute_settings( int $id, array $settings ) {
		$settings = parent::check_default( $settings, self::default_attribute_settings() );
		update_option( "drplus_wc_attr_{$id}", $settings, false );
	}

	public static function get_term_color( int $id ) {
		return sanitize_hex_color( get_term_meta( $id, '_drplus_color', true ) );
	}

	public static function update_term_color( int $id, string $color ) {
		update_term_meta( $id, '_drplus_color', $color );
	}

	public static function get_term_img( int $id ) {
		return absint( get_term_meta( $id, '_drplus_img', true ) );
	}

	public static function update_term_img( int $id, $img ) {
		update_term_meta( $id, '_drplus_img', absint( $img ) );
	}

	public static function my_account_custom_links() {
		$links = [
			'appointments'			=> _x( "Your reservations", 'My Account Link', 'drplus' ),
			'specialist-dashboard'	=> _x( "Specialist dashboard", 'My Account Link', 'drplus' ),
			'notifications'			=> _x( "Notifications", 'My Account Link', 'drplus' ),
			// 'tickets'				=> _x( "Your tickets", 'My Account Link', 'drplus' ),
			'wishlist'				=> _x( "Wishlist", 'My Account Link', 'drplus' ),
		];
		$options = Options::get_options( [
			'booking'					=> true,
			'notifications'				=> true,
			'tickets'					=> true,
			'wishlist'					=> true,
			'specialist_onboard'		=> true,
			'onboard_my_account_nav'	=> true,
		] );
		$unset = [];
		if( !parent::to_bool( $options['booking'] ) ) {
			$unset[] = 'appointments';
		}
		if( !parent::to_bool( $options['notifications'] ) ) {
			$unset[] = 'notifications';
		}
		if( !parent::to_bool( $options['tickets'] ) ) {
			$unset[] = 'tickets';
		}
		if( !parent::to_bool( $options['wishlist'] ) ) {
			$unset[] = 'wishlist';
		}
		if( !parent::to_bool( $options['specialist_onboard'] ) || !parent::to_bool( $options['onboard_my_account_nav'] ) ) {
			$unset[] = 'specialist-dashboard';
		}

		if( !empty( $unset ) ) {
			$links = parent::unset( $links, $unset );
		}
		return $links;
	}

	public static function my_account_menu_link_icons() {
		$icons = [
			'dashboard'				=> 'element-3',
			'orders'				=> 'bag-1',
			'appointments'			=> 'edit',
			'specialist-dashboard'	=> 'stethoscope',
			'downloads'				=> 'download',
			'notifications'			=> 'notification',
			'tickets'				=> 'document-text',
			'edit-address'			=> 'location',
			'wishlist'				=> 'heart',
			'edit-account'			=> 'message-edit',
			'customer-logout'		=> 'logout',
		];

		$options = Options::get_options( [
			'booking'		=> true,
			'notifications'	=> true,
			'tickets'		=> true,
			'wishlist'		=> true,
		] );
		$unset = [];
		if( !Utils::to_bool( $options['booking'] ) ) {
			$unset[] = 'appointments';
		}
		if( !Utils::to_bool( $options['notifications'] ) ) {
			$unset[] = 'notifications';
		}
		if( !Utils::to_bool( $options['tickets'] ) ) {
			$unset[] = 'tickets';
		}
		if( !Utils::to_bool( $options['wishlist'] ) ) {
			$unset[] = 'wishlist';
		}
		if( !empty( $unset ) ) {
			$icons = parent::unset( $icons, $unset );
		}

		return apply_filters( "drplus/wc/my-account/links/icons", $icons );
	}

	public static function specialist_profile_sections() : array {
		return [
			'specialist-appointments'	=> [
				'label'	=> __( "Appointments", 'drplus' ),
				'icon'	=> 'drplus-icon-calendar-2',
			],
			'personal'		=> [
				'label'	=> __( "Edit personal info", 'drplus' ),
				'icon'	=> 'drplus-icon-author',
			],
			'identity'		=> [
				'label'	=> __( "Identity documents", 'drplus' ),
				'icon'	=> 'drplus-icon-copy-2',
			],
			'services'		=> [
				'label'	=> __( "Specialized Services", 'drplus' ),
				'icon'	=> 'drplus-icon-stethoscope',
			],
			'insurances'	=> [
				'label'	=> __( "Insurances", 'drplus' ),
				'icon'	=> 'drplus-icon-element-3',
			],
			'offices'		=> [
				'label'	=> __( "Offices", 'drplus' ),
				'icon'	=> 'drplus-icon-hospital',
			],
			'certificates'	=> [
				'label'	=> __( "Certificates and Courses", 'drplus' ),
				'icon'	=> 'drplus-icon-verify',
			],
			'faqs'			=> [
				'label'	=> __( "FAQs", 'drplus' ),
				'icon'	=> 'drplus-icon-menu',
			],
			'reserve'		=> [
				'label'	=> __( "Reservation Settings", 'drplus' ),
				'icon'	=> 'drplus-icon-archive-book',
			],
			'financial'		=> [
				'label'	=> __( "Financial Information", 'drplus' ),
				'icon'	=> 'drplus-icon-coin',
			],
		];
	}

	public static function get_current_specialist_profile_section() : string {
		static $section = null;
		if( $section === null ) {
			$section = parent::convert_chars( get_query_var( 'specialist-dashboard', 'dashboard' ) );
			if( empty( $section ) || !file_exists( DRPLUS_DIR . "woocommerce/myaccount/custom-links/specialist-dashboard/{$section}.php" ) || !isset( self::specialist_profile_sections()[$section] ) ) {
				$section = 'dashboard';
			}
		}
		return $section;
	}

	public static function get_product_badge( $product_id = 0 ) {
		$product_id = parent::get_post_id( $product_id );
		$options = Options::get_options( [
			'product_badge'	=> true,
		] );
		if( !Utils::to_bool( $options['product_badge'] ) ) return [];
		$terms = get_the_terms( $product_id, 'product-badge' );
		if( empty( $terms[0] ) ) return [];
		$image = absint( get_term_meta( $terms[0]->term_id, 'badge_image', true ) );
		if( !$image ) return [];
		return [
			'image'	=> $image,
			'name'	=> $terms[0]->name
		];
	}

	public static function attr_display_types() {
		static $types = null;
		if( $types === null ) {
			$types = [
				'select'	=> __( 'Dropdown list', 'drplus' ),
				'color'		=> __( 'Color', 'drplus' ),
				'image'		=> __( 'Image', 'drplus' ),
			];
		}
		return $types;
	}
}