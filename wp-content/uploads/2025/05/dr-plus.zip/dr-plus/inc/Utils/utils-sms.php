<?php
namespace DrPlus\Utils;

use DrPlus\DB\OTP;
use DrPlus\Utils;

class SMS extends Utils {
	public static function defaults() {
		$blogname = get_option( 'blogname', '' );
		return [
			'gateway'	=> '',
			'messages'	=> [
				'auth'	=> [
					'login'				=> sprintf( __( 'Your login code is: {otp}%s', 'drplus' ), "\r\n\r\n" . $blogname ),
					'register'			=> sprintf( __( 'Your register code is: {otp}%s', 'drplus' ), "\r\n\r\n" . $blogname ),
					'lost_password'	=> sprintf( __( 'Your new password is: {password}%s', 'drplus' ), "\r\n\r\n" . $blogname ),
				]
			],
			'settings'	=> [
				'auth'	=> [
					'login'	=> [
						'enabled'	=> true,
						'pattern'	=> '',
						'otp_timer'	=> 60,
					],
					'register'	=> [
						'enabled'	=> true,
						'pattern'	=> '',
						'otp_timer'	=> 60,
					],
					'one_form'	=> true,
					'lost_password'	=> [
						'enabled'	=> true,
						'pattern'	=> '',
					],
				],
			],
		];
	}

	public static function gateways() {
		return apply_filters( 'drplus/sms/gateways', [
			'melipayamak'	=> [
				'label'			=> __( 'Melipayamak', 'drplus' ),
				'logo'			=> 'melipayamak.jpg',
				'fields'		=> ['username', 'password', 'from'],
				'is_service'	=> false,
			],
			'melipayamak_service'	=> [
				'label'			=> __( 'Melipayamak (service)', 'drplus' ),
				'logo'			=> 'melipayamak.jpg',
				'fields'		=> ['username', 'password'],
				'is_service'	=> true,
			],
			'farazsms'	=> [
				'label'			=> __( 'Farazsms', 'drplus' ),
				'logo'			=> 'farazsms.png',
				'fields'		=> ['api_key', 'from'],
				'is_service'	=> false,
			],
			'farazsms_service'	=> [
				'label'			=> __( 'Farazsms (service)', 'drplus' ),
				'logo'			=> 'farazsms.png',
				'fields'		=> ['api_key', 'from'],
				'is_service'	=> true,
			],
			'smsir'	=> [
				'label'			=> __( 'SMS.ir', 'drplus' ),
				'logo'			=> 'sms.ir.svg',
				'fields'		=> ['api_key', 'from'],
				'is_service'	=> false,
			],
			'smsir_service'	=> [
				'label'			=> __( 'SMS.ir (service)', 'drplus' ),
				'logo'			=> 'sms.ir.svg',
				'fields'		=> ['api_key'],
				'is_service'	=> true,
			],
			'kavenegar'	=> [
				'label'			=> __( 'Kavenegar', 'drplus' ),
				'logo'			=> 'kavenegar.png',
				'fields'		=> ['api_key', 'from'],
				'is_service'	=> false,
			],
			'kavenegar_service'	=> [
				'label'			=> __( 'Kavenegar (service)', 'drplus' ),
				'logo'			=> 'kavenegar.png',
				'fields'		=> ['api_key'],
				'is_service'	=> true,
			],
			'farapayamak'	=> [
				'label'			=> __( 'Farapayamak', 'drplus' ),
				'logo'			=> 'farapayamak.png',
				'fields'		=> ['username', 'password', 'from'],
				'is_service'	=> false,
			],
			'farapayamak_service'	=> [
				'label'			=> __( 'Farapayamak (service)', 'drplus' ),
				'logo'			=> 'farapayamak.png',
				'fields'		=> ['username', 'password'],
				'is_service'	=> true,
			],
			'payamresan'	=> [
				'label'			=> __( 'Payamresan', 'drplus' ),
				'logo'			=> 'payamresan.svg',
				'fields'		=> ['api_key', 'from'],
				'is_service'	=> false,
			],
			'payamresan_service'	=> [
				'label'			=> __( 'Payamresan (service)', 'drplus' ),
				'logo'			=> 'payamresan.svg',
				'fields'		=> ['api_key'],
				'is_service'	=> true,
			],
			'raygansms'	=> [
				'label'			=> __( 'Raygansms', 'drplus' ),
				'logo'			=> 'raygansms.png',
				'fields'		=> ['username', 'password', 'from'],
				'is_service'	=> false,
			],
			'raygansms_service'	=> [
				'label'			=> __( 'Raygansms (service)', 'drplus' ),
				'logo'			=> 'raygansms.png',
				'fields'		=> ['username', 'password', 'api_key'],
				'is_service'	=> true,
			],
		] );
	}
	
	public static function get_settings() {
		$settings = null;
		if( $settings === null ) {
			$settings = parent::check_default( get_option( 'drplus_sms_settings', self::defaults() ), self::defaults() );

			if( !empty( $settings['gateway'] ) ) {
				if( !isset( self::gateways()[$settings['gateway']] ) ) {
					$settings = parent::unset( $settings, [$settings['gateway']] ); // Remove the gateway settings if it's not valid
					$settings['gateway'] = '';
				} else {
					foreach( self::gateways()[$settings['gateway']]['fields'] as $field ) {
						$settings[$settings['gateway']][$field] = $settings[$settings['gateway']][$field] ?? '';
					}
				}
			}
		}

		return $settings;
	}

	public static function sanitize_gateway( string $gateway, array $gateways = [] ) {
		if( empty( $gateways ) ) {
			$gateways = self::gateways();
		}
		return parent::ensure_values_in_array( parent::convert_chars( $gateway, true, 'strtolower' ), array_keys( $gateways ) );
	}

	public static function save_settings( $settings ) {
		$gateways = self::gateways();

		// Save gateway settings
		$result_settings['gateway'] = self::sanitize_gateway( $settings["drplus_sms_gateway"], $gateways );
		foreach( $gateways as $id => $gateway ) {
			foreach( $gateway['fields'] as $field ) {
				$result_settings[$id][$field] = $settings["drplus_sms_{$id}"][$field] ?? '';
			}
		}

		// Save messages settings
		$messages_settings = $settings['drplus_sms_settings'];
		// Auth: Login
		$result_settings['settings']['auth']['login']['enabled'] = !empty( $messages_settings['auth']['login']['enabled'] );
		if( $result_settings['settings']['auth']['login']['enabled'] ) {
			$result_settings['settings']['auth']['login']['pattern'] = parent::convert_chars( $messages_settings['auth']['login']['pattern'] );
			$result_settings['settings']['auth']['login']['otp_timer'] = parent::convert_chars( $messages_settings['auth']['login']['otp_timer'], true, 'absint' );
			$result_settings['messages']['auth']['login'] = sanitize_textarea_field( $messages_settings['auth']['login']['message'] );
		}

		// Auth: Register
		$result_settings['settings']['auth']['register']['enabled'] = !empty( $messages_settings['auth']['register']['enabled'] );
		if( $result_settings['settings']['auth']['register']['enabled'] ) {
			$result_settings['settings']['auth']['register']['pattern'] = parent::convert_chars( $messages_settings['auth']['register']['pattern'] );
			$result_settings['settings']['auth']['register']['otp_timer'] = parent::convert_chars( $messages_settings['auth']['register']['otp_timer'], true, 'absint' );
			$result_settings['messages']['auth']['register'] = sanitize_textarea_field( $messages_settings['auth']['register']['message'] );
		}

		$result_settings['settings']['auth']['one_form'] = $result_settings['settings']['auth']['login']['enabled'] && $result_settings['settings']['auth']['register']['enabled'] && !empty( $messages_settings['auth']['one_form'] );

		// Auth: Forget password
		$result_settings['settings']['auth']['lost_password']['enabled'] = !empty( $messages_settings['auth']['lost_password']['enabled'] );
		if( $result_settings['settings']['auth']['lost_password']['enabled'] ) {
			$result_settings['settings']['auth']['lost_password']['pattern'] = parent::convert_chars( $messages_settings['auth']['lost_password']['pattern'] );
			$result_settings['messages']['auth']['lost_password'] = sanitize_textarea_field( $messages_settings['auth']['lost_password']['message'] );
		}

		update_option( 'drplus_sms_settings', $result_settings, false );
		add_settings_error( 'drplus-sms-settings', 'updated', __( 'Settings updated', 'drplus' ), 'success' );
	}

	public static function variables( $additional = [], $excludes = [] ) {
		$variables = [
			'otp'		=> __( "The OTP code", 'drplus' ),
			'end_time'	=> __( "The end time of the OTP code", 'drplus' ),
			'domain'	=> __( "The domain name", 'drplus' ),
			'name'		=> __( "The website name", 'drplus' ),
		];
		$variables = array_merge( $variables, $additional );
		return parent::unset( $variables, $excludes );
	}

	public static function apply_variables( string $text, $to, string $group, string $type, array $custom_variables = [] ) {
		if( strpos( $text, "{otp}" ) !== false ) {
			$otp = rand( 1000, 9999 );
			$text = str_replace( "{otp}", $otp, $text );
			
			$end_time = parent::convert_chars( date_i18n( 'U' ) ) + self::get_settings()['settings'][$group][$type]['otp_timer'];
			$end_time = date_i18n( "Y-m-d H:i:s", $end_time );
			$text = str_replace( "{end_time}", $end_time, $text );

			$otp_db = new OTP;
			$otp_db->mobile = $to[0];
			$otp_db->otp = $otp;
			$otp_db->expire = Date::maybe_j2g( Utils::convert_chars( $end_time ) );
			$otp_db->new_or_update();
		}

		$text = str_replace( "{name}", get_bloginfo( 'blogname' ), $text );
		$text = str_replace( "{domain}", str_replace( ['http://', 'https://'], '', get_bloginfo( 'url' ) ), $text );

		foreach( $custom_variables as $variable => $value ) {
			$text = str_replace( "{" . $variable . "}", $value, $text );
		}

		return $text;
	}
}