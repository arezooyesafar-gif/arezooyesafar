<?php
namespace DrPlus\DB;

use DrPlus\Utils;
use DrPlus\DB as DB;
use DrPlus\Utils\Sanitizers;

class Booking extends DB {
	public string $table = 'drplus_booking';
	public array $exclude_columns = ['creator'];
	public string $key = 'book_id'; 

	public array $columns = [
		'book_id'			=> 'INT NOT NULL AUTO_INCREMENT',
		'customer_id'		=> 'INT NOT NULL',
		'specialist_id'		=> 'INT NOT NULL',
		'office_id'			=> 'TINYTEXT NOT NULL',
		'date'				=> 'DATE NOT NULL',
		'start_time'		=> 'TIME NOT NULL',
		'end_time'			=> 'TIME NOT NULL',
		'total_price'		=> 'INT(11) NOT NULL',
		'commission'		=> 'INT(11) NULL',
		'specialist_income'	=> 'INT(11) NULL',
		'order_id'			=> 'INT NULL', // wc order_id
		'order_status'		=> 'VARCHAR(20) NOT NULL',
	];
	public array $defaults = [
		'customer_id'		=> 0,
		'specialist_id'		=> 0,
		'office_id'			=> '',
		'date'				=> '',
		'start_time'		=> '',
		'end_time'			=> '',
		'total_price'		=> 0,
		'commission'		=> 0,
		'specialist_income' => 0,
		'order_id'			=> 0,
		'order_status'		=> 'waiting',
	];

	public function sanitize( bool $update = false ) {
		$this->customer_id			= Utils::convert_chars( $this->customer_id, 'sanitize_text_field', 'absint' );
		$this->specialist_id		= Utils::convert_chars( $this->specialist_id, 'sanitize_text_field', 'absint' );
		$this->office_id			= Utils::convert_chars( $this->office_id, 'sanitize_text_field' );
		$this->date					= Utils::convert_chars( $this->date, 'sanitize_text_field' );
		$this->start_time			= Utils::convert_chars( $this->start_time, 'sanitize_text_field' );
		$this->end_time				= Utils::convert_chars( $this->end_time, 'sanitize_text_field' );
		$this->total_price			= Sanitizers::price( $this->total_price );
		$this->commission			= Sanitizers::price( $this->commission );
		$this->specialist_income	= Sanitizers::price( $this->specialist_income );
		$this->order_id				= Utils::convert_chars( $this->order_id, 'sanitize_text_field', 'absint' );
		$this->order_status			= Utils::convert_chars( $this->order_status );
	}
}
new Booking;