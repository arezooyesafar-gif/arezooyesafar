<?php
namespace DrPlus\Utils;

use DrPlus\DB\SpecialistHospitalsRel as DBSpecialistHospitalsRel;
use DrPlus\DB\Specialists as DBSpecialists;
use DrPlus\DB\Times;
use DrPlus\Specialist;
use DrPlus\Utils;
use DrPlus\Utils\SpecialistSpecialitiesRel;
use DrPlus\Utils\SpecialistHospitalsRel;
use DrPlus\Utils\SpecialistInsurancesRel;

class UtilsSpecialists extends Utils {
	private static $hospitals_specialists = [];

	public static function all( $where = [], $attr = [], $columns = [], $only_actives = true ) {
		$specialists = new DBSpecialists;
		if( $only_actives ) {
			$where['AND']['`status`=%s'] = 'active';
		}
		return $specialists->find( $where, $columns, $attr )->data;
	}

	public static function count( $where = [], $attr = [] ) {
		return ( new DBSpecialists )->count( $where, $attr );
	}

	public static function get( $id ) {
		$specialist = new DBSpecialists( absint( $id ) );

		$specialist = $specialist->data;
		$specialist['documents'] = wp_list_pluck( $specialist['documents'], 'attachment_id', 'type' );

		return $specialist;
	}

	public static function get_by_user_id( $user_id = 0, array $where = [], array $columns = [], array $attrs = [] ) : array {
		$user_id = parent::get_user_id( $user_id );
		if( empty( $user_id ) ) return [];
		$specialists = new DBSpecialists;
		$where['AND']['`user_id`=%d'] = $user_id;
		$specialist = $specialists->find( $where, $columns, $attrs )->data[0] ?? [];
		$specialist['offices'] = self::inject_consultation_office( json_decode( $specialist['offices'], true ), Utils::to_bool( $specialist['online_visit'] ) );
		$specialist['meta'] = json_decode( $specialist['meta'], true );
		return $specialist;
	}

	public static function get_by_slug( string $slug, array $where = [], array $columns = [], array $attrs = [] ) : array {
		$specialists = new DBSpecialists;
		$where['AND']['`slug`=%s'] = $slug;
		return $specialists->find( $where, $columns, $attrs )->data[0] ?? [];
	}

	public static function is_user_specialist( $user_id = 0 ) : bool {
		return !empty( self::get_by_user_id( $user_id, [], ['id'] ) );
	}

	public static function new( array $data = [] ) {
		$specialists = new DBSpecialists;
		foreach( $data as $key => $value ) {
			$specialists->$key = $value;
		}
		return $specialists->insert();
	}

	public static function update( int $id, array $data ) {
		$specialists = new DBSpecialists( $id );
		if( empty( $specialists->data ) || empty( $data ) ) return false;

		foreach( $data as $key => $value ) {
			$specialists->$key = $value;
		}
		return $specialists->update();
	}

	public static function save( array $data, int $sid = 0, $old_specialist = null ) {
		/**
		 * If you use `print_r()` or `die` before a `COMMIT` query, the database does not change.
		 */
		if( empty( $data ) || empty( $data['user_id'] ) ) {
			return new \WP_Error( 'user_id_is_empty', __( 'Please select a user', 'drplus' ) );
		}
		$original_data = $data;

		$new = !$sid;
		$user_id = parent::convert_chars( $data['user_id'], true, 'absint' );

		// Reject the specialist
		if( !empty( $data['status'] ) && sanitize_text_field( $data['status'] ) == 'rejected' ) { // Rejected
			$data = [
				'status'	=> 'rejected',
				'reject'	=> $data['reject'],
			];
			if( $new ) {
				$sid = self::new( $data );
				$specialist = new Specialist( $sid );
				do_action( 'drplus/specialist/created', $specialist, $original_data, $data );
			} else {
				self::update( $sid, $data );
				$specialist = new Specialist( $sid );
				do_action( 'drplus/specialist/updated', $specialist, $original_data, $data );
			}
			do_action( 'drplus/specialist/saved', $specialist, $original_data, $data );
			return $sid;
		}
		if( isset( $data['reject'] ) ) {
			$data['reject'] = '';
		}

		if( empty( $old_specialist ) ) {
			$old_specialist = UtilsSpecialists::get_by_user_id( $user_id );
		}
		if( empty( $old_specialist['meta'] ) ) {
			$old_specialist['meta'] = [];
		} else {
			if( parent::is_json( $old_specialist['meta'] ) ) {
				$old_specialist['meta'] = json_decode( $old_specialist['meta'], true );
			}
			if( is_scalar( $old_specialist['meta'] ) ) {
				$old_specialist['meta'] = [];
			}
		}

		// Check user before saving and process the data
		if( !$new ) {
			$specialist = UtilsSpecialists::get( $sid );

			// Show error message if specialist not found
			if( empty( $specialist ) ) {
				return new \WP_Error( 'specialist_not_found', __( 'Specialist not found', 'drplus' ) );
			}
		}

		// Check the slug
		if( isset( $data['slug'] ) ) {
			if( empty( $data['slug'] ) ) {
				unset( $data['slug'] );
			} else {
				// Check for duplicate slug
				$slug = parent::convert_chars( $data['slug'], true, 'sanitize_title_with_dashes' );
				if( !empty( self::get_by_slug( $slug, ['AND' => ['`id`!=%d' => $sid]], ['id'], ['LIMIT' => 1] ) ) ) {
					return new \WP_Error( 'duplicate_slug', __( 'The slug is duplicated.', 'drplus' ) );
				}
			}
		}

		if( !$new ) {
			$data = parent::unset( $data, ['user_id'] );
		}

		if( $data['section'] == 'personal' ) {
			if( !isset( $data['is_verified'] ) ) {
				$data['is_verified'] = 0;
			}
		}

		// Sanitize and validate some info
		if( isset( $data['nid'] ) ) {
			if( !Validators::id_code( $data['nid'] ) ) {
				return new \WP_Error( 'invalid_nid', __( 'Invalid national ID', 'drplus' ) );
			}
		}
		if( isset( $data['meta'] ) ) {
			if( isset( $data['meta']['card_number'] ) ) {
				if( !Validators::card_number( $data['meta']['card_number'] ) ) {
					return new \WP_Error( 'invalid_card_number', __( 'Invalid card number', 'drplus' ) );
				}
			}

			if( isset( $data['meta']['shaba_number'] ) ) {
				if( !Validators::id_code( $data['meta']['shaba_number'] ) ) {
					return new \WP_Error( 'invalid_shaba_number', __( 'Invalid shaba number', 'drplus' ) );
				}
			}
		}

		if( $data['section'] == 'reserve' && empty( $_GET['office'] ) ) {
			$data['offline_visit'] = !empty( $data['offline_visit'] );
			$data['online_visit'] = !empty( $data['online_visit'] );
		}

		global $wpdb;

		$wpdb->query( "START TRANSACTION" );

		// Update user meta and user data
		$user_data_and_meta = ['first_name', 'last_name', 'birthday', 'specialist_code', 'nid', 'mobile', 'gender', 'avatar', 'email'];
		User::update_user( $data, $user_id, false );
		// Remove meta and user data keys to pass other data to custom tables
		$data = parent::unset( $data, $user_data_and_meta );

		// Save specialist
		$db_specialists = new DBSpecialists();
		$specialist_table_data = parent::extract( $data, array_keys( $db_specialists->defaults ) );

		if( isset( $specialist_table_data['documents'] ) ) {
			if( is_array( $specialist_table_data['documents'] ) ) {
				foreach( $specialist_table_data['documents'] as $type => $attachment_id ) {
					$specialist_table_data['documents'][] = [
						'type'			=> $type,
						'attachment_id'	=> $attachment_id
					];
					unset( $specialist_table_data['documents'][$type] );
				}
			} else {
				$specialist_table_data['documents'] = [];
			}
		}

		if( isset( $specialist_table_data['meta'] ) ) {
			if( is_array( $specialist_table_data['meta'] ) ) {
				$specialist_table_data['meta'] = array_merge( $old_specialist['meta'], $specialist_table_data['meta'] );
			} else {
				$specialist_table_data['meta'] = [];
			}
		}

		if( isset( $specialist_table_data['offices'] ) ) {
			$cities_data = [];
			$main_office = parent::convert_chars( $data['main_office'] ?? '' );
			$offices = [];
			$old_offices = $old_specialist['offices'];
			$consultation_office = $old_offices[array_search('consultation', array_column( $old_offices, 'type' ))] ?? [];

			$old_offices_reserve_data = []; // This will store the visit_time and visit_price of each office to combine with office info in the next
			if( !empty( $old_offices ) && parent::is_json( $old_offices ) ) {
				$old_offices = json_decode( $old_offices, true );
				foreach( $old_offices as $old_office ) {
					$old_offices_reserve_data[$old_office['id']] = [
						'visit_time'	=> $old_office['visit_time'],
						'visit_price'	=> $old_office['visit_price'],
						'main'			=> false,
					];
				}
			}
			if( isset( $specialist_table_data['offices']['hospitals'] ) ) {
				foreach( $specialist_table_data['offices']['hospitals'] as $hospital_id ) {
					$hospital_office = [
						'type'	=> 'hospital',
						'id'	=> $hospital_id,
					];

					if( isset( $old_offices_reserve_data[$hospital_id] ) ) {
						$hospital_office = array_merge( $hospital_office, $old_offices_reserve_data[$hospital_id] );
					}

					if( $main_office == $hospital_id ) {
						$hospital_office['main'] = true;
					}
					$offices[] = $hospital_office;

					// Add city and province of hospital to specialist city rel
					$hospital_options = Hospital::get_options( $hospital_id, false, ['city', 'province'] );
					$cities_data[] = [
						'city'		=> $hospital_options['city'],
						'province'	=> $hospital_options['province'],
					];
				}
				unset( $specialist_table_data['offices']['hospitals'] );
			}
			// Store custom offices
			foreach( $specialist_table_data['offices'] as $office ) {
				if( !parent::check_requires( $office, ['name', 'address'] ) ) continue;
				$office['type'] = 'custom';
				$office['id'] = empty( $office['id'] ) ? wp_generate_uuid4() : $office['id'];

				if( isset( $old_offices_reserve_data[$office['id']] ) ) {
					$office = array_merge( $office, $old_offices_reserve_data[$office['id']] );
				}

				if( $main_office == $office['id'] ) {
					$office['main'] = true;
				}
				$offices[] = $office;
				$cities_data[] = [
					'city'		=> $office['city'],
					'province'	=> $office['province'],
				];
			}
			if( empty( $main_office ) && !empty( $offices ) ) {
				// set first item as main
				$offices[0]['main'] = true;
			}
			if( !empty( $consultation_office ) ) $offices[] = $consultation_office;
			$specialist_table_data['offices'] = $offices;

			// Get prev city data
			$prev_city_rel_data = SpecialistCitiesRel::get_user_cities( $user_id );

			// Update city data
			$should_remove = [];
			if( !empty( $prev_city_rel_data ) ) {
				foreach( $prev_city_rel_data as $prev_city_rel ) {
					$should_remove[] = $prev_city_rel['id'];
				}
			}
			if( !empty( $cities_data ) ) {
				foreach( $cities_data as $index => $city_data ) {
					if( !empty( $prev_city_rel_data ) ) {
						foreach( $prev_city_rel_data as $prev_city_rel ) {
							if( $prev_city_rel['city'] == $city_data['city'] && $prev_city_rel['province'] == $city_data['province'] ) {
								$should_remove = array_diff( $should_remove, [$prev_city_rel['id']] );
								unset( $cities_data[$index] );
							}
						}
					}
				}
				if( !empty( $cities_data ) ) {
					SpecialistCitiesRel::add_user_cities( $user_id, $cities_data );
				}
			}
			if( !empty( $should_remove ) ) {
				foreach( $should_remove as $city_rel_id ) {
					SpecialistCitiesRel::delete( $city_rel_id );
				}
			}
		}

		if( $new ) {
			$sid = self::new( $specialist_table_data );
		} else {
			self::update( $sid, $specialist_table_data );
		}

		// Remove specialist data from $data to pass other data to other tables
		$data = parent::unset( $data, array_keys( $db_specialists->defaults ) );

		// Save specialities
		if( !empty( $data['specialities'] ) && is_array( $data['specialities'] ) ) {
			$specialities = $data['specialities'];
			unset( $data['specialities'] );

			if( !$new ) {
				// Get previous specialities
				$old_specialities = SpecialistSpecialitiesRel::get_user_specialities( $user_id );
				$old_specialities_ids = wp_list_pluck( $old_specialities, 'speciality_id' );
				
				// remove not selected specialities
				$should_remove = [];
				foreach( $old_specialities as $old_speciality ) {
					if( !in_array( $old_speciality['speciality_id'], $specialities ) ) {
						$should_remove[] = $old_speciality['id'];
					}
				}
				if( !empty( $should_remove ) ) {
					foreach( $should_remove as $speciality_remove_id ) {
						SpecialistSpecialitiesRel::delete( $speciality_remove_id );
					}
				}
				
				// Add new specialities
				$should_add = array_diff( $specialities, $old_specialities_ids );				
				if( !empty( $should_add ) ) {
					SpecialistSpecialitiesRel::add_user_specialities( $user_id, $should_add );
				}
			} else {
				// Add new specialities
				SpecialistSpecialitiesRel::add_user_specialities( $user_id, $specialities );
			}
		}

		// Save hospital relations
		if( isset( $specialist_table_data['offices'] ) && is_array( $specialist_table_data['offices'] ) ) {
			$hospitals = [];
			foreach( $specialist_table_data['offices'] as $office ) {
				if( !is_array( $office ) || !parent::check_requires( $office, ['type', 'id'] ) || $office['type'] != 'hospital' ) continue;

				$hospitals[] = $office['id'];
			}
			
			if( !$new ) {
				// Get previous hospitals
				$old_hospitals = SpecialistHospitalsRel::get_user_hospitals( $user_id );
				$old_hospitals_ids = wp_list_pluck( $old_hospitals, 'hospital_id' );
				
				// remove not selected hospitals
				$should_remove = [];
				foreach( $old_hospitals as $old_hospital ) {
					if( !in_array( $old_hospital['hospital_id'], $hospitals ) ) {
						$should_remove[] = $old_hospital['id'];
					}
				}
				if( !empty( $should_remove ) ) {
					foreach( $should_remove as $hospital_remove_id ) {
						SpecialistHospitalsRel::delete( $hospital_remove_id );
					}
				}
				
				// Add new hospitals
				$should_add = array_diff( $hospitals, $old_hospitals_ids );
				if( !empty( $should_add ) ) {
					SpecialistHospitalsRel::add_user_hospitals( $user_id, $should_add );
				}
			} else {
				// Add new hospitals
				SpecialistHospitalsRel::add_user_hospitals( $user_id, $hospitals );
			}
		}

		// Save insurance relations
		if( isset( $data['insurances'] ) && is_array( $data['insurances'] ) ) {
			$insurances = $data['insurances'];
			unset( $data['insurances'] );
			
			if( !$new ) {
				// Get previous insurances
				$old_insurances = SpecialistInsurancesRel::get_user_insurances( $user_id );
				$old_insurances_ids = wp_list_pluck( $old_insurances, 'insurance_id' );
				
				// remove not selected insurances
				$should_remove = [];
				foreach( $old_insurances as $old_insurance ) {
					if( !in_array( $old_insurance['insurance_id'], $insurances ) ) {
						$should_remove[] = $old_insurance['id'];
					}
				}
				if( !empty( $should_remove ) ) {
					foreach( $should_remove as $insurance_remove_id ) {
						SpecialistInsurancesRel::delete( $insurance_remove_id );
					}
				}
				
				// Add new insurances
				$should_add = array_diff( $insurances, $old_insurances_ids );				
				if( !empty( $should_add ) ) {
					SpecialistInsurancesRel::add_user_insurances( $user_id, $should_add );
				}
			} else {
				// Add new insurances
				SpecialistInsurancesRel::add_user_insurances( $user_id, $insurances );
			}
		}

		// Save times
		if( $data['section'] == 'reserve' && !empty( $_GET['office'] ) ) {
			$office_id = parent::convert_chars( $_GET['office'] );
			
			// Update visit time and visit price
			$visit_price = Sanitizers::price( $data['visit_price'] );
			$visit_time = parent::ensure_values_in_array( parent::convert_chars( $data['visit_time'] ), array_keys( Booking::reserve_time_chunks() ), '30' );
			$specialist = self::get_by_user_id( $user_id );
			$offices = $specialist['offices'];
			foreach( $offices as $index => $office ) {
				if( $office['id'] == $office_id ) {
					$offices[$index]['visit_time'] = $visit_time;
					$offices[$index]['visit_price'] = $visit_price;
					break;
				}
			}
			self::update( $specialist['id'], ['offices' => $offices] );

			// Remove all user time for current office
			$where['AND']['office=%s'] = $office_id;
			(new Times)->remove_by_user_id( $user_id, $where );
			
			// Set new times
			$times = [];
			if( isset( $data['default_times'] ) && is_array( $data['default_times'] ) ) {
				foreach( $data['default_times'] as $time ) {
					if( empty( $time['from'] ) || empty( $time['to'] ) ) continue;
					$times[] = [
						'from'			=> $time['from'],
						'to'			=> $time['to'],
						'status'		=> $time['status'] ?? false,
						'use_default'	=> false,
						'day'			=> 9,
					];
				}
				unset( $data['default_times'] );
			}
	
			if( isset( $data['days'] ) && is_array( $data['days'] ) ) {
				foreach( $data['days'] as $day ) {
					if( parent::to_bool( $day['default_time'] ?? false ) ) {
						// Use default time
						$times[] = [
							'use_default'	=> true,
							'day'			=> $day['day_index'],
							'status'		=> $day['status'] ?? false
						];
					} else {
						if( empty( $day['times'] ) ) continue;
						foreach( $day['times'] as $time ) {
							if( empty( $time['from'] ) || empty( $time['to'] ) ) continue;
							$times[] = [
								'from'			=> $time['from'],
								'to'			=> $time['to'],
								'use_default'	=> false,
								'day'			=> $day['day_index'],
								'status'		=> $day['status'] ?? false
							];
						}
					}
				}
				unset( $data['days'] );
			}

			// Insert into DB
			foreach( $times as $time ) {
				$db_time = new Times();
				$db_time->user_id = $user_id;
				$db_time->office = $office_id;
				$db_time->day = $time['day'];
				$db_time->from = !empty( $time['from'] ) ? $time['from'] . ":00" : "00:00:00";
				$db_time->to = !empty( $time['to'] ) ? $time['to'] . ":00" : "00:00:00";
				$db_time->use_default = $time['use_default'];
				$db_time->status = $time['status'];
				$db_time->new();
			}
		}

		$wpdb->query( 'COMMIT' );

		$specialist = new Specialist( $sid );
		if( $new ) {
			do_action( 'drplus/specialist/created', $specialist, $original_data, $data );
		} else {
			do_action( 'drplus/specialist/updated', $specialist, $original_data, $data );
		}
		do_action( 'drplus/specialist/saved', $specialist, $original_data, $data );
		return $sid;
	}

	public static function delete( int $id ) {
		$specialists = new DBSpecialists( absint( $id ) );
		if( empty( $specialists->data ) ) return false;
		return $specialists->delete();
	}

	public static function activate( int $id ) {
		return self::update( $id, [
			'status'	=> 'active'
		] );
	}

	public static function deactivate( int $id ) {
		return self::update( $id, [
			'status'	=> 'inactive'
		] );
	}

	public static function get_specialists_by_user_query( array $args = [] ) : array {
		$args['specialists'] = true;
		$specialists = [];
		$users = new \WP_User_Query( $args );
		if( $results = $users->get_results() ) {
			foreach( $results as $user ) {
				$specialists[] = new Specialist( 0, $user );
			}
		}
		return $specialists;
	}

	/**
	 * Create different lists of specialists
	 *
	 * @param array $settings Elementor settings
	 * @param array $mode Accepts: offline_visits | online_visits | all
	 * @return void HTML
	 */
	public static function list( array $settings = [], string $mode = 'all', array $specialists = [] ) {
		$mode = Utils::ensure_values_in_array( $mode, ['offline_visits', 'online_visits', 'all'], 'all' );

		if( empty( $specialists ) ) {
			$query_type = parent::ensure_values_in_array( sanitize_text_field( $settings['query_type'] ), ['default', 'by_id'], 'default' );

			$orderby = !empty( $settings['orderby'] ) ? $settings['orderby'] : 'login';
			if( $orderby === 'id' ) {
				$settings['orderby'] = 'ID';
			}
			$user_query_args = [
				'only_verified'			=> isset( $settings['only_verified'] ) && parent::to_bool( $settings['only_verified'] ),
				'only_offline_visits'	=> isset( $settings['only_offline_visits'] ) && parent::to_bool( $settings['only_offline_visits'] ),
				'only_online_visits'	=> isset( $settings['only_online_visits'] ) && parent::to_bool( $settings['only_online_visits'] ),
				'include'				=> $query_type == 'default' || empty( $settings['query_include_ids'] ) ? [] : array_unique( array_filter( array_map( fn( $user_id ) => parent::convert_chars( $user_id, true, 'absint' ), $settings['query_include_ids'] ) ) ),
				'number'				=> parent::convert_chars( $settings['ppp'], true, 'absint' ),
				'offset'				=> parent::convert_chars( $settings['offset'], true, 'absint' ),
				'paged'					=> Archive::get_paged(),
				'order'					=> !empty( $settings['order'] ) ? strtoupper( $settings['order'] ) : 'ASC',
				'orderby'				=> $orderby,
			];

			$specialists = self::get_specialists_by_user_query( $user_query_args );
		}
		self::list_html( [
			'specialists'	=> $specialists,
			'settings'		=> $settings,
			'mode'			=> $mode,
		] );
	}

	public static function list_html( $args ) {
		$args = parent::check_default( $args, [
			'specialists'	=> [],
			'settings'		=> [
				'style'					=> 'card-1',
				'only_verified'			=> false,
				'only_offline_visits'	=> false,
				'only_online_visits'	=> false,
				'style_args'			=> [], // Pass to template part
			],
			'mode'			=> 'all',
			'remove_wrap'	=> false,
		] );
		$settings = $args['settings'];

		if( !$args['remove_wrap'] ) {
			$display_attributes = Elementor::get_display_attributes( $settings );
		}
		$wrap_classes = ['wrapper', 'specialists', "specialists-style-{$settings['style']}"];

		$is_card = in_array( $settings['style'], ['card-1', 'card-2'] );
		if( $is_card ) {
			$wrap_classes[] = 'specialists-style-card';
		}

		if( isset( $settings['only_verified'] ) && parent::to_bool( $settings['only_verified'] ) ) {
			$wrap_classes[] = 'verified-specialists';
		}
		if( isset( $settings['only_offline_visits'] ) && parent::to_bool( $settings['only_offline_visits'] ) ) {
			$wrap_classes[] = 'offline-visits';
		}
		if( isset( $settings['only_online_visits'] ) && parent::to_bool( $settings['only_online_visits'] ) ) {
			$wrap_classes[] = 'online-visits';
		}
		$wrap_attrs = [
			'class'	=> $wrap_classes,
		];
		if( !$args['remove_wrap'] ) {
			$wrap_attrs['class'] = array_merge( $wrap_attrs['class'], $display_attributes['classes'] );
		}

		if( !$args['remove_wrap'] ) {
			echo '<div ' . parent::get_html_attributes( $wrap_attrs ) . '>';
		}

		foreach( $args['specialists'] as $specialist ) {
			if( empty( $specialist->ID ) ) {
				continue;
			}
			$item_classes = ['specialist', "specialist-{$specialist->ID}", "specialist-user-{$specialist->user_id}", 'slider-slide'];

			if( $is_card ) {
				$item_classes[] = 'specialist-card';
			}
			
			if( !empty( $specialist->offline_visit ) ) {
				$item_classes[] = 'offline-visit';
			}
			if( !empty( $specialist->online_visit ) ) {
				$item_classes[] = 'online-visit';
			}
			if( !empty( $specialist->is_verified ) ) {
				$item_classes[] = 'verified';
			}

			$item_attrs = [
				'class'		=> $item_classes,
				'data-id'	=> $specialist->user_id,
			];
			echo '<div ' . parent::get_html_attributes( $item_attrs ) . '>';
			$style_args = [
				'specialist'	=> $specialist,
				'mode'			=> $args['mode'] == 'all' ? ( $specialist->online_visit ? 'online_visits' : 'offline_visits' ) : $args['mode'],
				'name-tag'		=> $settings['name-tag'] ?? 'h2',
				'short_bio-tag'	=> $settings['short_bio-tag'] ?? 'div',
				'verified-text'	=> $settings['verified-text'] ?? '',
			];
			get_template_part( 'templates/specialists/template-specialists', $settings['style'], array_merge( $style_args, $args['settings']['style_args'] ) );
			echo '</div>';
		}
		
		if( !$args['remove_wrap'] ) {
			echo '</div>';
		}
	}

	/**
	 * Get specialist page link
	 *
	 * @param int|array $specialist
	 * @return string The URL of the page
	 */
	public static function get_page_link( $specialist ) : string {
		$url = home_url( '/specialist' );
		if( is_array( $specialist ) && !empty( $specialist['slug'] ) ) {
			return "{$url}/{$specialist['slug']}";
		}

		if( is_numeric( $specialist ) ) {
			$specialist = self::get( $specialist );
			return "{$url}/{$specialist['slug']}";
		}

		if( is_object( $specialist ) && is_a( $specialist, 'DrPlus\Specialist' ) ) {
			return "{$url}/{$specialist->slug}";
		}
		return "";
	}

	/**
	 * Searches for specialists using a text query.
	 *
	 * @param string $text The search text.
	 * @param array $args Optional. Additional query arguments.
	 * @param string $return Optional. Return format: 'object' (default) for Specialist objects, 'query' for WP_User_Query, or raw results.
	 * @return array|\WP_User_Query Returns results based on $return.
	 */
	public static function search( string $text, array $args = [], string $return = 'object' ) {
		$args = parent::check_default( $args, [
			'search'        => '*' . $text . '*',
			'fields'        => 'ID',
			'number'        => 5,
			'count_total'   => false,
		] );
		$args['specialists'] = true;

		$query = new \WP_User_Query( $args );
		if( $return == 'query' ) {
			return $query;
		}

		$results = $query->get_results();
		if( !empty( $results ) && $return == 'object' ) {
			$results = array_map( fn( $user_id ) => new Specialist( null, $user_id ), $results );
		}
		return $results;
	}

	public static function get_identity_types_terms() : array {
		static $types = null;
		if( $types === null ) {
			$terms = get_terms( [
				'taxonomy'		=> 'identity_type',
				'hide_empty'	=> false,
			] );
			$types = [];
			foreach( $terms as $term ) {
				if( !$term->name ) continue;
				$types[] = [
					'name'			=> $term->name,
					'description'	=> $term->description,
				];
			}
		}
		return $types;
	}

	public static function get_insurances_terms() : array {
		static $insurances = null;
		if( $insurances === null ) {
			$terms = get_terms( [
				'taxonomy'		=> 'insurance',
				'hide_empty'	=> false,
			] );
			$insurances = [];
			foreach( $terms as $term ) {
				if( !$term->name ) continue;
				$insurances[] = [
					'id'			=> $term->term_id,
					'name'			=> $term->name,
					'description'	=> $term->description,
					'icon'			=> get_term_meta( $term->term_id, 'icon', true ),
				];
			}
		}
		return $insurances;
	}

	public static function get_identity_max_upload_size( bool $add_suffix = true, int $decimal_places = 0 ) {
		static $max_upload_size = null;
		if( $max_upload_size === null ) {
			$default = parent::get_max_upload_size();
			$options = Options::get_options( [
				'specialist_identity_max_upload_size'	=> parent::convert_bytes_to_mb( $default, false ),
			] );
			$max_upload_size = parent::convert_mb_to_bytes( $options['specialist_identity_max_upload_size'] );
			if( $max_upload_size > $default ) {
				$max_upload_size = $default;
			}
		}
		if( $add_suffix ) {
			return parent::convert_bytes_to_mb( $max_upload_size, $add_suffix, $decimal_places );
		} else {
			return $max_upload_size;
		}
	}

	public static function get_current_specialist() {
		static $specialist = null;
		if( $specialist === null ) {
			if( !is_user_logged_in() ) {
				$specialist = new Specialist();
			}
			$specialist = new Specialist( null, wp_get_current_user() );
		}
		return $specialist;
	}

	public static function statuses() {
		return [
			'pending'		=> __( "Pending", 'drplus' ),
			'incomplete'	=> __( "Incomplete", 'drplus' ),
			'active'		=> __( "Active", 'drplus' ),
			'inactive'		=> __( "Inactive", 'drplus' ),
			'rejected'		=> __( "Rejected", 'drplus' ),
		];
	}

	public static function get_hospital_specialists( $hospital_id = 0, int $limit = 10, int $offset = 0 ) : array {
		$hospital_id = parent::get_post_id( $hospital_id );
		$hospital_specialists = [];

		// Local cache
		$local_cache_key = "{$hospital_id}-{$limit}-{$offset}";
		if( isset( self::$hospitals_specialists[$local_cache_key] ) ) {
			return self::$hospitals_specialists[$local_cache_key];
		}

		$specialist_hospitals_rel_table = (new DBSpecialistHospitalsRel)->table;
		$specialists_db = new DBSpecialists;
		$specialists_table = $specialists_db->table;

		$query = "SELECT DISTINCT * FROM `{$specialists_table}` LEFT JOIN `{$specialist_hospitals_rel_table}` ON `{$specialists_table}`.`user_id`=`{$specialist_hospitals_rel_table}`.`user_id` WHERE `{$specialist_hospitals_rel_table}`.`hospital_id`=%d LIMIT %d, %d";
		$specialists = $specialists_db->query( $query, [
			$hospital_id,
			$offset,
			$limit,
		] );
		if( !empty( $specialists ) ) {
			foreach( $specialists as $specialist ) {
				$hospital_specialists[] = new Specialist( $specialist );
			}
		}

		self::$hospitals_specialists[$local_cache_key] = $hospital_specialists;
		return self::$hospitals_specialists[$local_cache_key];
	}

	public static function get_specialist_post_id( $specialist ) : int {
		$post_id = get_posts( [			
			'post_type'		=> 'specialist',
			'meta_query'	=> [
				[
					'key'     => '_drplus_specialist_id',
					'value'   => $specialist->ID,
					'compare' => '='
				]
			],
			'post_status'	=> 'any',
			'numberposts'	=> 1,
			'fields'		=> 'ids'
		] );
		return !empty( $post_id ) ? $post_id[0] : 0;
	}

	public static function get_province_and_city_for_post( $specialist ) {
		// Get main office for city
		$specialist_province = '';
		$specialist_city = '';
		if( !empty( $specialist->offices ) ) {
			$main_office = [];
			$offices = parent::obj_to_array( $specialist->offices, true );
			foreach( $offices as $office ) {
				if( empty( $office['main'] ) ) continue;
				$main_office = $office;
				break;
			}
			if( !empty( $main_office ) ) {
				$main_office = $offices[0];
			}
			
			if( $main_office['type'] == 'hospital' ) {
				$hospital_info = Hospital::get_options( $main_office['id'] );
				$main_office['province'] = $hospital_info['province'];
				$main_office['city'] = $hospital_info['city'];
			}

			if( !empty( $main_office['province'] ) ) {
				$specialist_province = $main_office['province'];
			}
			if( !empty( $main_office['city'] ) ) {
				$specialist_city = $main_office['city'];
			}
		}
		return [
			'province'	=> $specialist_province,
			'city'		=> $specialist_city,
		];
	}

	public static function inject_consultation_office( $offices, $online_visit ) {
		$is_exists = false;
		foreach( $offices as $office ) {
			if( $office['type'] == 'consultation' ) {
				$is_exists = true;
				break;
			}
		}
		if( !$is_exists ) {
			$offices[] = [
				'type'			=> 'consultation',
				'id'			=> 'consultation',
				'name'			=> esc_html__( 'Online Consultation', 'drplus' ),
				'visit_time'	=> '30',
				'visit_price'	=> '',
				'main'			=> false,
			];
		}

		return $offices;
	}
}