<?php

use DrPlus\Components\Button;
use DrPlus\Specialist;
use DrPlus\Utils\WC;

$show_save_button = true;
$disabled_save_button = false;
$back_link = wc_get_account_endpoint_url( 'specialist-dashboard' );

$user_id = get_current_user_id();
$specialist = new Specialist( null, $user_id );

$sections = WC::specialist_profile_sections();
$current_section = WC::get_current_specialist_profile_section();
if( $current_section != 'dashboard' && $current_section != 'specialist-appointments' ) {
	?>
	<h2 class="drplus-myaccount-page-title"><?php echo esc_html( $sections[$current_section]['label'] ) ?></h2>
	<form action="" method="post" class="drplus-specialist-form">
		<?php wp_nonce_field( 'drplus_specialist-save', 'nonce' ) ?>
		<input type="hidden" name="section" value="<?php echo esc_attr( $current_section ) ?>">
		<input type="hidden" name="user_id" value="<?php echo esc_attr( $user_id ) ?>">
	<?php
}

include( DRPLUS_DIR . "woocommerce/myaccount/custom-links/specialist-dashboard/{$current_section}.php" );

if( $current_section != 'dashboard' ) {
	?>
	<div class="drplus-specialist-form-actions">
		<?php
		if( $show_save_button ) {
			Button::view( [
				'text'			=> __( "Save", 'drplus' ),
				'icon'			=> 'drplus-icon-tick-circle',
				'icon_align'	=> 'start',
				'fullwidth'		=> true,
				'small'			=> true,
				'classes'		=> ['onboard-next-btn'],
				'id'			=> 'onboard-submit',
				'disabled'		=> $disabled_save_button
			] );
		}
		Button::view( [
			'type'			=> 'bordered',
			'text'			=> __( "Back to dashboard", 'drplus' ),
			'link'			=> $back_link,
			'small'			=> true,
			'fullwidth'		=> true,
			'icon'			=> is_rtl() ? 'drplus-icon-left' : 'drplus-icon-right',
			'icon_align'	=> 'end',
			'align'			=> 'end',
		] );
		?>
	</div>
	<?php if( $current_section != 'specialist-appointments' ) { ?>
		</form>
	<?php } ?>
	<?php
}