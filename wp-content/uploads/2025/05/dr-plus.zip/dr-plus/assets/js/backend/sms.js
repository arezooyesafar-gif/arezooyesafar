(function($) {
	const prefix = 'drplus_sms_';
	$(document).ready(function(){
		// Change tab
		$(`.${prefix}sidebar-item`).on('click', function() {
			if( $(this).hasClass('active') ) return;

			if( $(this).hasClass(`${prefix}sidebar-sub-item`) ) { // Sub item
				let tab = $(this).closest(`.${prefix}sidebar-item.has-subitems`).attr('data-tab'),
					section = $(this).attr('data-section');
				$(`#${prefix}${tab}-content .${prefix}section-content`).hide();
				$(`#${prefix}${tab}-content #${prefix}${tab}-${section}-content`).slideDown();
			} else { // Main item
				let tab = $(this).attr('data-tab');
				$(`.${prefix}tab-content`).hide();
				$(`#${prefix}${tab}-content`).slideDown();
				$(this).siblings('.active').find(`.${prefix}sidebar-sub-items`).slideUp();
				$(this).find(`.${prefix}sidebar-sub-items`).slideDown({
					start: function() {
						$(this).css({
							display: 'flex'
						});
					}
				});
			}
			$(this).siblings('.active').removeClass('active');
			$(this).addClass('active');
		})

		// Show gateway settings
		$(`.${prefix}gateway`).on('click', function() {
			$(this).siblings('.active').removeClass('active');
			$(this).addClass('active');

			let gateway = $(this).attr('data-id');

			$(`.${prefix}gateway-fields`).hide();
			$(`.${prefix}gateway-${gateway}-fields`).show();
		})

		// Enable/Disable fields
		$(`.${prefix}status-switch`).on('change', function() {
			let fields = [
				`.${prefix}settings-gateway-select`,
				`.${prefix}settings-from`,
				`.${prefix}settings-pattern`,
				`.${prefix}settings-message`,
				`.${prefix}settings-otp_timer`,
			];
			$(this).closest('table').find(fields.join(',')).prop('disabled', !$(this).prop('checked'));
		})

		// Show pattern code field when a service gateway selected
		$(`.${prefix}gateway`).on('click', function() {
			let gateway = $(this).attr('data-id'),
				pattern = $(`.${prefix}settings-gateway-pattern-row`),
				patternDescription = $(`.${prefix}pattern-description`);
			if( drplusSMS.gateways[gateway].is_service ) {
				pattern.show();
				patternDescription.show();
			} else {
				pattern.hide();
				patternDescription.hide();
			}
		})

		// Enable/Disable one form switch
		$(`#${prefix}settings-auth-login-status, #${prefix}settings-auth-register-status`).on('change', function() {
			let oneFormWrap = $(`#${prefix}settings-auth-one_form-wrap`),
				oneForm = $(`#${prefix}settings-auth-one_form`);
			if($(`#${prefix}settings-auth-login-status`).prop('checked') && $(`#${prefix}settings-auth-register-status`).prop('checked')) {
				oneFormWrap.removeClass('disabled');
				oneForm.prop('disabled', false);
			} else {
				oneFormWrap.addClass('disabled');
				oneForm.prop('disabled', true);
			}
		})
	});
})(jQuery);