<?php
namespace DrPlus\Options;

use DrPlus\Utils;
return;
class Save {
	public static function save( $response ) {
		$options = $response['options'];

		$styler = [
			'body_color' => [
				'selector'	=> ':root',
				'variables'	=> [
					'body'	=> [
						'type'	=> 'color',
					],
				],
			],
			'text_main_color' => [
				'selector'	=> ':root',
				'variables'	=> [
					'text-main'	=> [
						'type'	=> 'color',
					],
				],
			],

			'primary_color_100' => [
				'selector'	=> ':root',
				'variables'	=> [
					'primary-100'	=> [
						'type'	=> 'color',
					],
					'primary-100-50'	=> [
						'type'			=> 'color',
						'value_suffix'	=> '80'
					],
				],
			],
			'primary_color_200' => [
				'selector'	=> ':root',
				'variables'	=> [
					'primary-200'	=> [
						'type'	=> 'color',
					],
				],
			],
			'primary_color_300' => [
				'selector'	=> ':root',
				'variables'	=> [
					'primary-300'	=> [
						'type'	=> 'color',
					],
				],
			],
			'primary_color_400' => [
				'selector'	=> ':root',
				'variables'	=> [
					'primary-400'	=> [
						'type'	=> 'color',
					],
				],
			],
			'primary_color_500' => [
				'selector'	=> ':root',
				'variables'	=> [
					'primary-500'	=> [
						'type'	=> 'color',
					],
				],
			],
			'primary_color_hover' => [
				'selector'	=> ':root',
				'variables'	=> [
					'primary-hover'	=> [
						'type'	=> 'color',
					],
				],
			],

			'secondary_color_100' => [
				'selector'	=> ':root',
				'variables'	=> [
					'secondary-100'	=> [
						'type'	=> 'color',
					],
				],
			],
			'secondary_color_200' => [
				'selector'	=> ':root',
				'variables'	=> [
					'secondary-200'	=> [
						'type'	=> 'color',
					],
				],
			],
			'secondary_color_300' => [
				'selector'	=> ':root',
				'variables'	=> [
					'secondary-300'	=> [
						'type'	=> 'color',
					],
				],
			],
			'secondary_color_400' => [
				'selector'	=> ':root',
				'variables'	=> [
					'secondary-400'	=> [
						'type'	=> 'color',
					],
				],
			],
			'secondary_color_500' => [
				'selector'	=> ':root',
				'variables'	=> [
					'secondary-500'	=> [
						'type'	=> 'color',
					],
				],
			],
			'secondary_color_hover' => [
				'selector'	=> ':root',
				'variables'	=> [
					'secondary-hover'	=> [
						'type'	=> 'color',
					],
				],
			],

			'tertiary_color_100' => [
				'selector'	=> ':root',
				'variables'	=> [
					'tertiary-100'	=> [
						'type'	=> 'color',
					],
				],
			],
			'tertiary_color_200' => [
				'selector'	=> ':root',
				'variables'	=> [
					'tertiary-200'	=> [
						'type'	=> 'color',
					],
				],
			],
			'tertiary_color_300' => [
				'selector'	=> ':root',
				'variables'	=> [
					'tertiary-300'	=> [
						'type'	=> 'color',
					],
					
				],
			],
			'tertiary_color_400' => [
				'selector'	=> ':root',
				'variables'	=> [
					'tertiary-400'	=> [
						'type'	=> 'color',
					],
				],
			],
			'tertiary_color_500' => [
				'selector'	=> ':root',
				'variables'	=> [
					'tertiary-500'	=> [
						'type'	=> 'color',
					],
				],
			],

			'gray_color_100' => [
				'selector'	=> ':root',
				'variables'	=> [
					'gray-100'	=> [
						'type'	=> 'color',
					],
				],
			],
			'gray_color_200' => [
				'selector'	=> ':root',
				'variables'	=> [
					'gray-200'	=> [
						'type'	=> 'color',
					],
				],
			],
			'gray_color_300' => [
				'selector'	=> ':root',
				'variables'	=> [
					'gray-300'	=> [
						'type'	=> 'color',
					],
				],
			],
			'gray_color_400' => [
				'selector'	=> ':root',
				'variables'	=> [
					'gray-400'	=> [
						'type'	=> 'color',
					],
				],
			],
			'gray_color_500' => [
				'selector'	=> ':root',
				'variables'	=> [
					'gray-500'	=> [
						'type'	=> 'color',
					],
					'gray-500-20'	=> [
						'type'			=> 'color',
						'value_suffix'	=> '33'
					],
					'gray-500-50'	=> [
						'type'			=> 'color',
						'value_suffix'	=> '80'
					],
				],
			],
			'gray_color_600' => [
				'selector'	=> ':root',
				'variables'	=> [
					'gray-600'	=> [
						'type'	=> 'color',
					],
					'gray-600-50'	=> [
						'type'			=> 'color',
						'value_suffix'	=> '80'
					],
					'gray-600-75'	=> [
						'type'			=> 'color',
						'value_suffix'	=> 'bf'
					],
				],
			],
			'gray_color_700' => [
				'selector'	=> ':root',
				'variables'	=> [
					'gray-700'	=> [
						'type'	=> 'color',
					],
				],
			],

			'text_color_100' => [
				'selector'	=> ':root',
				'variables'	=> [
					'text-100'	=> [
						'type'	=> 'color',
					],
					'text-100-70'	=> [
						'type'			=> 'color',
						'value_suffix'	=> 'b3'
					],
				],
			],
			'text_color_200' => [
				'selector'	=> ':root',
				'variables'	=> [
					'text-200'	=> [
						'type'	=> 'color',
					],
				],
			],
			'text_color_300' => [
				'selector'	=> ':root',
				'variables'	=> [
					'text-300'	=> [
						'type'	=> 'color',
					],
				],
			],
			'text_color_400' => [
				'selector'	=> ':root',
				'variables'	=> [
					'text-400'	=> [
						'type'	=> 'color',
					],
					'text-400-50'	=> [
						'type'			=> 'color',
						'value_suffix'	=> '80'
					],
				],
			],
			'text_color_500' => [
				'selector'	=> ':root',
				'variables'	=> [
					'text-500'	=> [
						'type'	=> 'color',
					],
				],
			],
			'text_color_600' => [
				'selector'	=> ':root',
				'variables'	=> [
					'text-600'	=> [
						'type'	=> 'color',
					],
				],
			],

			'input_bg'	=> [
				'selector'	=> ':root',
				'variables'	=> [
					'input-bg'	=> [
						'type'	=> 'background-color',
					],
				],
			],
			'input_text'	=> [
				'selector'	=> ':root',
				'variables'	=> [
					'input-text'	=> [
						'type'	=> 'color',
					],
				],
			],

			'widget_bg' => [
				'selector'	=> '.widget',
				'type'		=> 'background-color',
			],
			'widget_title_bg' => [
				'selector'	=> '.widget .widgettitle',
				'type' => 'background-color'
			],
			'widget_title_color' => [
				'selector' => '.widget .widgettitle',
				'type' => 'color'
			],
			'widget_text_color' => [
				'selector' => '.widget',
				'type' => 'color'
			],
			'widget_links_color' => [
				'selector' => '.widget a',
				'type' => 'color'
			],

			'header_bg' => [
				'selector'	=> '#header-container',
				'variables'	=> [
					'header-bg'	=> [
						'type'		=> 'background-color',
					]
				]
			],
			'header_logo_color' => [
				'selector'	=> '#site-logo',
				'type'		=> 'color',
			],
			'sticky_header_logo_color' => [
				'selector'	=> 'body.sticky-header-active #site-logo',
				'type'		=> 'color',
			],

			'header-btn-bg-color' => [
				'selector'	=> '#header-account',
				'type'		=> 'background-color'
			],
			'header-btn-color' => [
				'selector'	=> '.header-account-icon',
				'type'		=> 'color'
			],

			'footer_bg' => [
				'selector'	=> '#site-footer',
				'type'		=> 'background',
			],

			'main-typography' => [
				'selector'	=> ':root',
				'variables'	=> [
					'main-font'	=> [
						'type'	=> 'font-family',
					]
				]
			],
			'breadcrumb-typography' => [
				'selector'	=> '#breadcrumb-wrap',
				'type'		=> 'typography',
			],
			'archive-title-typography' => [
				'selector'	=> '.page-title, #page-title',
				'type'		=> 'typography',
			],
			'post-title-typography' => [
				'selector'	=> '#post-title',
				'type'		=> 'typography',
			],
			'h1-typography' => [
				'selector'	=> 'h1',
				'type'		=> 'typography',
			],
			'h2-typography' => [
				'selector'	=> 'h2',
				'type'		=> 'typography',
			],
			'h3-typography' => [
				'selector'	=> 'h3',
				'type'		=> 'typography',
			],
			'h4-typography' => [
				'selector'	=> 'h4',
				'type'		=> 'typography',
			],
			'h5-typography' => [
				'selector'	=> 'h5',
				'type'		=> 'typography',
			],
			'h6-typography' => [
				'selector'	=> 'h6',
				'type'		=> 'typography',
			],
			'header-logo-typography' => [
				'selector'	=> '#site-logo',
                'type'		=> 'typography',
			],
			'header-menu-1-typography' => [
				'selector'	=> '#bottom-header-menu',
				'type'		=> 'typography',
			],
			'header-menu-2-typography' => [
				'selector'	=> '#bottom-header-second-menu',
				'type'		=> 'typography',
			],
			'forms-btn-typography' => [
				'selector'	=> 'button, .button, input:is([type="button"], [type="submit"], [type="reset"])',
				'type'		=> 'typography',
			],
			'forms-input-typography' => [
				'selector'	=> 'input:is([type="text"], [type="password"], [type="tel"], [type="url"], [type="date"], [type="datetime-local"], [type="search"], [type="email"], [type="month"], [type="number"], [type="time"], [type="week"]), textarea, select',
				'type'		=> 'typography',
			],
			'shop-regular-price-typography' => [
				'selector' => '.price ins, .price>.amount',
				'type' => 'typography',
			],
			'shop-sale-price-typography' => [
				'selector' => '.price>del',
				'type' => 'typography',
			],
			'booking-search-row-bg'	=> [
				'selector'	=> '#booking-specialist_section .booking_search-head',
				'type'		=> 'background',
			],
			'footer-menu-1-typography' => [
				'selector'	=> '#footer-menu-wrap:first-child',
				'type'		=> 'typography'
			],
			'footer-menu-2-typography' => [
				'selector'	=> '#footer-menu-wrap:last-child',
				'type'		=> 'typography'
			],
			'footer-about-typography' => [
				'selector'	=> '#footer-about-text',
				'type'		=> 'typography'
			],
			'footer-more_info_title-typography'	=> [
				'selector'	=> '#footer-more-info-title',
				'type'		=> 'typography'
			],
			'footer-more_info_subtitle-typography'	=> [
				'selector'	=> '#footer-more-info-subtitle',
				'type'		=> 'typography'
			],
			'footer-phones-typography'	=> [
				'selector'	=> '#footer-more-info-phones',
				'type'		=> 'typography'
			],
			'footer-contact_subtitle-typography'	=> [
				'selector'	=> '#footer-more-info-contact-subtitle',
				'type'		=> 'typography'
			],
			'footer-copyright-typography' => [
				'selector'	=> '#footer-copyright',
				'type'		=> 'typography'
			],
		];
	
		$css_content_array = [];
		foreach( $styler as $option => $data ) {
			if( empty( $options[$option] ) ) continue;
	
			if( !isset( $css_content_array[$data['selector']] ) ) $css_content_array[$data['selector']] = [];
	
			$selector_properties = [];
			if( !isset( $data['variables'] ) ) {
				$type = $data['type'];
				if( $type == 'background' ) {
					$selector_properties = array_filter( Utils::unset( $options[$option], ['media'] ) );
					if( !empty( $selector_properties['background-image'] ) ) {
						$selector_properties['background-image'] = "url({$selector_properties['background-image']})";
					}
					if( !empty( $selector_properties['background-color'] ) ) {
						$selector_properties['background-color'] = Utils::minify_hex( $selector_properties['background-color'] );
					}
				} else if( $type == 'typography' ) {
					$selector_properties = array_filter( Utils::unset( $options[$option], ['font-options', 'google'] ) );
					if( isset( $selector_properties['font-size'] ) && str_ends_with( $selector_properties['font-size'], "rem" ) ) {
						$selector_properties['font-size'] = floatval( $selector_properties['font-size'] ) . "rem";
					}
				} else if( $type == 'color' ) {
					$selector_properties['color'] = Utils::minify_hex( $options[$option] );
				} else if( $type == 'background-color' ) {
					$selector_properties['background'] = Utils::minify_hex( $options[$option] );
				} else if( $type == 'border-color' ) {
					$selector_properties['border-color'] = Utils::minify_hex( $options[$option] );
				} else if( $type == 'border-bottom' ) {
					if( $options[$option]['border-style'] === 'none' ) {
						$selector_properties['border-bottom'] = '0';
					} else {
						$selector_properties['border-bottom'] = "{$options[$option]['border-bottom']} {$options[$option]['border-style']} " . Utils::minify_hex( $options[$option]['border-color'] );
					}
				}
			} else { // Has variables
				foreach( $data['variables'] as $variable => $variable_data ) {
					if( !isset( $variable_data['type'] ) ) continue;
	
					$variable = strpos( $variable, "--" ) === 0 ? $variable : "--{$variable}";
					$value = '';
					if( $variable_data['type'] == 'color' ) {
						$value = Utils::minify_hex( $options[$option] );
					} else if( $variable_data['type'] == 'font-family' ) {
						$value = $options[$option]['font-family'];
					} else if( $variable_data['type'] == 'background-color' ) {
						$value = Utils::minify_hex( $options[$option] );
					}
					if( isset( $variable_data['value_suffix'] ) ) {
						$value .= $variable_data['value_suffix'];
					}
					$selector_properties[$variable] = $value;
				}
			}
	
			if( !empty( $data['important'] ) ) {
				$selector_properties = array_map( fn( $value ) => "{$value}!important", $selector_properties );
			}
	
			$css_content_array[$data['selector']] = array_merge( $css_content_array[$data['selector']], $selector_properties );
		}
		$css_content_array = array_filter( $css_content_array );
	
		// Reposition selectors
		if( !empty( $css_content_array[":root"] ) ) {
			$selector_positions = [
				':root',
				'html',
				'body',
				'h1',
				'h2',
				'h3',
				'h4',
				'h5',
				'h6',
	
				// Forms
				'button, .button, input:is([type="button"], [type="submit"], [type="reset"])',
				'input:is([type="text"], [type="password"], [type="tel"], [type="url"], [type="date"], [type="datetime-local"], [type="search"], [type="email"], [type="month"], [type="number"], [type="time"], [type="week"]), textarea, select',
				
				// Header
				'#header-container',
				'#site-logo',
				'body.sticky-header-active #site-logo',
				'.header-account',
				'.header-account-icon',
				'#bottom-header-menu',
				'#bottom-header-second-menu',
	
				// Content
				'#breadcrumb-wrap',
				'.page-title, #page-title',
				'#page-header, .woocommerce-products-header',
				'#post-title',

				// Shop
				'.price ins, .price>.amount',
				'.price>del',

				// Booking
				'#booking-specialist_section .booking_search-head',

				// Footer
				'#site-footer',
				'#footer-menu-wrap:first-child',
				'#footer-menu-wrap:last-child',
				'#footer-about-text',
				'#footer-more-info-title',
				'#footer-more-info-subtitle',
				'#footer-more-info-phones',
				'#footer-more-info-contact-subtitle',
				'#footer-copyright',
			];
			foreach( $selector_positions as $key => $value ) {
				if( is_int( $key ) ) {
					$selector = $value;
					$position = $key;
				} else {
					$selector = $key;
					$position = $value;
				}
				Utils::reposition_array_element( $css_content_array, $selector, $position );
			}
		}
	
		$css_content = '';
		foreach( $css_content_array as $selector => $properties ) {
			$selector = str_replace( ", ", ",", $selector );
			$css_content .= $selector . '{';
			$last_property = array_key_last( $properties );
			foreach( $properties as $property => $value ) {
				$css_content .= "{$property}:{$value}";
				if( $property != $last_property ) {
					$css_content .= ";";
				}
			}
			$css_content .= "}";
		}
		
		@file_put_contents( wp_upload_dir()['basedir'] . "/drplus.css", $css_content );
	
		update_option( 'drplus_custom_style_version', time(), false );
		
		return $response;
	}
}
add_filter( 'redux/options/drplus/ajax_save/response', [Save::class, 'save'] );