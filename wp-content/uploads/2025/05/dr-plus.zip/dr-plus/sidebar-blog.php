<?php
if( !defined( 'ABSPATH' ) || !class_exists( "DrPlus\Utils" ) ) exit;

?>
<div id="sidebar" class="sidebar sidebar-archive sidebar-blog col-md-3 col-sm-12">
	<div id="widget-area" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 'blog' ); ?>
	</div>
</div>