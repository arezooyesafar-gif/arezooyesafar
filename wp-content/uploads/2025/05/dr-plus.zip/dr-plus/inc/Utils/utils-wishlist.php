<?php
namespace DrPlus\Utils;

use DrPlus\DB\Wishlist as DBWishlist;
use DrPlus\Utils;

class Wishlist extends Utils {
	public static function get_user_wishlist( $user_id = 0, array $where = [], array $columns = [], array $attrs = [] ) {
		if( !is_user_logged_in() ) return [];
		$user_id = parent::get_user_id( $user_id );

		$where['AND']['`user_id`=%d'] = $user_id;

		$wishlist = new DBWishlist();
		$wishlist->find( $where, $columns, $attrs );

		return $wishlist->data;
	}

	public static function is_in_wishlist( $product_id, $user_id = 0 ) {
		if( !is_user_logged_in() ) return false;
		
		$user_id = parent::get_user_id( $user_id );

		if( empty( $user_id ) ) $user_id = get_current_user_id();

		$wishlist = new DBWishlist();
		
		$wishlist->find( [
			'AND'	=> [
				'`product_id`=%d'	=> $product_id,
				'`user_id`=%d'	=> $user_id
			]
		] );

		return !empty( $wishlist->data ) ? true : false;
	}

	public static function add_to_wishlist( $product_id, $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		
		$wishlist = new DBWishlist();
		$wishlist->product_id = $product_id;
		$wishlist->user_id = $user_id;
		return $wishlist->insert();
	}

	public static function remove_from_wishlist_by_id( $id ) {
		$wishlist = new DBWishlist( $id );
		if( empty( $wishlist->data ) ) return;
		return $wishlist->delete();
	}

	public static function remove_from_wishlist( $product_id, $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );

		$wishlist = new DBWishlist();
		$wishlist->find( [
			'AND'	=> [
				'`product_id`=%d'	=> parent::convert_chars( $product_id, true, 'absint' ),
				'`user_id`=%d'	=> parent::convert_chars( $user_id, true, 'absint' ),
			]
		] );
		if( empty( $wishlist->data ) ) return;
		return $wishlist->delete();
	}
}