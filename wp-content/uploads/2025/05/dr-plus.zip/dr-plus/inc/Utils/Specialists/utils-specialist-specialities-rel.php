<?php
namespace DrPlus\Utils;

use DrPlus\DB\SpecialistSpecialitiesRel as DBSpecialistSpecialitiesRel;
use DrPlus\Utils;

class SpecialistSpecialitiesRel extends Utils {
	public static function all( $where = [], $columns = [], $attrs = [] ) {
		$specialists_rel = new DBSpecialistSpecialitiesRel;
		return $specialists_rel->find( $where, $columns, $attrs )->data;
	}

	public static function get( $id ) {
		$specialists_rel = new DBSpecialistSpecialitiesRel( absint( $id ) );
		return $specialists_rel->data;
	}

	public static function find( $where = [], $attr = [] ) {
		$specialists_rel = new DBSpecialistSpecialitiesRel;
		return $specialists_rel->find( $where, [], $attr )->data;
	}

	public static function new( $data ) {
		$specialists_rel = new DBSpecialistSpecialitiesRel;
		foreach( $data as $key => $value ) {
			$specialists_rel->$key = $value;
		}
		return $specialists_rel->insert();
	}

	public static function update( $id, $data ) {
		$specialists_rel = new DBSpecialistSpecialitiesRel( absint( $id ) );
		if( empty( $specialists_rel->data ) ) return false;

		foreach( $data as $key => $value ) {
			$specialists_rel->$key = $value;
		}
		return $specialists_rel->update()->data;
	}

	public static function delete( $id ) {
		$specialists_rel = new DBSpecialistSpecialitiesRel( absint( $id ) );
		if( empty( $specialists_rel->data ) ) return false;
		return $specialists_rel->delete();
	}

	/**
	 * Add user specialities
	 *
	 * @param int $user_id
	 * @param array $specialities array of speciality ids (NOT DB ids)
	 * @return void
	 */
	public static function add_user_specialities( $user_id, $specialities ) {
		foreach( $specialities as $speciality ) {
			self::new( [
				'user_id'		=> $user_id,
				'speciality_id'	=> $speciality
			] );
		}
	}

	public static function get_user_specialities( $user_id ) {
		$user_id = Utils::get_user_id( $user_id );
		if( empty( $user_id ) ) return false;
		$specialists_rel = new DBSpecialistSpecialitiesRel;
		$where = [];
		$where = [
			'AND'	=> [
				'`user_id`=%d'	=> $user_id
			]
		];
		return $specialists_rel->find( $where )->data ?? [];
	}

	public static function count( bool $only_actives = true, $where = [], $attrs = [] ) : int {
		$specialists_rel = new DBSpecialistSpecialitiesRel;
		if( $only_actives ) {
			global $wpdb;
			$where['AND']["`{$wpdb->prefix}drplus_specialists`.`status`=%s"] = 'active';

			$attrs = Utils::unset( $attrs, ['LIMIT', 'OFFSET'] );

			$query = "SELECT COUNT(`{$specialists_rel->table}`.`{$specialists_rel->key}`) as counts FROM `{$specialists_rel->table}` LEFT JOIN `{$wpdb->prefix}drplus_specialists` ON `{$specialists_rel->table}`.`user_id` = `{$wpdb->prefix}drplus_specialists`.`user_id`";
			$query = $specialists_rel->query_creator( $query, $where, $attrs );
			return $wpdb->get_row( $query )->counts ?? 0;
		} else {
			return $specialists_rel->count( $where, $attrs );
		}
	}
}