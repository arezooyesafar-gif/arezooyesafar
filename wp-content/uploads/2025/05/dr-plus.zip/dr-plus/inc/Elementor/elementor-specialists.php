<?php
namespace DrPlus\Elementor;

use DrPlus\ElementorControls;
use DrPlus\Utils;
use DrPlus\Utils\Elementor;
use DrPlus\Utils\UtilsSpecialists;

class Specialists extends \Elementor\Widget_Base {
	public function get_name() {
		return 'drplus_specialists';
	}

	public function get_title() {
		return esc_html__( 'Specialists (Doctor Plus)', 'drplus' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return ['drplus', 'basic'];
	}

	public function get_keywords() {
		return ['counselor', 'doctor', 'advise', 'online', 'offline', 'visit', 'consultant', 'مشاور', 'دکتر', 'ویزیت', 'آنلاین', 'ثبت', 'پذیرش'];
	}

	protected function register_controls() {
		ElementorControls::specialists_query_control( $this );
		ElementorControls::display_settings( $this, [
			'controls'	=> [
				'desktop_slides_space'	=> [
					'default'	=> 16,
				],
				'desktop_cols'	=> [
					'default'	=> 4,
				],
				'desktop_gap'	=> [
					'default'	=> 16,
				],
				'tablet_slider'	=> [
					'default'	=> 'no',
				],
				'tablet_slides_space'	=> [
					'default'	=> 16,
				],
				'tablet_cols'	=> [
					'default'	=> 2,
				],
				'tablet_gap'	=> [
					'default'	=> 16,
				],
				'mobile_slides_space'	=> [
					'default'	=> 16,
				],
				'mobile_cols'	=> [
					'default'	=> 1,
				],
				'mobile_gap'	=> [
					'default'	=> 16,
				],
			],
		] );
		ElementorControls::specialists_seo_control( $this );
		ElementorControls::pagination_controls( $this, [
			'controls'	=> [
				'ppp'		=> [
					'label'	=> esc_html__( "Specialists per page", 'drplus' ),
				],
				'offset'	=> [
					'description'	=> esc_html__( 'The offset causes the first few results to be skipped and provides the number of specialists from that point onward.', 'drplus' ),
				],
			],
		] );
		ElementorControls::section_title_settings( $this, [
			'controls'	=> [
				'title'	=> [
					'default'	=> esc_html__( "Our specialists", 'drplus' )
				],
				'icon'	=> [
					'default'	=> [
						'value'		=> 'drplus-icon-clock-fill',
						'library'	=> 'drplus-icon',
					],
				],
				'link'	=> [
					'default'	=> [
						'url'	=> home_url( "/specialists" ),
					]
				],
			],
		] );
		$show_button_condition = [
			'button_show_button'	=> 'yes'
		];
		ElementorControls::button_settings( $this, [
			'section'	=> [
				'label'	=> esc_html__( 'Show all button', 'drplus' )
			],
			'controls'	=> [
				'show_button'	=> [
					'label'			=> esc_html__( "Show button", 'drplus' ),
					'type'			=> \Elementor\Controls_Manager::SWITCHER,
					'label_on'		=> esc_html__( 'Yes', 'drplus' ),
					'label_off'		=> esc_html__( 'No', 'drplus' ),
					'return_value'	=> 'yes',
					'default'		=> 'yes',
					'_position'		=> 0,
				],
				'text'	=> [
					'default'	=> esc_html__( 'Show all', 'drplus' ),
					'condition'	=> $show_button_condition,
				],
				'link'	=> [
					'condition'	=> $show_button_condition,
					'default'	=> [
						'url'	=> home_url( "/specialists" )
					]
				],
				'new_tab'	=> [
					'condition'	=> $show_button_condition,
				],
				'transparent'	=> [
					'condition'	=> $show_button_condition,
				],
				'type'	=> [
					'condition'	=> array_merge( $show_button_condition, ['button_transparent!' => 'yes'] ),
					'default'	=> 'gray',
				],
				'small'	=> [
					'condition'	=> $show_button_condition,
					'default'	=> 'yes'
				],
				'icon'	=> [
					'condition'	=> $show_button_condition,
					'default'	=> [
						'value'		=> is_rtl() ? 'drplus-icon-arrow-square-left' : 'drplus-icon-arrow-square-right',
						'library'	=> 'drplus-icon',
					],
				],
				'icon_align'	=> [
					'condition'	=> $show_button_condition,
					'default'	=> 'end',
				],
				'style'	=> [
					'condition'	=> $show_button_condition,
				],
				'align'	=> [
					'condition'	=> $show_button_condition,
					'default'	=> 'end'
				],
				'fullwidth'	=> [
					'condition'	=> $show_button_condition,
				],
			],
		] );

		ElementorControls::section_title_styles( $this );

		// Card styles
		ElementorControls::specialists_card_style_control( $this, 'all' );

		ElementorControls::pagination_style_controls( $this );

		// Button styles
		ElementorControls::general_style_controls( $this, [ // button_wrap_
			'prefix'		=> 'button_wrap_',
			'base_selector'	=> '.specialist-read-more-btn',
			
			'section'	=> [
				'name'	=> 'button_wrap_',
				'label'	=> esc_html__( 'Show all button', 'drplus' ),
			],

			'mode'	=> 'wrap',
		] );
		ElementorControls::general_style_controls( $this, [ // button_icon_
			'prefix'		=> 'button_icon_',
			'base_selector'	=> '.specialist-read-more-btn',
			'selector'		=> '.button-icon',
			
			'section'	=> [
				'name'	=> 'button_icon_',
				'label'	=> esc_html__( 'Show all button icon', 'drplus' ),
			],

			'mode'	=> 'icon',
		] );
		ElementorControls::general_style_controls( $this, [ // button_text_
			'prefix'		=> 'button_text_',
			'base_selector'	=> '.specialist-read-more-btn',
			'selector'		=> '.button-text',
			
			'section'	=> [
				'name'	=> 'button_text_',
				'label'	=> esc_html__( 'Show all button text', 'drplus' ),
			],

			'mode'	=> 'text',
		] );
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$display_attributes = Elementor::get_display_attributes( $settings );

		$attributes = [
			'class'	=> array_merge( [
				'drplus-slider-wrap',
				'specialists-slider-wrap',
			], $display_attributes['wrap_classes'] ),
			'data-settings'	=> $display_attributes['args'],
			'style'			=> $display_attributes['style'],
		];
		?>
		<div <?php echo Utils::get_html_attributes( $attributes ) ?>>
			<?php if( !empty( $settings['section_title_title'] ) ) { ?>
				<div class="drplus-slider-head specialists-slider-head">
					<?php
					get_template_part( "templates/components/template-components-section_title", null, [
						'icon'		=> $settings['section_title_icon'],
						'tag'		=> $settings['section_title_tag'],
						'title'		=> $settings['section_title_title'],
						'link'		=> $settings['section_title_link'],
						'nav_btns'	=> true,
						'classes'	=> ['specialists-section-title'],
					] );
					if( Utils::to_bool( $settings['button_show_button'] ) ) {
						$button_args = Elementor::get_button_args( $settings );
						$button_args['prefix'] = 'button_';
						$button_args['button_classes'][] = 'specialist-read-more-btn';
						get_template_part( "templates/components/template-components-button", null, $button_args );
					}
					?>
				</div>
			<?php } ?>
			<?php UtilsSpecialists::list( $settings ) ?>
		</div>
		<?php
	}
}