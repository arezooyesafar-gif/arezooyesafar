<?php
namespace DrPlus\AJAX;

use DrPlus\AJAX;
use DrPlus\Utils;

class GetUsers extends AJAX {
	public static function get_instance() {
		static $instance = null;
		if( $instance === null ) {
			$instance = new self;
		}
		return $instance;
	}

	public function __construct() {
		return $this;
	}

	public function get_users() {
		$this->set_request_data();

		$type = !empty( $this->data['type'] ) ? Utils::convert_chars( $this->data['type'] ) : 'users';
		$type = Utils::ensure_values_in_array( $type, ['users', 'specialists', 'non_specialists'], 'users' );

		$search_term = Utils::convert_chars( $this->data['name'] );

		$get_users_args = [
			'search'	=> "*{$search_term}*",
			'number'	=> 50,
		];
		if( $type == 'specialists' ) {
			$get_users_args['specialists'] = true;
		} else if( $type == 'non_specialists' ) {
			$get_users_args['specialists'] = false;
		}

		$users = [];
		foreach( get_users( $get_users_args ) as $user ) {
			$users[] = [
				'id'	=> $user->ID,
				'text'	=> "{$user->display_name} ({$user->user_email})",
			];
		}

		$this->result( 'success', $users );
	}
}