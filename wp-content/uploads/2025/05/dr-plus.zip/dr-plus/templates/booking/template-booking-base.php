<?php

use DrPlus\Components\Alert;
use DrPlus\Utils\Booking;

if( !Booking::is_booking_active() ) {
	esc_html_e( 'Booking is not active', 'drplus' );
	return;
}

$booking_url = Booking::get_booking_page_url();
$active_step = Booking::get_current_step();

// Next step
$next_step = $active_step;
$booking_steps = Booking::booking_steps();
$next_step_index = array_search( $active_step, array_keys( $booking_steps ) ) + 1;
if( $next_step_index < count( $booking_steps ) ) {
	$next_step = array_keys( $booking_steps )[$next_step_index];
}
$next_step_url = stripslashes( $booking_url ) . $next_step;

if( !empty( $_SESSION['booking']['error'] ) ) {
	Alert::view( [
		'type'		=> 'error',
		'icon'		=> 'drplus-icon-error',
		'text'		=> $_SESSION['booking']['error_message'],
		'classes'	=> ['booking-alert'],
	] );
	unset( $_SESSION['booking']['error'] );
	unset( $_SESSION['booking']['error_message'] );
}
?>

<?php if( $active_step == 'specialist' ) { ?>

	<div id="booking-<?php echo esc_attr( $active_step ) ?>_section" class="booking_wrap" data-section="<?php echo esc_attr( $active_step ) ?>">
		<?php get_template_part( "templates/booking/template-booking-step", $active_step, [
			'booking_url'	=> $booking_url
		] ); ?>
	</div>

<?php } else { ?>

	<form method="post" action="<?php echo $next_step_url ?>" id="booking-form">
		<?php wp_nonce_field( "booking_step_{$active_step}", 'booking_nonce' ) ?>

		<div id="booking-<?php echo esc_attr( $active_step ) ?>_section" class="booking_wrap" data-section="<?php echo esc_attr( $active_step ) ?>">
			<?php get_template_part( "templates/booking/template-booking-step", $active_step, [
				'booking_url'	=> $booking_url
			] ); ?>
		</div>
	</form>

<?php } ?>