<?php

namespace DrPlus\Backend\Specialists;

use DrPlus\Utils\AdminUI;
use DrPlus\Utils\Formatters;

class SpecialistFinancial extends SpecialistView {
	public static function view() {
		$specialist = parent::$specialist;
		$user_data = $specialist['meta'];

		AdminUI::input_with_label( [
			'label'			=> esc_html__( 'Card number', 'drplus' ),
			'type'			=> 'text',
			'value'			=> !empty( $user_data->card_number ) ? Formatters::card_number( $user_data->card_number ) : "",
			'id'			=> parent::$PREFIX . "card_number",
			'name'			=> parent::$PREFIX . "meta[card_number]",
			'input_classes'	=> ['regular-text', 'ltr', 'drplus-card-number-input'],
			'inputmode'		=> 'numeric',
			'minlength'		=> 19,
			'maxlength'		=> 19,
		] );
		AdminUI::input_with_label( [
			'label'			=> esc_html__( 'SHABA number', 'drplus' ),
			'type'			=> 'text',
			'value'			=> !empty( $user_data->shaba_number ) ? Formatters::shaba_number( $user_data->shaba_number ) : "",
			'id'			=> parent::$PREFIX . "shaba_number",
			'name'			=> parent::$PREFIX . "meta[shaba_number]",
			'input_classes'	=> ['regular-text', 'ltr', 'drplus-shaba-number-input'],
			'inputmode'		=> 'numeric',
			'minlength'		=> 32,
			'maxlength'		=> 32,
			'placeholder'	=> 'IR...'
		] );
	}
}