<?php
namespace DrPlus\Backend;

use DrPlus\Utils;

class Messages {
	public static function server_messages() {
		// Get messages from server
		$url = "https://mjkhajeh.ir/api/mj/messages";
		$url = add_query_arg( "product", 'drplus', $url );
		$url = add_query_arg( "version", DRPLUS_VERSION, $url );
		$url = add_query_arg( "include_publics", true, $url );

		$user_dismissed_messages = self::get_dismissed_messages();
		if( !empty( $user_dismissed_messages ) ) {
			$url = add_query_arg( 'excludes', implode( ",", $user_dismissed_messages ), $url );
		}
		$messages = wp_remote_get( $url );
		if( !is_wp_error( $messages ) ) {
			$messages = json_decode( wp_remote_retrieve_body( $messages ) );
			if( !empty( $messages ) ) {
				if( DRPLUS_DEV ) {
					wp_enqueue_script( 'drplus-notices', DRPLUS_URI . "assets/js/notices.js", ['jquery'], DRPLUS_VERSION, true );
				} else {
					wp_enqueue_script( 'drplus-notices', DRPLUS_URI . "assets/js/notices.min.js", ['jquery'], DRPLUS_VERSION, true );
				}
				wp_localize_script( 'drplus-notices', 'drplus_notices', [
					'ajaxUrl'	=> admin_url( 'admin-ajax.php' ),
					'nonce'		=> wp_create_nonce( 'drplus_dismiss_notice' ),
				] );
				foreach( $messages as $message ) {
					?>
					<div class="drplus_notice notice notice-<?php echo sanitize_html_class( $message->type ) ?><?php echo $message->dismissible ? ' is-dismissible' : '' ?>" data-id="<?php echo esc_attr( $message->id ) ?>"><?php echo wpautop( $message->message ) ?></div>
					<?php
				}
			}
		}
	}

	private static function get_dismissed_messages( $user_id = 0 ) {
		$user_id = Utils::convert_chars( $user_id, true, 'absint' );
		if( $user_id === 0 && is_user_logged_in() ) {
			$user_id = get_current_user_id();
		}

		$ids = get_user_meta( $user_id, 'dismissed_messages', true );
		if( empty( $ids ) || !is_array( $ids ) ) {
			$ids = [];
		}
		return $ids;
	}
}
add_action( 'admin_notices', [Messages::class, 'server_messages'] );