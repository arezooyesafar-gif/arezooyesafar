<?php
namespace DrPlus\Backend\Specialists;

use DrPlus\DB;
use DrPlus\Specialist;
use DrPlus\Utils;
use DrPlus\Utils\UtilsSpecialists;
use DrPlus\Utils\SpecialistSpecialitiesRel;

class SpecialistListTable extends \WP_List_Table {
	private static $searched_users = [];
	private static $searched_user_ids = [];

	/** Class constructor */
	public function __construct() {
		parent::__construct( [
			'singular' => __( 'Specialist', 'drplus' ), //singular name of the listed records
			'plural' => __( 'Specialists', 'drplus' ), //plural name of the listed records
			'ajax' => false	//should this table support ajax?
		] );
	}

	/**
	* Retrieve specialists’s data from the database
	*
	* @param int $per_page
	* @param int $page_number
	*
	* @return mixed
	*/
	public static function get_specialists( $per_page = 5, $page_number = 1 ) {
		$limit = $per_page;
		$offset = ( $page_number - 1 ) * $per_page;
		$where = [];

		// If search is not set, get users from founded specialists
		if( !empty( $_REQUEST['s'] ) ) {
			$specialists = UtilsSpecialists::search( $_REQUEST['s'], [
				'number'	=> $limit,
				'offset'	=> $offset,
			] );
		} else {
			$attr = [
				'ORDER BY'	=> 'id DESC',
				'LIMIT'		=> "{$offset}, {$limit}"
			];
			if( !empty( $_GET['status'] ) ) {
				$where['AND']['`status`=%s'] = Utils::convert_chars( $_GET['status'] );
			}
			$db_specialists = UtilsSpecialists::all( $where, $attr, [], false );
			if( empty( $db_specialists ) ) return [];
			$specialists = array_map( fn( $db_specialist ) => new Specialist( $db_specialist ), $db_specialists );
		}
		if( empty( $specialists ) ) return [];

		$specialities = get_posts( [
			'post_type'		=> 'speciality',
			'post_status'	=> 'publish',
			'numberposts'	=> -1,
			'post__in'		=> array_values( array_unique( Utils::array_flatten( wp_list_pluck( $specialists, 'specialities' ) ) ) ),
		] );
		if( !empty( $specialities ) ) {
			foreach( $specialists as $specialist_index => $specialist ) {
				foreach( $specialities as $speciality ) {
					if( in_array( $speciality->ID, $specialist->specialities ) ) {
						$specialist_speciality_index = array_search( $speciality->ID, $specialist->specialities );
						$specialists[$specialist_index]->specialities[$specialist_speciality_index] = $speciality;
					}
				}
			}
		}

		return $specialists;
	}

	/**
	* Delete a specialist record.
	*
	* @param int $id specialist ID
	*/
	public static function delete_specialist( $id ) {
		UtilsSpecialists::delete( $id );
	}

	public function no_items() {
		_e( 'No specialists available.', 'drplus' );
	}

	/**
	* Method for name column
	*
	* @param array $item an array of DB data
	*
	* @return string
	*/
	function column_name( $item ) {
		// create a nonce
		$delete_nonce = wp_create_nonce( "drplus_delete_specialist-{$item->ID}" );
		
		$edit_link = add_query_arg( [
			'tab'	=> 'view',
			'sid'	=> $item->ID
		] );
		$title = '<a href="' . $edit_link . '"><strong>' . $item->display_name . '</strong></a>';
		$title .= " - " . UtilsSpecialists::statuses()[$item->status];
		$view_link = home_url( '/' . trailingslashit( 'specialist' ) . $item->slug );
		
		$actions = [
			'edit'	=> sprintf( '<a href="%s">%s</a>', $edit_link, esc_html__( 'Edit', 'drplus' ) ),
			'delete' => sprintf( '<a href="?page=%s&action=%s&specialist=%s&_wpnonce=%s">%s</a>', esc_attr( $_GET['page'] ), 'delete', absint( $item->ID ), $delete_nonce, esc_html__( 'Remove', 'drplus' ) ),
		];

		if( $item->status == 'active' ) {
			$actions['view'] = sprintf( '<a href="%s">%s</a>', $view_link, esc_html__( 'View', 'drplus' ) );
		}
		
		return $title . $this->row_actions( $actions );
	}

	public function get_views() {
		$current = !empty( $_GET['status'] ) ? Utils::convert_chars( $_GET['status'] ) : 'all';

		$items = [
			'all'	=> [
				'label'	=> __( "All", 'drplus' ),
				'count'	=> UtilsSpecialists::count(),
			],
			'pending'	=> [
				'label'	=> __( "Pending to review", 'drplus' ),
				'count'	=> 0,
			],
			'active'	=> [
				'label'	=> __( "Active", 'drplus' ),
				'count'	=> 0,
			],
			'inactive'	=> [
				'label'	=> __( "Inactive", 'drplus' ),
				'count'	=> 0,
			],
			'incomplete'	=> [
				'label'	=> __( "Incomplete", 'drplus' ),
				'count'	=> 0,
			],
			'rejected'	=> [
				'label'	=> __( "Rejected", 'drplus' ),
				'count'	=> 0,
			],
		];

		$views = [];
		foreach( $items as $status => $data ) {
			if( $status == 'all' ) {
				$url = admin_url( 'admin.php?page=specialists' );
			} else {
				$url = add_query_arg( 'status', $status );
				$data['count'] = UtilsSpecialists::count( ['AND' => ['`status`=%s' => $status]] );
			}
			$views[$status] = sprintf(
				'<a href="%s"%s>%s <span class="count">(%s)</span></a>',
				esc_url( $url ),
				$current === $status ? ' class="current"' : '',
				$data['label'],
				$data['count']
			);
		}
	
		return $views;
	}

	/**
	* Render a column when no column specific method exists.
	*
	* @param array $item
	* @param string $column_name
	*
	* @return mixed
	*/
	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'image':
				return get_avatar( $item->user_id, 64 );
			case 'specialities':
				$text = [];
				foreach( $item->specialities as $speciality ) {
					$text[] = '<a href="' . get_edit_post_link( $speciality->id ) . '">' . $speciality->post_title . '</a>';
				}
				return implode( ', ', $text );
			default:
				return print_r( $item, true ); //Show the whole array for troubleshooting purposes
		}
	}

	/**
	* Returns the count of records in the database.
	*
	* @return null|string
	*/
	public static function record_count() {
		$where = [];
		if( !empty( $_REQUEST['s'] ) ) {
			$search_term = Utils::convert_chars( $_REQUEST['s'] );
			self::$searched_users = get_users( [
				'search'	=> '*' . $search_term . '*',
				'fields'	=> 'ID',
			] );
			$where = [
				'AND'	=> [
					"`user_id` IN (" . DB::placeholder( self::$searched_user_ids, '%d' ) . ")"	=> self::$searched_user_ids
				]
			];
		}
		return UtilsSpecialists::count( $where );
	}

	/**
	* Render the bulk edit checkbox
	*
	* @param array $item
	*
	* @return string
	*/
	function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="bulk-delete[]" value="%s" />', $item->ID
		);
	}

	/**
	* Associative array of columns
	*
	* @return array
	*/
	function get_columns() {
		$columns = [
			'cb'			=> '<input type="checkbox" />',
			'image'			=> __( 'Image', 'drplus' ),
			'name'			=> __( 'Name', 'drplus' ),
			'specialities'	=> __( 'Specialities', 'drplus' ),
		];
		
		return $columns;
	}

	/**
	* Columns to make sortable.
	*
	* @return array
	*/
	public function get_sortable_columns() {
		$sortable_columns = [];
		
		return $sortable_columns;
	}

	/**
	* Returns an associative array containing the bulk action
	*
	* @return array
	*/
	public function get_bulk_actions() {
		$actions = [
			'bulk-delete' => 'Delete'
		];
		
		return $actions;
	}

	/**
	* Handles data query and filter, sorting, and pagination.
	*/
	public function prepare_items() {

		$this->_column_headers = $this->get_column_info();
		
		/** Process bulk action */
		$this->process_bulk_action();
		
		$per_page = $this->get_items_per_page( 'specialists_per_page', 12 );
		$current_page = $this->get_pagenum();
		$total_items = self::record_count();
		
		$this->set_pagination_args( [
			'total_items' => $total_items, //WE have to calculate the total number of items
			'per_page' => $per_page //WE have to determine how many items to show on a page
		] );
		
		$this->items = self::get_specialists( $per_page, $current_page );
	}

	public function process_bulk_action() {
		// Detect when a bulk action is being triggered...
		if ( 'delete' === $this->current_action() ) {
			$item_id = absint( $_GET['specialist'] );
			// In our file that handles the request, verify the nonce.
			$nonce = esc_attr( $_REQUEST["_wpnonce"] );
		
			if ( ! wp_verify_nonce( $nonce, "drplus_delete_specialist-{$item_id}" ) ) {
				die( esc_html__( 'Unable to remove specialist', 'drplus' ) );
			} else {
				self::delete_specialist( $item_id );
			
				wp_redirect( esc_url( add_query_arg() ) );
				exit;
			}
		}
		
		// If the delete bulk action is triggered
		if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'bulk-delete' ) || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'bulk-delete' ) ) {
			$delete_ids = esc_sql( $_POST['bulk-delete'] );
			// loop over the array of record IDs and delete them
			foreach ( $delete_ids as $id ) {
				self::delete_specialist( $id );
			}
		
			wp_redirect( esc_url( add_query_arg() ) );
			exit;
		}
	}
}