<?php

use DrPlus\Utils;
use DrPlus\Utils\User;

if( !function_exists( "drplus_orderby_random_user_query" ) ) {
	function drplus_orderby_random_user_query( $query ) {
		if( $query->query_vars["orderby"] === "rand" ) {
			$query->query_orderby = str_replace( "user_login", "RAND()", $query->query_orderby );
		}
	}
}
add_action( 'pre_user_query', 'drplus_orderby_random_user_query' );

// Enhanced search
if( !function_exists( "drplus_enhanced_user_search_columns" ) ) {
	function drplus_enhanced_user_search_columns( $columns, $search, $query ) {
		if( !empty( $query->query_vars['search'] ) ) {
			global $wpdb;

			$query->query_from .= " LEFT JOIN {$wpdb->usermeta} AS fm ON {$wpdb->users}.ID = fm.user_id AND fm.meta_key = 'first_name' ";
			$query->query_from .= " LEFT JOIN {$wpdb->usermeta} AS lm ON {$wpdb->users}.ID = lm.user_id AND lm.meta_key = 'last_name' ";

			$columns[] = 'fm.meta_value';
			$columns[] = 'lm.meta_value';
		}

		return $columns;
	}
}
add_filter( 'user_search_columns', 'drplus_enhanced_user_search_columns', 10, 3 );

// Custom avatar
if( !function_exists( "drplus_change_avatar" ) ) {
	function drplus_change_avatar( $avatar, $id_or_email, $size, $default, $alt, $args ) {
		if( is_a( $id_or_email, 'WP_Comment' ) ) {
			$id_or_email = !empty( $id_or_email->user_id ) ? $id_or_email->user_id : $id_or_email->comment_author_email;
		}
		$user = Utils::get_user_object( $id_or_email );
		if( !empty( $user ) ) {
			$avatar_id = User::get_avatar_id( $user->ID );
			if( $avatar_id ) {
				$args['alt'] = $alt;
				$avatar = wp_get_attachment_image( $avatar_id, [$size, $size], false, $args );
			}
		}
		return $avatar;
	}
}
add_filter( 'get_avatar', 'drplus_change_avatar', 1, 6 );

if( !function_exists( "drplus_change_avatar_url" ) ) {
	function drplus_change_avatar_url( $url, $id_or_email, $args ) {
		if( is_a( $id_or_email, 'WP_Comment' ) ) {
			$id_or_email = !empty( $id_or_email->user_id ) ? $id_or_email->user_id : $id_or_email->comment_author_email;
		}
		$user = Utils::get_user_object( $id_or_email );
		if( !empty( $user ) ) {
			$avatar_id = User::get_avatar_id( $user->ID );
			if( $avatar_id ) {
				$url = wp_get_attachment_image_url( $avatar_id, [$args['size'], $args['size']] );
			}
		}
		return $url;
	}
}
add_filter( 'get_avatar_url', 'drplus_change_avatar_url', 10, 3 );

function drplus_allow_users_upload_files() {
    if ( ! current_user_can( 'upload_files' ) ) {
        $user = wp_get_current_user();
        $user->add_cap( 'upload_files' );
    }
}
add_action( 'init', 'drplus_allow_users_upload_files' );