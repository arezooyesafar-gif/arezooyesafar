<?php
namespace DrPlus\DB;

use DrPlus\DB as DB;
use DrPlus\Utils;

class Times extends DB {
	public string $table = 'drplus_times';
	public array $exclude_columns = ['deleted'];

	public array $columns = [
		'id'			=> 'INT NOT NULL AUTO_INCREMENT',
		'user_id'		=> 'INT NOT NULL',
		'office'		=> 'TINYTEXT NOT NULL',
		'day'			=> 'TINYINT NOT NULL',
		'from'			=> 'TIME NULL',
		'to'			=> 'TIME NULL',
		'use_default'	=> 'BOOLEAN',
		'status'		=> 'BOOLEAN',
	];
	public array $defaults = [
		'user_id'		=> 0,
		'office'		=> '',
		'day'			=> 0,
		'from'			=> '00:00:00',
		'to'			=> '00:00:00',
		'use_default'	=> false,
		'status'		=> 1,
	];

	public function sanitize( bool $update = false ) {
		$this->user_id		= Utils::convert_chars( $this->user_id, true, 'absint' );
		$this->office		= Utils::convert_chars( $this->office );
		$this->day			= Utils::convert_chars( $this->day );
		$this->day			= Utils::absint_pro( $this->day, 0, 9 );
		$this->from			= Utils::convert_chars( $this->from );
		$this->to			= Utils::convert_chars( $this->to );
		$this->use_default	= Utils::to_bool( $this->use_default );
		$this->status		= Utils::to_bool( $this->status );

		// Check from and to values
		foreach( ['from', 'to'] as $time ) {
			// Convert to string to extract the time only
			if( is_numeric( $time ) ) {
				$time = date_i18n( "H:i:s", $time );
			}
		}
	}

	/**
	 * Find times by user id
	 *
	 * @param mixed $user_id
	 * @param null|integer $status if null status will be ignored
	 * @param array $where
	 * @param array $columns
	 * @param array $attrs
	 * @return object|false $this
	 */
	public function find_by_user_id( $user_id = 0, $status = 1, array $where = [], array $columns = [], array $attrs = [] ) {
		$user_id = Utils::get_user_id( $user_id );
		if( empty( $user_id ) ) return false;

		if( $status !== null ) {
			$where['AND']['`status`=%d'] = $status;
		}

		$where['AND']['`user_id`=%d'] = $user_id;

		return $this->find( $where, $columns, $attrs );
	}
	
	public function remove_by_user_id( $user_id, array $where = [] ) {
		$user_id = Utils::get_user_id( $user_id );
		if( empty( $user_id ) ) return false;
		
		$where['AND']['`user_id`=%d'] = $user_id;
		$query = $this->query_creator( "DELETE FROM `{$this->table}`", $where );
		$this->query( $query );
	}
}
new Times;