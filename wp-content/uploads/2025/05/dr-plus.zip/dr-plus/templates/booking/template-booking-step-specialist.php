<?php

use DrPlus\Components\Button;
use DrPlus\Components\SectionTitle;
use DrPlus\Specialist;
use DrPlus\Utils;
use DrPlus\Utils\Elementor;
use DrPlus\Utils\Options;
use DrPlus\Utils\Search;
use DrPlus\Utils\User;
use DrPlus\Utils\UtilsSpecialists;

$options = Options::get_options( [
	'booking-search-city-field'				=> true,
	'booking-search-section-tag'			=> 'h1',
	'booking-search-head-text'				=> esc_html__( 'Please select the name of your desired specialist or specialty along with the city.', 'drplus' ),
	'booking-search-specialist-placeholder'	=> esc_html__( 'Search for specialist name', 'drplus' ),
	'booking-search-cities-placeholder'		=> esc_html__( 'All cities', 'drplus' ),
	'booking-search-no-result-text'			=> esc_html__( 'Unfortunately, no specialist was found with your specifications. Please check the information you entered and search again.', 'drplus' ),
	'booking-search-show-recent'			=> true,
	'booking-search-recent-title'			=> esc_html__( 'Recently visited', 'drplus' ),
] );
if( Utils::to_bool( $options['booking-search-city-field'] ) ) {
	$cities = Utils::get_cities();
}

// Search in specialist
$search_results = [];
$search_name = Utils::convert_chars( $_GET['stext'] ?? "" );
$city_name = Utils::convert_chars( $_GET['city'] ?? "" );
$searched = false;
global $wpdb;
if( !empty( $search_name ) ) {
	$searched = true;
	$name_like = '%' . $wpdb->esc_like( $search_name ) . '%';
	// Search name_like in user display name, specialist subtitle and speciality post title with OR operator
	// if city_name is not empty. search in city with AND operator
	$sql =
	"
    SELECT DISTINCT s.id
    FROM {$wpdb->prefix}drplus_specialists s
    JOIN {$wpdb->users} u ON u.ID = s.user_id
    LEFT JOIN {$wpdb->prefix}drplus_specialist_city_rel c ON c.user_id = s.user_id
    LEFT JOIN {$wpdb->prefix}drplus_specialist_speciality_rel ssr ON ssr.user_id = s.user_id
    LEFT JOIN {$wpdb->posts} sp ON sp.ID = ssr.speciality_id 
        AND sp.post_type = 'speciality' 
        AND sp.post_status = 'publish'
    WHERE s.status = 'active'
      AND (
        u.display_name LIKE %s
        OR s.subtitle LIKE %s
        OR sp.post_title LIKE %s
      )
	";

	$params = [$name_like, $name_like, $name_like];
	if ( !empty( $city_name ) ) {
		$sql .= " AND c.city = %s";
		$params[] = $city_name;
	}
	
	$query = $wpdb->prepare( $sql, ...$params );
	$result_specialists_ids = $wpdb->get_col( $query );

	$result_specialists_ids = array_slice( $result_specialists_ids, 0, 10 );
	if( !empty( $result_specialists_ids ) ) {
		foreach( $result_specialists_ids as $specialist_id ) {
			$search_results[] = new Specialist( $specialist_id );
		}
	}
}

$display_settings = [
	'desktop_slider'	=> false,
	'desktop_cols'		=> 5,
	'desktop_gap'		=> 16,

	'tablet_slider'		=> false,
	'tablet_cols'		=> 3,
	'tablet_gap'		=> 16,

	'mobile_slider'		=> false,
	'mobile_cols'		=> 2,
	'mobile_gap'		=> 16,
];
$display_args = Elementor::get_display_attributes( $display_settings );
$div_attrs = [
	'class'			=> $display_args['wrap_classes'],
	'data-settings'	=> $display_args['args'],
	'style'			=> $display_args['style'],
];

// Get recent specialists
if( $options['booking-search-show-recent'] ) {
	$recent_specialists = User::get_user_recently_visited_specialists_ids();
	if( !empty( $recent_specialists ) ) {
		foreach( $recent_specialists as $key => $specialist_id ) {
			$recent_specialists[$key] = new Specialist( $specialist_id );
		}
	}
}
?>
<div class="booking-search-head">
	<<?php echo tag_escape( $options['booking-search-section-tag'] ) ?> class="booking-search-text">
		<?php echo $options['booking-search-head-text']; ?>
	</<?php echo tag_escape( $options['booking-search-section-tag'] ) ?>>
	<div class="booking-search-form-wrap">
		<form method="get" action="" class="drplus-search-form booking-search-form">
			<?php
			$input_args = [
				'classes'		=> ['drplus-search-text'],
				'data-nonce'	=> wp_create_nonce( 'booking_search_nonce' ),
				'name'			=> 'stext',
			];

			get_template_part( "templates/components/template-components-search-input", null, [
				'wrap'	=> [
					'classes'	=> ['drplus-search-field-group', 'drplus-search-text-field-group'],
				],
				'input'			=> $input_args,
				'value'			=> $search_name,
				'change_bg_when_filled'	=> false,
				'placeholder'	=> $options['booking-search-specialist-placeholder'],
			] );

			if( Utils::to_bool( $options['booking-search-city-field'] ) ) {
				get_template_part( "templates/components/template-components-custom-select", null, [
					'wrap'			=> [
						'classes'	=> ['drplus-search-field-group', 'drplus-search-city-field-group'],
					],
					'select'		=> [
						'classes'	=> ['drplus-search-city'],
						'name'		=> 'city',
					],
					'value'			=> $city_name,
					'placeholder'	=> $options['booking-search-cities-placeholder'],
					'options'		=> $cities,
				] );
			}
			Button::view( [
				'icon'	=> 'drplus-icon-search'
			] );
			?>
		</form>
	</div>
</div>
<?php if( !empty( $searched ) ) { ?>
	<div id="booking-searched_specialists-wrap" <?php echo Utils::get_html_attributes( $div_attrs ) ?>>
		<?php
		SectionTitle::view( [
			'icon'	=> 'drplus-icon-search-2-fill',
			'title'	=> esc_html__( 'Search result', 'drplus' ),
			'tag'	=> 'h3',
		] );
		if( !empty( $search_results ) ) {
			UtilsSpecialists::list_html( [
				'specialists'	=> $search_results,
				'settings'		=> $display_settings,
				'mode'			=> 'offline_visits',
			] );
		} else { ?>
			<p class="booking-search-no-result">
				<?php echo $options['booking-search-no-result-text'] ?>
			</p>
		<?php } ?>
	</div>
<?php } ?>
<?php if( $options['booking-search-show-recent'] && !empty( $recent_specialists ) ) { ?>
	<div id="booking-recent_specialists-wrap" <?php echo Utils::get_html_attributes( $div_attrs ) ?>>
		<?php
		SectionTitle::view( [
			'icon'	=> 'drplus-icon-clock-fill',
			'title'	=> $options['booking-search-recent-title'],
			'tag'	=> 'h3'
		] );
		UtilsSpecialists::list_html( [
			'specialists'	=> $recent_specialists,
			'settings'		=> $display_settings,
			'mode'			=> 'offline_visits',
		] ); ?>
	</div>
<?php } ?>