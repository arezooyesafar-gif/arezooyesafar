<?php
namespace DrPlus;

use DrPlus\Utils\SpecialistInsurancesRel;
use DrPlus\Utils\SpecialistSpecialitiesRel;
use DrPlus\Utils\User;
use DrPlus\Utils\UtilsSpecialists;

class Specialist {
	public $ID = 0;
	public $user_id = 0;
	public $post_id = 0;
	public $slug = '';
	public $subtitle = '';
	public $about = '';
	public $offline_visit = false;
	public $online_visit = false;
	public $is_verified = false;
	public $offices = [];
	public $documents = [];
	public $insurances = [];
	public $articles = [];
	public $services = [];
	public $faqs = [];
	public $certificates = [];
	public $card_number = '';
	public $shaba_number = '';
	public $specialities = '';
	public $display_name = '';
	public $first_name = '';
	public $last_name = '';
	public $birthday = '';
	public $specialist_code = '';
	public $nid = '';
	public $mobile = '';
	public $gender = '';
	public $avatar = '';
	public $email = '';
	public $status = '';
	public $reject = '';

	public function __construct( $specialist = null, $user = null, array $excludes = [] ) {
		if( empty( $specialist ) && empty( $user ) ) return $this;

		$excludes = Utils::unset( $excludes, ['ID', 'id', 'user_id', 'post_id'] );

		if( !empty( $specialist ) ) {
			$specialist = Utils::array_to_obj( $specialist );
			if( is_object( $specialist ) ) {
				if( is_a( $specialist, 'WP_User' ) ) {
					$user = $specialist;
					$specialist = UtilsSpecialists::get_by_user_id( $user->ID );
				} else if( is_a( $specialist, 'WP_Post' ) ) {
					$sid = absint( get_post_meta( $specialist->ID, '_drplus_specialist_id', true ) );
					$specialist = new self( $sid );
				} else if( is_a( $specialist, 'DrPlus\Specialist' ) ) {
					if( !empty( $specialist->user_id ) ) {
						if( empty( $user ) ) {
							$user = get_user_by( 'id', $specialist->user_id );
						}
					} else if( !empty( $specialist->ID ) ) {
						$specialist = UtilsSpecialists::get( $specialist->ID );
						if( empty( $user ) ) {
							$user = get_user_by( 'id', $specialist['user_id'] );
						}
					}
				}
			} else if( is_numeric( $specialist ) ) {
				$specialist = UtilsSpecialists::get( $specialist );
				if( empty( $user ) ) {
					$user = get_user_by( 'id', $specialist['user_id'] );
				}
			}
		} else {
			if( is_numeric( $user ) ) {
				$user = get_user_by( 'id', $user );
			}
			$specialist = UtilsSpecialists::get_by_user_id( $user->ID );
		}
		if( !empty( $specialist ) ) {
			$specialist = Utils::array_to_obj( $specialist );
		}
		if( empty( $user ) && !empty( $specialist ) ) {
			$user = get_user_by( 'id', $specialist->user_id );
		}

		if( !empty( $specialist ) && !empty( $user ) ) {
			if( isset( $specialist->ID ) ) {
				$this->ID = $specialist->ID;
			} else if( $specialist->id ) {
				$this->ID = $specialist->id;
			}
			$this->ID = absint( $this->ID );

			$this->user_id = absint( $user->ID );
			$this->post_id = absint( $specialist->post_id );
			$this->slug = $specialist->slug;
			$this->subtitle = $specialist->subtitle;
			$this->about = $specialist->about;
			$this->offline_visit = !empty( $specialist->offline_visit );
			$this->online_visit = !empty( $specialist->online_visit );
			$this->is_verified = !empty( $specialist->is_verified );
			$this->avatar = User::get_avatar_id( $user->ID );

			$this->offices = $specialist->offices;
			if( Utils::is_json( $this->offices ) ) {
				$this->offices = json_decode( $this->offices, true );
			}
			$this->offices = Utils::obj_to_array( $this->offices );

			$this->documents = $specialist->documents;
			if( Utils::is_json( $this->documents ) ) {
				$this->documents = json_decode( $this->documents, true );
			}
			$this->documents = Utils::obj_to_array( $this->documents );

			$meta = [];
			if( isset( $specialist->meta ) ) {
				$meta = $specialist->meta;
				if( Utils::is_json( $meta ) ) {
					$meta = json_decode( $meta, true );
				}
				$meta = Utils::obj_to_array( $meta );
			}

			$this->articles = !empty( $meta['articles'] ) ? absint( $meta['articles'] ) : 0;
			$this->services = !empty( $meta['services'] ) ? $meta['services'] : [];
			$this->faqs = !empty( $meta['faqs'] ) ? $meta['faqs'] : [];
			$this->certificates = !empty( $meta['certificates'] ) ? $meta['certificates'] : [];
			$this->card_number = !empty( $meta['card_number'] ) ? $meta['card_number'] : '';
			$this->shaba_number = !empty( $meta['shaba_number'] ) ? $meta['shaba_number'] : '';

			$this->status = $specialist->status;
			$this->reject = $specialist->reject;

			// Get specialities
			if( !in_array( 'specialities', $excludes ) ) {
				if( empty( $this->specialities ) ) {
					$this->specialities = SpecialistSpecialitiesRel::get_user_specialities( $this->user_id );
					if( !empty( $this->specialities ) ) {
						$this->specialities = wp_list_pluck( $this->specialities, 'speciality_id' );
					}
				}
			}

			// Get insurances
			if( !in_array( 'insurances', $excludes ) ) {
				if( empty( $this->insurances ) ) {
					$this->insurances = SpecialistInsurancesRel::get_user_insurances( $this->user_id );
					if( !empty( $this->insurances ) ) {
						$this->insurances = wp_list_pluck( $this->insurances, 'insurance_id' );
					}
				}
			}
			
			$this->display_name = $user->display_name;
			$this->first_name = $user->first_name;
			$this->last_name = $user->last_name;
			$this->birthday = $user->birthday;
			$this->specialist_code = $user->specialist_code;
			$this->nid = $user->nid;
			$this->mobile = $user->mobile;
			$this->gender = $user->gender;
			$this->email = $user->user_email;

			if( !in_array( 'mobile', $excludes ) && !$this->mobile ) {
				$this->mobile = User::get_phone( $this->user_id );
			}

			foreach( $excludes as $exclude ) {
				if( isset( $this->{$exclude} ) ) {
					unset( $this->{$exclude} );
				}
			}
		}

		return $this;
	}

	public function get_page_link() {
		return UtilsSpecialists::get_page_link( $this );
	}
}