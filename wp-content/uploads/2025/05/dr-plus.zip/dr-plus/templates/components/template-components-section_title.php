<?php

use DrPlus\Utils;
use DrPlus\Utils\Elementor;
use DrPlus\Utils\Sanitizers;

if( !defined( 'ABSPATH' ) ) exit;

$args = Utils::check_default( $args, [
	'icon'			=> '',
	'icon_has_bg'	=> true,
	'tag'			=> 'h2',
	'title'			=> '',
	'link'			=> [],
	'nav_btns'		=> false,
	'classes'		=> [],
	'aria-label'	=> '',
], ['icon', 'link'] );

// Sanitize
$custom_tag = Sanitizers::tag( $args['tag'] );
$icon = Sanitizers::icon( $args['icon'], 'section-title-icon' );
$icon_has_bg = Utils::to_bool( $args['icon_has_bg'] );
$title = wp_kses_post( $args['title'] );

if( !empty( $args['link'] ) && is_string( $args['link'] ) ) {
	$args['link'] = ['url' => $args['link']];
}

$classes = ['section-title-wrap'];
if( !empty( $args['classes'] ) ) {
	$classes = array_merge( $classes, $args['classes'] );
}
if( $args['nav_btns'] ) {
	$classes[] = 'section-title-with-arrows';
}
?>
<div class="<?php echo Utils::prepare_html_classes( $classes ) ?>">
	<<?php echo tag_escape( $custom_tag ) ?> class="section-title"<?php echo $args['aria-label'] ? ' aria-label="' . $args['aria-label'] . '"' : '' ?>>
		<?php
		$icon_args = [
			'icon'			=> $args['icon'],
			'has_bg'		=> $icon_has_bg,
			'classes'		=> ['section-title-icon-wrap'],
			'icon_classes'	=> ['section-title-icon'],
		];
		get_template_part( "templates/components/template-components-simple_icon", null, $icon_args );
		?>
		<?php if( !empty( $args['link'] ) && !empty( !empty( $args['link']['url'] ) ) ) { ?>
			<a <?php echo Utils::get_html_attributes( Elementor::get_link_attributes( $args['link'] ) ) ?> class="section-title-title"><?php echo $title ?></a>
		<?php } else { ?>
			<span class="section-title-title"><?php echo $title ?></span>
		<?php } ?>
	</<?php echo tag_escape( $custom_tag ) ?>>
	<?php
	if( $args['nav_btns'] ) {
		get_template_part( 'templates/components/template-components-slider_arrows', null, [
			'inline'	=> true,
		] );
	}
	?>
</div>