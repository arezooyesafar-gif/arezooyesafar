<?php
namespace DrPlus\Elementor;

use DrPlus\ElementorControls;
use DrPlus\Utils;

class Menu extends \Elementor\Widget_Base {
	public function get_name() {
		return 'drplus_menu';
	}

	public function get_title() {
		return esc_html__( 'Menu (Doctor Plus)', 'drplus' );
	}

	public function get_icon() {
		return 'eicon-menu-bar';
	}

	public function get_categories() {
		return ['drplus', 'basic'];
	}

	public function get_keywords() {
		return ['text', 'menu', 'منو'];
	}

	private function settings_controls() {
		$this->start_controls_section( // content_section
			'settings_section',
			[
				'label'	=> esc_html__( 'Settings', 'drplus' ),
				'tab'	=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$menus = wp_get_nav_menus();

		$options = [];

		foreach( $menus as $menu ) {
			$options[$menu->slug] = $menu->name;
		}

		$this->add_control( // menu
			"menu",
			[
				'type'			=> \Elementor\Controls_Manager::SELECT,
				'label'			=> esc_html__( 'Menu', 'drplus' ),
				'options'		=> $options,
				'default'		=> array_keys( $options )[0],
				'description' => sprintf(
					/* translators: 1: Link opening tag, 2: Link closing tag. */
					esc_html__( 'Go to the %1$sMenus screen%2$s to manage your menus.', 'elementor-pro' ),
					sprintf( '<a href="%s" target="_blank">', admin_url( 'nav-menus.php' ) ),
					'</a>'
				),
			]
		);

		$this->add_control(
			'menu-align',
			[
				'label'		=> esc_html__( 'Menu Position', 'drplus' ),
				'type'		=> \Elementor\Controls_Manager::CHOOSE,
				'default'	=> is_rtl() ? 'right' : 'left',
				'options'	=> [
					'right'	=> [
						'title'	=> esc_html__( 'Right', 'drplus' ),
						'icon'	=> 'eicon-h-align-left',
					],
					'center'	=> [
						'title'	=> esc_html__( 'Center', 'drplus' ),
						'icon'	=> 'eicon-h-align-center',
					],
					'left'	=> [
						'title'	=> esc_html__( 'Left', 'drplus' ),
						'icon'	=> 'eicon-h-align-right',
					],
				],
			],
		);

		$this->add_control(
			'menu-direction',
			[
				'label'		=> esc_html__( 'Menu direction', 'drplus' ),
				'type'		=> \Elementor\Controls_Manager::CHOOSE,
				'default'	=> 'row-direction',
				'options'	=> [
					'col-direction'	=> [
						'title'	=> esc_html__( 'Column', 'drplus' ),
						'icon'	=> 'eicon-arrow-down',
					],
					'col-reverse-direction'	=> [
						'title'	=> esc_html__( 'Column reverse', 'drplus' ),
						'icon'	=> 'eicon-arrow-up',
					],
					'row-direction'	=> [
						'title'	=> esc_html__( 'Row', 'drplus' ),
						'icon'	=> 'eicon-arrow-right',
					],
					'row-reverse-direction'	=> [
						'title'	=> esc_html__( 'Row reverse', 'drplus' ),
						'icon'	=> 'eicon-arrow-left',
					],
				],
			],
		);

		$this->add_control( // show_icons
			'show_icons',
			[
				'label'			=> esc_html__( 'Show icons', 'drplus' ),
				'type'			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on'		=> esc_html__( 'Show', 'drplus' ),
				'label_off'		=> esc_html__( 'Hide', 'drplus' ),
				'return_value'	=> 'yes',
				'default'		=> 'yes',
			]
		);

		$this->add_control( // show_subtitles
			'show_subtitles',
			[
				'label'			=> esc_html__( 'Show subtitles', 'drplus' ),
				'type'			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on'		=> esc_html__( 'Show', 'drplus' ),
				'label_off'		=> esc_html__( 'Hide', 'drplus' ),
				'return_value'	=> 'yes',
				'default'		=> 'yes',
			]
		);

		$this->end_controls_section();
	}

	protected function register_controls() {
		$this->settings_controls();

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'menu_item_',
			'selector'		=> '.drplus-menu-wrap .menu > .menu-item, .drplus-menu-wrap .menu>ul>li',
			'hover_selector' => '.drplus-menu-wrap .menu > .menu-item:hover, .drplus-menu-wrap .menu>ul>li:hover',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'menu_item',
				'label'	=> esc_html__( 'Menu item', 'drplus' ),
			],

			'mode'	=> 'wrap',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'menu_item_title_',
			'selector'		=> '.drplus-menu-wrap .menu > .menu-item > a .menu-item-title, .drplus-menu-wrap .menu > ul > li > a .menu-item-title',
			'hover_selector' => '.drplus-menu-wrap .menu > .menu-item:hover > a .menu-item-title, .drplus-menu-wrap .menu > ul > li:hover > a .menu-item-title',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'menu_item_title',
				'label'	=> esc_html__( 'Menu item title', 'drplus' ),
			],

			'mode'	=> 'text',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'menu_item_icon_',
			'selector'		=> '.drplus-menu-wrap .menu > .menu-item > a .drplus-simple-icon-wrap, .drplus-menu-wrap .menu > ul > li > a .drplus-simple-icon-wrap',
			'hover_selector' => '.drplus-menu-wrap .menu > .menu-item:hover > a .drplus-simple-icon-wrap, .drplus-menu-wrap .menu > ul > li:hover > a .drplus-simple-icon-wrap',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'menu_item_icon',
				'label'	=> esc_html__( 'Menu item icon', 'drplus' ),
			],

			'excludes'	=> [
				'background',
			],
			'hover_excludes'	=> [
				'background',
				'icon_background'
			],
			'controls'	=> [
				'icon_background'	=> [
					'label'	=> esc_html__( 'Background color', 'drplus' ),
					'type'	=> \Elementor\Controls_Manager::COLOR,
					'selectors'	=> [
						'{{WRAPPER}} .drplus-menu-wrap .menu > .menu-item > a .drplus-simple-icon-wrap::before, .drplus-menu-wrap .menu > ul > li > a .drplus-simple-icon-wrap::before' => 'background-color: {{VALUE}}',
					],
				],
			],

			'mode'	=> 'icon',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'submenu_wrap_',
			'selector'		=> '.drplus-menu-wrap ul.sub-menu, .drplus-menu-wrap ul.children',
			'hover_selector' => false,
			
			'section'	=> [
				'name'	=> 'submenu_wrap',
				'label'	=> esc_html__( 'Sub menu container', 'drplus' ),
			],

			'mode'	=> 'wrapper',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'submenu_item_',
			'selector'		=> '.drplus-menu-wrap ul.sub-menu .menu-item, .drplus-menu-wrap ul.children > li',
			'hover_selector' => '.drplus-menu-wrap ul.sub-menu .menu-item:hover, .drplus-menu-wrap ul.children li:hover',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'submenu_item',
				'label'	=> esc_html__( 'Sub Menu item', 'drplus' ),
			],

			'hover_excludes'	=> [
				'submenu_item_hover_bar'
			],

			'controls'	=> [
				'submenu_item_hover_bar'	=> [
					'_position'	=> 5,
					'label'	=> esc_html__( 'Hover bar color', 'drplus' ),
					'type'	=> \Elementor\Controls_Manager::COLOR,
					'selectors'	=> [
						'{{WRAPPER}} .drplus-menu-wrap ul.sub-menu .menu-item a::after, .drplus-menu-wrap ul.sub-menu:is(.children) li a::after, .drplus-menu-wrap ul.children .menu-item a::after, .drplus-menu-wrap ul.children:is(.children) li a::after' => 'background: {{VALUE}}',
					],
				],
			],

			'mode'	=> 'wrap',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'submenu_item_title_',
			'selector'		=> '.drplus-menu-wrap ul.sub-menu .menu-item-title, .drplus-menu-wrap ul.children .menu-item-title',
			'hover_selector' => '.drplus-menu-wrap ul.sub-menu .menu-item:hover .menu-item-title, .drplus-menu-wrap ul.children li:hover .menu-item-title',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'submenu_item_title',
				'label'	=> esc_html__( 'Sub Menu item title', 'drplus' ),
			],

			'mode'	=> 'text',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'submenu_item_subtitle_',
			'selector'		=> '.drplus-menu-wrap ul.sub-menu .menu-item-subtitle, .drplus-menu-wrap ul.children .menu-item-subtitle',
			'hover_selector' => '.drplus-menu-wrap ul.sub-menu .menu-item:hover .menu-item-subtitle, .drplus-menu-wrap ul.children li:hover .menu-item-subtitle',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'submenu_item_subtitle',
				'label'	=> esc_html__( 'Sub Menu item subtitle', 'drplus' ),
			],

			'mode'	=> 'text',
		] );

		ElementorControls::general_style_controls( $this, [
			'prefix'		=> 'submenu_item_icon_',
			'selector'		=> '.drplus-menu-wrap ul.sub-menu .menu-item .drplus-simple-icon-wrap, .drplus-menu-wrap ul.children .drplus-simple-icon-wrap',
			'hover_selector' => '.drplus-menu-wrap ul.sub-menu .menu-item .menu-item:hover .drplus-simple-icon-wrap, .drplus-menu-wrap ul.children li:hover .drplus-simple-icon-wrap',
			'hover_type'	=> 'normal',
			
			'section'	=> [
				'name'	=> 'submenu_item_icon',
				'label'	=> esc_html__( 'Sub Menu item icon', 'drplus' ),
			],

			'excludes'	=> [
				'background',
			],
			'hover_excludes'	=> [
				'background',
				'icon_background'
			],
			'controls'	=> [
				'icon_background'	=> [
					'label'	=> esc_html__( 'Background color', 'drplus' ),
					'type'	=> \Elementor\Controls_Manager::COLOR,
					'selectors'	=> [
						'{{WRAPPER}} .drplus-menu-wrap ul.sub-menu .drplus-simple-icon-wrap::before, .drplus-menu-wrap ul.children .drplus-simple-icon-wrap::before' => 'background-color: {{VALUE}}',
					],
				],
			],

			'mode'	=> 'icon',
		] );
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$wrap_classes = ['drplus-menu-wrap', $settings['menu-align'], $settings['menu-direction']];
		?>
		<nav class="<?php echo Utils::prepare_html_classes( $wrap_classes ) ?>">
			<?php
			wp_nav_menu( [
				'menu'				=> $settings['menu'],
				'container_class'	=> $settings['menu'],
				'show_icons'		=> Utils::to_bool( $settings['show_icons'] ),
				'show_subtitles'	=> Utils::to_bool( $settings['show_subtitles'] ),
			] );
			?>
		</nav>
		<?php
	}
}