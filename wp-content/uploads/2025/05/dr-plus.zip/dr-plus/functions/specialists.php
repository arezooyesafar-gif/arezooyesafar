<?php

use DrPlus\DB;
use DrPlus\DB\SpecialistCitiesRel;
use DrPlus\DB\Specialists as DBSpecialists;
use DrPlus\DB\SpecialistSpecialitiesRel;
use DrPlus\Utils;
use DrPlus\Utils\Onboard;
use DrPlus\Utils\Search;
use DrPlus\Utils\Speciality;
use DrPlus\Utils\UtilsSpecialists;
use DrPlus\Utils\User;

if( !function_exists( "drplus_specialist_user_query" ) ) {
	function drplus_specialist_user_query( $query ) {
		if( isset( $query->query_vars['specialists'] ) || !empty( $query->query_vars['only_offline_visits'] ) || !empty( $query->query_vars['only_online_visits'] ) || !empty( $query->query_vars['only_verified'] ) ) {
			global $wpdb;
			
			$join_type = 'INNER';
			if( isset( $query->query_vars['specialists'] ) && Utils::to_bool( $query->query_vars['specialists'] ) === false ) {
				$join_type = 'LEFT';
				$query->query_where .= " AND dr_sp.`user_id` IS NULL ";
			}
			$specialists_db = new DBSpecialists;
			$query->query_from .= " {$join_type} JOIN `{$specialists_db->table}` AS dr_sp ON `{$wpdb->users}`.`ID`=dr_sp.`user_id`";

			if( !empty( $query->query_vars['only_offline_visits'] ) ) {
				$query->query_where .= " AND dr_sp.`offline_visit`=1";
			} else if( !empty( $query->query_vars['only_online_visits'] ) ) {
				$query->query_where .= " AND dr_sp.`online_visit`=1";
			}

			if( !empty( $query->query_vars['only_verified'] ) ) {
				$query->query_where .= " AND dr_sp.`is_verified`=1";
			}
		}
	}
}
add_action( 'pre_user_query', 'drplus_specialist_user_query' );

if( !function_exists( "drplus_specialist_city_filter" ) ) {
	function drplus_specialist_city_filter( $query ) {
		if( isset( $query->query_vars['specialists'] ) ) {
			$city = Search::get_city_from_GET();
			if( $city ) {
				global $wpdb;
				$city_rel_db = new SpecialistCitiesRel;
				$query->query_from .= " LEFT JOIN `{$city_rel_db->table}` AS dr_scity ON `{$wpdb->users}`.`ID`=dr_scity.`user_id`";
				$query->query_where .= " AND dr_scity.`city`='" . esc_sql( $city ) . "'";
			}
		}
	}
}
add_action( 'pre_user_query', 'drplus_specialist_city_filter' );

if( !function_exists( "drplus_onboard_create_post" ) ) {
	function drplus_onboard_create_post( $specialist ) {
		// check if exist
		$post_id = UtilsSpecialists::get_specialist_post_id( $specialist );
		if( !empty( $post_id ) ) return;

		// Insert post
		$post_status = 'draft';
		if( !empty( $post_status ) ) {
			$post_status = $specialist->status == 'active' ? "publish" : "draft";	
		}

		$args = [
			'post_title'		=> sprintf( '%s (%s)', $specialist->display_name, $specialist->subtitle ),
			'post_status'		=> $post_status,
			'post_type'			=> 'specialist',
			'post_name'			=> $specialist->slug,
			'comment_status'	=> 'open',
			'ping_status'		=> 'closed',
			'meta_input'		=> [
				'_drplus_user_id'		=> $specialist->user_id,
				'_drplus_specialist_id'	=> $specialist->ID,
			],
		];
		$post_id = wp_insert_post( $args, true );
		if( !is_wp_error( $post_id ) ) {
			do_action( 'drplus/specialist/post_updated', $post_id, $specialist );
		}
		return $post_id;
	}
}
add_action( 'drplus/specialist/created', 'drplus_onboard_create_post' );

if( !function_exists( "drplus_onboard_update_post" ) ) {
	function drplus_onboard_update_post(  $specialist ) {
		$post_id = UtilsSpecialists::get_specialist_post_id( $specialist );
		if( empty( $post_id ) ) {
			return drplus_onboard_create_post( $specialist );
		}

		$args = [
			'ID'			=> $post_id,
			'post_status'	=> $specialist->status == 'active' ? "publish" : "draft",
			'post_name'		=> $specialist->slug,
			'post_title'	=> sprintf( '%s (%s)', $specialist->display_name, $specialist->subtitle ),
		];
		$post_id = wp_update_post( $args, true );
		if( !is_wp_error( $post_id ) ) {
			do_action( 'drplus/specialist/post_updated', $post_id, $specialist );
		}
		return $post_id;
	}
}
add_action( 'drplus/specialist/updated', 'drplus_onboard_update_post');

if( !function_exists( "drplus_specialist_saved" ) ) {
	function drplus_specialist_saved( $specialist, $original_data, $data ) {
		if( is_admin() ) return;
		// Save next step for onboard
		$step = '';
		if( empty( $data['status'] ) ) return;
		if( $data['status'] != 'rejected' && !empty( $data['step'] ) ) {
			$step = Utils::convert_chars( $data['step'] );
		} else if( $data['status'] == 'rejected' ) {
			$step = 'rejected';
		}
		Onboard::update_user_step( $step );
	}
}
add_action( 'drplus/specialist/saved', 'drplus_specialist_saved', 10, 3 );

if( !function_exists( "drplus_specialist_after_post_updated" ) ) {
	function drplus_specialist_after_post_updated( $post_id, $specialist ) {
		UtilsSpecialists::update( $specialist->ID, [
			'post_id'	=> $post_id,
		] );
	}
}
add_action( 'drplus/specialist/post_updated', 'drplus_specialist_after_post_updated', 10, 2 );

if( !function_exists( "drplus_change_specialist_page_comments_title" ) ) {
	function drplus_change_specialist_page_comments_title( $title ) {
		if( !is_singular( 'specialist' ) ) return $title;

		return esc_html__( 'User Reviews', 'drplus' );
	}
}
add_filter( 'drplus/comments/title', 'drplus_change_specialist_page_comments_title' );

if( !function_exists( "drplus_save_specialist_as_recently_visited" ) ) {
	function drplus_save_specialist_as_recently_visited() {
		if( wp_doing_ajax() ) return;

		// only work in specialist page or any page with 'drplus_save_recent' query string
		if( !empty( $_GET['drplus_save_recent'] ) ) {
			$specialist_id = Utils::convert_chars( $_GET['drplus_save_recent'], true, 'absint' );
		} else if( is_singular( 'specialist' ) ) {
			$specialist_post_id = get_the_ID();
			$specialist_id = get_post_meta( $specialist_post_id, '_drplus_specialist_id', true );
		} else {
			return;
		}
 		if( empty( $specialist_id ) ) return;
		User::add_recently_visited_specialist( 0, $specialist_id );

		if( !empty( !empty( $_GET['drplus_save_recent'] ) ) ) {
			// Redirect to remove query string
			$redirect_url = remove_query_arg( 'drplus_save_recent' );
			if( !empty( $redirect_url ) ) {
				wp_safe_redirect( $redirect_url );
				exit;
			}
		}
	}
}
add_action( 'wp_head', 'drplus_save_specialist_as_recently_visited' );

if( !function_exists( "drplus_specialist_speciality_filter" ) ) {
	function drplus_specialist_speciality_filter( $clauses, $query ) {
		if( is_admin() || !$query->is_main_query() || $query->get( 'post_type' ) != 'specialist' ) return $clauses;

		$specialities = Speciality::get_specialities_from_GET();
		if( empty( $specialities ) ) return $clauses;

		$specialities_sql_placeholder = DB::placeholder( $specialities, '%d' );

		global $wpdb;
		$specialists_db = new DBSpecialists;
		$specialist_speciality_rel_db = new SpecialistSpecialitiesRel;
		$where = "AND `{$wpdb->posts}`.`ID` IN (SELECT DISTINCT `{$specialists_db->table}`.`post_id` FROM `{$specialists_db->table}` LEFT JOIN `{$specialist_speciality_rel_db->table}` ON `{$specialists_db->table}`.`user_id`=`{$specialist_speciality_rel_db->table}`.`user_id` WHERE `{$specialist_speciality_rel_db->table}`.`speciality_id` IN ({$specialities_sql_placeholder}))";
		$where = $wpdb->prepare( $where, $specialities );

		$clauses['where'] .= " {$where}";
		
		return $clauses;
	}
}
add_filter( 'posts_clauses', 'drplus_specialist_speciality_filter', 10, 2 );

if( !function_exists( "drplus_specialist_type_filter" ) ) {
	function drplus_specialist_type_filter( $clauses, $query ) {
		if( is_admin() || !$query->is_main_query() || $query->get( 'post_type' ) != 'specialist' ) return $clauses;

		if( empty( $_GET['specialist-type'] ) ) return $clauses;
		$type = Utils::ensure_values_in_array( Utils::convert_chars( $_GET['specialist-type'] ), ['all', 'online', 'consult'], 'all' );
		if( $type === 'all' ) return $clauses;

		$specialists_db = new DBSpecialists;
		global $wpdb;
		if( strpos( $clauses['join'], "JOIN `{$specialists_db->table}`" ) === false ) {
			$clauses['join'] .= " LEFT JOIN `{$specialists_db->table}` as dr_sp ON dr_sp.`post_id`=`{$wpdb->posts}`.`ID`";
		}
		if( $type == 'online' ) {
			$clauses['where'] .= " AND dr_sp.`offline_visit`=1";
		}
		if( $type == 'consult' ) {
			$clauses['where'] .= " AND dr_sp.`online_visit`=1";
		}

		return $clauses;
	}
}
add_filter( 'posts_clauses', 'drplus_specialist_type_filter', 10, 2 );