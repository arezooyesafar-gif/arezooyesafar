<?php

use DrPlus\Utils;
use DrPlus\Utils\Options;

add_filter( 'woocommerce_enqueue_styles', '__return_false' ); // Disable all wc styles

if( !function_exists( "drplus_wc_product_classes" ) ) {
	function drplus_wc_product_classes( $classes ) {
		$classes[] = 'slider-slide';
		return $classes;
	}
}
add_filter( 'woocommerce_post_class', 'drplus_wc_product_classes', 99 );

if( !function_exists( "drplus_wc_return_to_shop_text" ) ) {
	function drplus_wc_return_to_shop_text( $text ) {
		return Options::get_options( [
			'wc_return_to_shop_text'	=> __( 'Return to shop', 'drplus' )
		] )['wc_return_to_shop_text'];
	}
}
add_filter( 'woocommerce_return_to_shop_text', 'drplus_wc_return_to_shop_text' );

if( !function_exists( "drplus_wc_sku_status" ) ) {
	function drplus_wc_sku_status( $status ) {
		return Utils::to_bool( Options::get_options( ['sku_status' => true] )['sku_status'] );
	}
}
add_filter( 'wc_product_sku_enabled', 'drplus_wc_sku_status' );

include( DRPLUS_DIR . "woocommerce/functions/single.php" );
include( DRPLUS_DIR . "woocommerce/functions/loop.php" );
include( DRPLUS_DIR . "woocommerce/functions/myaccount.php" );
include( DRPLUS_DIR . "woocommerce/functions/checkout.php" );
include( DRPLUS_DIR . "woocommerce/functions/cart.php" );
include( DRPLUS_DIR . "woocommerce/functions/mini-cart.php" );
include( DRPLUS_DIR . "woocommerce/functions/filters.php" );