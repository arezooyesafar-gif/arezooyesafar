<?php

use DrPlus\Components\Button;
use DrPlus\Utils;
use DrPlus\Utils\Booking;
use DrPlus\Utils\Date;

$show_save_button = false;

if( !empty( $_GET['order_id'] ) ) {
	$back_link = remove_query_arg( 'order_id' );
	get_template_part( 'templates/specialists/template-specialists-appointment', null, [
		'specialist_id'	=> $specialist->ID,
	] );
	return;
}

// Get day from filter
$app_date = Utils::convert_chars( $_GET['app_date'] ?? '' );
if( !empty( $app_date ) ) {
	$app_date_georgian = implode( '-', Date::jalali_to_gregorian(...explode( '-', $app_date ) ) );
	$app_date_timestamp = date( 'U', strtotime( $app_date_georgian ) );
}

// If empty. get today apps
if( empty( $app_date ) ) {
	$app_date_georgian = date( 'Y-m-d' );
}

// Get specialist apps of only one day
$where['AND'] = [
	'date=%s' => $app_date_georgian
];
$apps = Booking::get_specialist_appointments( $specialist->ID, Booking::get_status_filters( 'ongoing' )['statuses'], $where, ['start_time', 'customer_id', 'order_id', 'office_id'] );
?>

<h2 class="drplus-myaccount-page-title"><?php echo esc_html( $sections['specialist-appointments']['label'] ) ?></h2>
<form action="" method="get" class="drplus-specialist-form">
	<div class="drplus-specialist-apps-filters-wrap">
		<h3 class="drplus-specialist-apps-title"><?php echo esc_html__( 'Filter appointments', 'drplus' ) ?></h3>
		<input
			type="text"
			class="drplus-datepicker-input"
			id="drplus_app_date_input"
			data-time="<?php echo esc_attr( $app_date_timestamp ?? "" ) ?>",
			data-options='<?php echo wp_json_encode( ['altFormat' => 'YYYY-MM-DD'] ) ?>'
			placeholder="<?php echo esc_html__( 'Select date', 'drplus' ) ?>"
			readonly
		>
		<input type="hidden" name="app_date" id="drplus_app_date_alt">
		<?php
		Button::view( [
			'text'	=> esc_html__( 'Filter', 'drplus' ),
			'small'	=> true,
			'type'	=> 'bordered',
			'align'	=> 'end',
			'atts'	=> [
				'type'	=> 'submit'
			]
		] )
		?>
	</div>


	<div class="drplus-specialist-apps-container">
		<h3 class="drplus-specialist-apps-title">
			<?php if( empty( $app_date_timestamp ) ) {
				$date_title = esc_html__( 'Today', 'drplus' );
			} else {
				$date_title = Date::jdate( 'd F Y', $app_date_timestamp );
			} ?>
			<?php printf( esc_html_x( 'Appointments of %s', 'date title', 'drplus' ), $date_title ) ?>
		</h3>

		<div class="drplus-specialist-apps-list">
			<?php if( empty( $apps ) ) { ?>
				<div class="empty-page">
					<i class="empty-page-icon empty-apps-icon drplus-icon-calendar-2"></i>
					<p class="empty-page-text empty-apps-text">
						<?php // translators: در تاریخ انتخاب‌شده، هیچ نوبتی برای شما ثبت نشده است. ?>
						<?php esc_html_e( 'No appointments have been scheduled for you on the selected date.', 'drplus' ) ?>
					</p>
				</div>
			<?php } else { ?>
				<?php foreach( $apps as $app ) { ?>
					<?php
					$order = wc_get_order( $app['order_id'] );
					$book_data = [];
					foreach( $order->get_meta_data() as $meta ) {
						if( $meta->key == '_booking_data' ) {
							$book_data = $meta->value;
							break;
						}
					}
					?>
					<a href="<?php echo add_query_arg( 'order_id', $app['order_id'], remove_query_arg( 'app_date' ) ) ?>" class="drplus-specialist-apps-item">
						<div class="drplus-specialist-apps-item-time-wrap">
							<span class="drplus-specialist-apps-item-time"><?php echo $book_data['start_time'] ?></span>
							<span class="drplus-specialist-apps-item-time-period"><?php echo Date::get_time_period( (int) explode( ':', $book_data['start_time'] )[0] ) ?></span>
						</div>
						<div class="drplus-specialist-apps-item-customer-wrap">
							<span class="drplus-specialist-apps-item-customer-title"><?php echo esc_html__( 'Patient name', 'drplus' ); ?>:</span>
							<span class="drplus-specialist-apps-item-customer-name"><?php printf( '%s %s', esc_html( $book_data['first_name'] ), esc_html( $book_data['last_name'] ) ) ?></span>
						</div>
						<div class="drplus-specialist-apps-item-type-wrap">
							(<?php echo $app['office_id'] == 'consultation' ? esc_html__( 'Online consultation', 'drplus' ) : esc_html__( 'in-person visit', 'drplus' ) ?>)
						</div>
					</a>
				<?php } ?>
			<?php } ?>
		</div>
	</div>
</form>