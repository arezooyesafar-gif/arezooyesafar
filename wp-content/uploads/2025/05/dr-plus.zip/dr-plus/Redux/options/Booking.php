<?php
defined( 'ABSPATH' ) || exit;

Redux::set_section( // General settings
	$opt_name,
	array(
		'title'			=> esc_html__( 'General settings', 'drplus' ),
		'id'			=> 'booking-general-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // enable-booking
				'id'		=> 'enable-booking',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Enable Booking', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Enable', 'drplus' ) ),
				'on'		=> esc_html__( 'Enable', 'drplus' ),
				'off'		=> esc_html__( 'Disable', 'drplus' ),
				'default'	=> true,
			],
			[ // booking-page-id
				'id'		=> 'booking-page-id',
				'type'		=> 'select',
				'title'		=> esc_html__( 'Select your booking page', 'drplus' ),
				'subtitle'	=> esc_html__( 'Choose a page from the list.', 'drplus' ),
				'desc'		=> sprintf( esc_html__( 'Use [drplus_booking] shortcode on this page', 'drplus' ) ),
				'data'		=> 'pages',
				'required'	=> [
					['enable-booking','=',true]
				]
			],
			[
				'id'	=> 'sms_info',
				'type'	=> 'info',
				'desc'	=> sprintf( __( "After changing the booking page please go to <a href='%s'>Permalink settings</a> and just save the settings again.", 'drplus' ), admin_url( "options-permalink.php" ) ),
				'style'	=> 'info',
				'icon'	=> 'el-icon-info-sign',
				'required'	=> [
					['enable-booking','=',true]
				],
			],
			[ // booking-specialist-not-found
				'id'			=> 'booking-specialist-not-found',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Message for when the selected specialist is not found', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Selected specialist not found', 'drplus' ) ),
				'default'		=> esc_html__( 'Selected specialist not found', 'drplus' ),
				'placeholder'	=> esc_html__( 'Selected specialist not found', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-commission-type (none, fixed, percentage)
				'id'			=> 'booking-commission-type',
				'type'			=> 'select',
				'title'			=> esc_html__( 'Booking commission type', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'None', 'drplus' ) ),
				'default'		=> 'none',
				'options'		=> array(
					'none'			=> esc_html__( 'None', 'drplus' ),
					'fixed'			=> esc_html__( 'Fixed', 'drplus' ),
					'percentage'	=> esc_html__( 'Percentage', 'drplus' ),
				),
				'desc'			=> esc_html__( 'Select the type of commission for booking.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-commission-calculate-type
				'id'			=> 'booking-commission-calculate-type',
				'type'			=> 'select',
				'title'			=> esc_html__( 'Booking commission calculate type', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Add to customer order', 'drplus' ) ),
				'default'		=> 'add_to_customer_order',
				'options'		=> array(
					'add_to_customer_order'				=> esc_html__( 'Add to customer order', 'drplus' ),
					'deduction_from_specialist_income'	=> esc_html__( 'Deduction from specialist income', 'drplus' ),
				),
				'desc'			=> esc_html__( 'Select the type of commission calculation for booking.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
					['booking-commission-type','!=','none'],
				],
			],
			[ // booking-commission-fixed-amount
				'id'			=> 'booking-commission-fixed-amount',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Booking commission amount (Toman)', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), 0 ),
				'default'		=> 0,
				'placeholder'	=> 0,
				'desc'			=> esc_html__( 'Enter the fixed amount (in Toman) of the commission for booking', 'drplus' ),
				'validate' 		=> 'numeric',
				'required'		=> [
					['enable-booking','=',true],
					['booking-commission-type','=','fixed'],
				],
			],
			[ // booking-commission-amount
				'id'			=> 'booking-commission-percentage-amount',
				'type'			=> 'slider',
				'title'			=> esc_html__( 'Booking commission percentage', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), '0' ),
				'default'		=> 0,
				"min"       	=> 0,
				"step"      	=> 1,
				"max"       	=> 100,
				'display_value'	=> 'text',
				'placeholder'	=> '0',
				'desc'			=> esc_html__( 'Enter the percentage of the commission for booking (percent of specialist visit price)', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
					['booking-commission-type','=','percentage'],
				],
			],
		),
	)
);

Redux::set_section( // Search specialist settings
	$opt_name,
	array(
		'title'			=> esc_html__( 'Search specialist settings', 'drplus' ),
		'id'			=> 'booking-specialist-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // booking-search-city-field
				'id'		=> 'booking-search-city-field',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show city field in search section', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Yes', 'drplus' ) ),
				'on'		=> esc_html__( 'Yes', 'drplus' ),
				'off'		=> esc_html__( 'No', 'drplus' ),
				'default'	=> true,
				'required'		=> [
					['enable-booking','=',true]
				]
			],
			[ // booking-search-section-tag
				'id'		=> 'booking-search-section-tag',
				'type'		=> 'select',
				'title'		=> __( 'Search section title tag', 'drplus' ),
				'default'	=> 'h1',
				'options'	=> $tags,
				'required'		=> [
					['enable-booking','=',true]
				]
			],
			[ // booking-search-head-text
				'id'			=> 'booking-search-head-text',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Search section title text', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Please select the name of your desired specialist or specialty along with the city.', 'drplus' ) ),
				'default'		=> esc_html__( 'Please select the name of your desired specialist or specialty along with the city.', 'drplus' ),
				'placeholder'	=> esc_html__( 'Please select the name of your desired specialist or specialty along with the city.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-search-specialist-placeholder
				'id'			=> 'booking-search-specialist-placeholder',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Search specialist field placeholder', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Search for specialist name', 'drplus' ) ),
				'default'		=> esc_html__( 'Search for specialist name', 'drplus' ),
				'placeholder'	=> esc_html__( 'Search for specialist name', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-search-cities-placeholder
				'id'			=> 'booking-search-cities-placeholder',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Search cities field placeholder', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'All cities', 'drplus' ) ),
				'default'		=> esc_html__( 'All cities', 'drplus' ),
				'placeholder'	=> esc_html__( 'All cities', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
					['booking-search-city-field','=',true],
				],
			],
			[ // booking-search-no-result-text
				'id'			=> 'booking-search-no-result-text',
				'type'			=> 'text',
				'title'			=> esc_html__( 'No result search text', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Unfortunately, no specialist was found with your specifications. Please check the information you entered and search again.', 'drplus' ) ),
				'default'		=> esc_html__( 'Unfortunately, no specialist was found with your specifications. Please check the information you entered and search again.', 'drplus' ),
				'placeholder'	=> esc_html__( 'Unfortunately, no specialist was found with your specifications. Please check the information you entered and search again.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-search-row-bg
				'id'			=> 'booking-search-row-bg',
				'type'			=> 'background',
				'title'			=> __( 'Search section background', 'drplus' ),
				'compiler'		=> true,
				'transparent'	=> true,
				'default'		=> [
					'background-image'	=> DRPLUS_URI . "assets/images/booking-search-head.svg",
					'background-color'	=> '#1dbab5',
					'background-repeat'	=> 'no-repeat',
					'background-size'	=> 'cover',
				],
				'required'		=> [
					['enable-booking','=',true]
				]
			],

			[ // divider
				'id'	=> 'booking-search-divider',
				'type'	=> 'divide',
			],

			[ // booking-search-show-recent
				'id'		=> 'booking-search-show-recent',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Show recently visited specialists', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'Yes', 'drplus' ) ),
				'on'		=> esc_html__( 'Yes', 'drplus' ),
				'off'		=> esc_html__( 'No', 'drplus' ),
				'default'	=> true,
				'required'		=> [
					['enable-booking','=',true]
				]
			],
			[ // booking-search-recent-title
				'id'			=> 'booking-search-recent-title',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Recently visited title', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Latest viewed specialists', 'drplus' ) ),
				'default'		=> esc_html__( 'Latest viewed specialists', 'drplus' ),
				'placeholder'	=> esc_html__( 'Latest viewed specialists', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
					['booking-search-show-recent','=',true],
				],
			],
		),
	)
);
Redux::set_section( // receipt page settings
	$opt_name,
	array(
		'title'			=> esc_html__( 'Appointment receipt page settings', 'drplus' ),
		'id'			=> 'booking-appointment-receipt-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // booking-receipt-section-title-success
				'id'			=> 'booking-receipt-section-title-success',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Receipt title for success booking', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Thank you. your requested appointment has been booked.', 'drplus' ) ),
				'default'		=> esc_html__( 'Thank you. your requested appointment has been booked.', 'drplus' ),
				'placeholder'	=> esc_html__( 'Thank you. your requested appointment has been booked.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-receipt-section-title-pending
				'id'			=> 'booking-receipt-section-title-pending',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Receipt title for pending booking', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Your appointment has been reserved, but payment is still pending.', 'drplus' ) ),
				'default'		=> esc_html__( 'Your appointment has been reserved, but payment is still pending.', 'drplus' ),
				'placeholder'	=> esc_html__( 'Your appointment has been reserved, but payment is still pending.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-receipt-section-title-failed
				'id'			=> 'booking-receipt-section-title-failed',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Receipt title for failed booking', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'We\'re sorry; your appointment booking was unsuccessful. Please attempt your book again.', 'drplus' ) ),
				'default'		=> esc_html__( 'We\'re sorry; your appointment booking was unsuccessful. Please attempt your book again.', 'drplus' ),
				'placeholder'	=> esc_html__( 'We\'re sorry; your appointment booking was unsuccessful. Please attempt your book again.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-receipt-section-title-cancelled
				'id'			=> 'booking-receipt-section-title-cancelled',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Receipt title for cancelled booking', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Your appointment has been cancelled as requested.', 'drplus' ) ),
				'default'		=> esc_html__( 'Your appointment has been cancelled as requested.', 'drplus' ),
				'placeholder'	=> esc_html__( 'Your appointment has been cancelled as requested.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-receipt-section-title-refunded
				'id'			=> 'booking-receipt-section-title-refunded',
				'type'			=> 'text',
				'title'			=> esc_html__( 'Receipt title for refunded booking', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Your payment has been refunded successfully.', 'drplus' ) ),
				'default'		=> esc_html__( 'Your payment has been refunded successfully.', 'drplus' ),
				'placeholder'	=> esc_html__( 'Your payment has been refunded successfully.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-receipt-section-offline-description
				'id'			=> 'booking-receipt-section-offline-description',
				'type'			=> 'textarea',
				'rows'			=> 5,
				'title'			=> esc_html__( 'Receipt note for visit at office customer', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Please arrive at the medical center 30 minutes before your scheduled appointment time.
In case of cancellation, half of the consultation fee will be deducted.', 'drplus' ) ),
				'default'		=> esc_html__( 'Please arrive at the medical center 30 minutes before your scheduled appointment time.
In case of cancellation, half of the consultation fee will be deducted.', 'drplus' ),
				'placeholder'	=> esc_html__( 'Please arrive at the medical center 30 minutes before your scheduled appointment time.
In case of cancellation, half of the consultation fee will be deducted.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
			[ // booking-receipt-section-online-description
				'id'			=> 'booking-receipt-section-online-description',
				'type'			=> 'textarea',
				'rows'			=> 5,
				'title'			=> esc_html__( 'Receipt note for online consultation customer', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'At the scheduled consultation time, the specialist will contact you using the phone number you provided during the booking.
Please make sure to be available at that time and ensure your phone is turned on and has proper signal coverage.', 'drplus' ) ),
				'default'		=> esc_html__( 'At the scheduled consultation time, the specialist will contact you using the phone number you provided during the booking.
Please make sure to be available at that time and ensure your phone is turned on and has proper signal coverage.', 'drplus' ),
				'placeholder'	=> esc_html__( 'At the scheduled consultation time, the specialist will contact you using the phone number you provided during the booking.
Please make sure to be available at that time and ensure your phone is turned on and has proper signal coverage.', 'drplus' ),
				'required'		=> [
					['enable-booking','=',true],
				],
			],
		),
	)
);