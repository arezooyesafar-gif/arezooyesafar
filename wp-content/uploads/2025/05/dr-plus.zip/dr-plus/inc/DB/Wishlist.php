<?php
namespace DrPlus\DB;

use DrPlus\Utils;
use DrPlus\DB as DB;

class Wishlist extends DB {
	public string $table = 'drplus_wishlist';
	public array $exclude_columns = ['created_at', 'updated_at', 'creator', 'deleted'];

	public array $columns = [
		'id'			=> 'INT NOT NULL AUTO_INCREMENT',
		'product_id'	=> 'INT NOT NULL',
		'user_id'		=> 'INT NOT NULL',
	];
	public array $defaults = [
		'product_id'	=> 0,
		'user_id'		=> 0,
	];

	public function sanitize( bool $update = false ) {
		$this->product_id	= Utils::convert_chars( $this->product_id, 'sanitize_text_field', 'absint' );
		$this->user_id		= Utils::convert_chars( $this->user_id, 'sanitize_text_field', 'absint' );
	}
}
new Wishlist;