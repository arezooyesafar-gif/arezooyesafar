<?php
namespace DrPlus\Utils;

use DrPlus\Components\Alert;
use DrPlus\Components\Button;
use DrPlus\DB;
use DrPlus\DB\Booking as DBBooking;
use DrPlus\DB\Specialists;
use DrPlus\DB\Times;
use DrPlus\Specialist;
use DrPlus\Utils;

class Booking extends Utils {
	public static function booking_steps() {
		return [
			'specialist'	=> esc_html__( 'Select specialist', 'drplus' ),
			'time'			=> esc_html__( 'Select time', 'drplus' ),
			'info'			=> esc_html__( 'Completing the information', 'drplus' ),
			'checkout'		=> esc_html__( 'Checkout', 'drplus' ),
			'receipt'		=> esc_html__( 'See receipt', 'drplus' )
		];
	}

	public static function get_order_statuses() {
		return [
			'completed'		=> esc_html_x( 'Completed', 'book status', 'drplus' ),
			'processing'	=> esc_html_x('Processing', 'book status', 'drplus' ),
			'on-hold'		=> esc_html_x('On Hold', 'book status', 'drplus' ),
			'pending'		=> esc_html_x('Pending', 'book status', 'drplus' ),
			'failed'		=> esc_html_x('Failed', 'book status', 'drplus' ),
			'cancelled'		=> esc_html_x('Cancelled', 'book status', 'drplus' ),
			'refunded'		=> esc_html_x('Refunded', 'book status', 'drplus' ),
		];
	}

	public static function get_status_filters( $status_key = "" ) {
		$statuses = [
			'all'	=> [
				'statuses'	=> array_keys( self::get_order_statuses() ),
				'text'		=> __( 'All', 'drplus' ),
				'value'		=> 0,
				'link'		=> remove_query_arg( 'filter' )
			],
			'ongoing'	=> [
				'statuses'	=> ['completed', 'processing'],
				'text'		=> __( 'Ongoing', 'drplus' ),
				'value'		=> 0,
				'link'		=> add_query_arg( ['filter' => 'ongoing'] )
			],
			'completed'	=> [
				'statuses'	=> ['completed', 'processing'],
				'text'		=> _x( 'Completed', 'book status', 'drplus' ),
				'value'		=> 0,
				'link'		=> add_query_arg( ['filter' => 'completed'] )
			],
			'cancelled'	=> [
				'statuses'	=> ['failed', 'cancelled', 'refunded'],
				'text'		=> __( 'Cancelled', 'drplus' ),
				'value'		=> 0,
				'link'		=> add_query_arg( ['filter' => 'cancelled'] )
			],
			'pending'	=> [
				'statuses'	=> ['pending'],
				'text'		=> _x( 'Pending', 'book status', 'drplus' ),
				'value'		=> 0,
				'link'		=> add_query_arg( ['filter' => 'pending'] )
			],
		];

		if( !empty( $status_key ) ) {
			if( array_key_exists( $status_key, $statuses ) ) return $statuses[$status_key];
			return [];
		}
		return $statuses;
	}

	public static function is_booking_active() {
		return Options::get_options( [
			'enable-booking'	=> true,
		] )['enable-booking'];
	}


	public static function get_booking_page_id() {
		return Options::get_options( [
			'booking-page-id'	=> 0,
		] )['booking-page-id'];
	}

	public static function get_booking_page_url( $step = "" ) {
		$booking_page_id = self::get_booking_page_id();
		$url = get_permalink( $booking_page_id );
		return esc_url( stripslashes( $url ) . $step );
	}

	public static function get_current_step() {
		$booking_steps = self::booking_steps();
		
		// Get current step from URL
		$request_uri = $_SERVER['REQUEST_URI'];
		$request_uri = remove_query_arg( 'book_id', $request_uri );
		$path_parts = explode('/', trim( $request_uri, '/') );
		
		// remove GET params
		$path_parts = array_filter( $path_parts, function( $part ) {
			return !empty( $part ) && strpos( $part, '?' ) === false;
		} );
		$path_parts = array_map( 'sanitize_text_field', $path_parts );
		$endpoint = end( $path_parts );

		$active_step = $endpoint;
		$active_step = Utils::ensure_values_in_array( $active_step, array_keys( $booking_steps ), array_key_first( $booking_steps ) );

		return $active_step;
	}

	public static function get_specialist( $only_id = false ) {
		$general_options = Options::get_options( [
			'booking-specialist-not-found'	=> esc_html__( "Selected specialist not found", 'drplus' ),
		] );

		$specialist_id = 0;
		if( !empty( $_GET['sid'] ) ) {
			$specialist_id = parent::convert_chars( $_GET['sid'], true, 'absint' );
		} else if( !empty( $_SESSION['booking']['specialist_id'] ) ) {
			$specialist_id = parent::convert_chars( $_SESSION['booking']['specialist_id'] , true, 'absint' );
		}

		if( empty( $specialist_id ) ) {
			Alert::view( [
				'type'	=> 'error',
				'icon'	=> 'drplus-icon-error',
				'text'	=> $general_options['booking-specialist-not-found'],
				'classes'	=> ['booking-alert']
			] );
			// Get prev page url
			$prev_page_url = wp_get_referer();
			if( empty( $prev_page_url ) ) {
				$prev_page_url = self::get_booking_page_url();
			}
			Button::view( [
				'text'	=> esc_html__( 'Return to previous page', 'drplus' ),
				'link'	=> esc_url( $prev_page_url ),
				'type'	=> 'bordered',
				'align' 	=> 'center',
				'small'		=> true,
			] );
			return false;
		}
		if( $only_id ) return $specialist_id;

		$specialist = new Specialist( $specialist_id );
		if( empty( $specialist->ID ) ) {
			Alert::view( [
				'type'	=> 'error',
				'icon'	=> 'drplus-icon-error',
				'text'	=> $general_options['booking-specialist-not-found'],
				'classes'	=> ['booking-alert']
			] );
			Button::view( [
				'text'	=> esc_html__( 'Back', 'drplus' ),
				'link'	=> self::get_booking_page_url(),
				'type'	=> 'bordered',
				'align' 	=> 'center',
			] );
			return false;
		}
		return $specialist;
	}

	public static function check_booking_session( array $keys ) {
		$error = false;
		if( empty( $_SESSION['booking'] ) ) {
			$error = true;
		} else {
			foreach( $keys as $key ) {
				if( empty( $_SESSION['booking'][$key] ) ) {
					$error = true;
					break;
				}
			}
		}

		if( $error ) {
			Alert::view( [
				'type'	=> 'error',
				'icon'	=> 'drplus-icon-error',
				'text'	=> esc_html__( 'Something went wrong. please try again', 'drplus' ),
				'classes'	=> ['booking-alert']
			] );
			Button::view( [
				'text'	=> esc_html__( 'Back', 'drplus' ),
				'link'	=> self::get_booking_page_url(),
				'type'	=> 'bordered',
				'align' 	=> 'center',
			] );
		}
		return !$error;
	}

	public static function specialist_info_html( $specialist ) {
		$avatar_url = DRPLUS_URI . 'assets/images/user.svg';
		if( !empty( $specialist->avatar ) ) {
			$avatar_url = get_avatar_url( $specialist->user_id );
		}
		$specialist_page = esc_url( UtilsSpecialists::get_page_link( $specialist ) );
		?>
		<div class="booking-specialist-info">
			<a href="<?php echo $specialist_page ?>" target="_blank" class="booking-specialist-avatar-wrap">
				<img src="<?php echo $avatar_url ?>" class="booking-specialist-avatar" alt="<?php echo esc_attr( $specialist->display_name ) ?>">
			</a>
			<a href="<?php echo $specialist_page ?>" target="_blank" class="booking-specialist-name"><?php echo esc_html( $specialist->display_name ) ?></a>
			<span class="booking-specialist-subtitle"><?php echo esc_html( $specialist->subtitle ) ?></span>
		</div>
		<?php
	}

	public static function specialist_office_html( $office, $icon_as_image = false, $show_map_url = false ) {
		if( $office->type == 'hospital' ) {
			$hospital_settings = Hospital::get_options( $office->id );
			$office->name = get_the_title( $office->id );
			$office->phone = $hospital_settings['phones'][0]['phone'] ?? "";
			$office->address = $hospital_settings['address'];
			$office->map_url = $hospital_settings['map_address'];
			if( !$icon_as_image ) {
				$office->image = get_the_post_thumbnail_url( $office->id );
			}
		} else {
			if( !$icon_as_image ) {
				if( $office->id == 'consultation' ) {
					$office->image = DRPLUS_URI . 'assets/images/online-consultation.webp';
				} else {
					$office->image = wp_get_attachment_image_url( $office->image );
				}
			}
		}
		if( empty( $office->image ) && !$icon_as_image ) {
			$office->image = DRPLUS_URI . 'assets/images/hospital-placeholder.webp';
		}
		?>
		<div class="booking-specialist-office">
			<div class="booking-specialist-office-head">
				<div class="booking-specialist-office-img-wrap">
					<?php if( $icon_as_image ) { ?>
						<div class="booking-specialist-office-icon"><i class="drplus-icon-location-fill"></i></div>
					<?php } else { ?>
						<img src="<?php echo $office->image ?>" class="booking-specialist-office-img" alt="<?php echo esc_attr( $office->name ) ?>">
					<?php } ?>
				</div>
				<div class="booking-specialist-office-info">																
					<span class="booking-specialist-office-name line-clamp line-clamp-1"><?php echo esc_html( $office->name ) ?></span>
					<?php if( !empty( $office->phone ) ) { ?>
						<span class="booking-specialist-office-phone">
							<i class="drplus-icon-calling"></i>
							<?php echo esc_html( $office->phone ) ?>
						</span>
					<?php } ?>
				</div>
			</div>
			<?php if( !empty( $office->address ) ) { ?>
				<p class="booking-specialist-office-address"><?php echo esc_html( $office->address ) ?></p>
			<?php } ?>
			<?php if( !empty( $show_map_url ) && !empty( $office->map_url ) ) { ?>
				<a href="<?php echo esc_url( $office->map_url ) ?>" class="booking-specialist-office-office-map" target="_blank" title="<?php echo esc_attr( $office->name ) ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Show %s on the map', 'drplus' ), $office->name ) ) ?>">
					<i class="drplus-icon-routing"></i>
					<?php esc_html_e( 'Show on the map', 'drplus' ) ?>
				</a>
			<?php } ?>
		</div>
		<?php
	}

	public static function get_times_by_office( $office_id, $specialist ) : array {
		$return = [
			'default_times'	=> [],
			'days'			=> [],
		];
		$specialist = new Specialist( $specialist );
		if( empty( $specialist ) || empty( $specialist->ID ) || empty( $specialist->user_id ) ) return $return;

		// Get times for specific user and office
		$where['AND'] = [
			'`office`=%s'	=> $office_id
		];
		$db_times = (new Times)->find_by_user_id( $specialist->user_id, null, $where )->data;

		$default_times = [];
		$days = [];

		foreach( $db_times as $db_time ) {
			if( $db_time['day'] === '9' ) {
				$default_times[] = $db_time;
			} else {
				$days[$db_time['day']]['status'] = $db_time['status'];
				$days[$db_time['day']]['day'] = $db_time['day'];
				if( $db_time['use_default'] == true ) {
					$days[$db_time['day']]['use_default'] = true;
				} else {
					$days[$db_time['day']]['use_default'] = false;
				}
				$days[$db_time['day']]['times'][] = $db_time;
			}
		}

		$US_week_days = [__( 'Sunday', 'drplus' ), __( 'Monday', 'drplus' ), __( 'Tuesday', 'drplus' ), __( 'Wednesday', 'drplus' ), __( 'Thursday', 'drplus' ), __( 'Friday', 'drplus' ), __( 'Saturday', 'drplus' )];
		for( $day_index = 0; $day_index <= 6; $day_index++ ) {
			$days[$day_index]['day_name'] =  $US_week_days[$day_index];
			if( count( $days[$day_index] ) > 1 ) continue;

			$days[$day_index]['status'] = false;
			$days[$day_index]['day'] = $day_index;
			$days[$day_index]['use_default'] = true;
		}

		// Convert to Iran week template
		ksort( $days );
		$days = array_merge(array_slice($days, 6), array_slice($days, 0, 6));

		return [
			'default_times'	=> $default_times,
			'days'			=> $days,
		];
	}

	public static function reserve_time_chunks() {
		return [
			'15'	=> esc_attr__( '15 minutes', 'drplus' ),
			'30'	=> esc_attr__( '30 minutes', 'drplus' ),
			'45'	=> esc_attr__( '45 minutes', 'drplus' ),
			'60'	=> esc_attr__( '1 hour', 'drplus' ),
			'90'	=> esc_attr__( '1 hour and 30 minutes', 'drplus' ),
			'120'	=> esc_attr__( '2 hours', 'drplus' ),
		];
	}

	public static function get_available_time_slots( $date, $specialist_id, $office_id, $chunk_duration ) {
		$day_index = date( 'w', strtotime( $date ) ); // Index (0 for Sunday, 6 for Saturday)
		$date = date( 'Y-m-d', strtotime( $date ) );

		// Current date and time
		$current_date = date( 'Y-m-d' );
		$current_time = wp_date( 'H:i:s' );
		$current_timestamp = strtotime( $current_time ); // Current timestamp

		// Get specialist user ID
		$user_id = (new Specialists)->get( $specialist_id, ['user_id'] )->user_id;

		// Get availability times of requested day index and 9 (default times)
		$times_where = [
			'AND'	=> [
				'day IN (%d, %d)'	=> [$day_index, 9],
				'office=%s'			=> $office_id,
				'user_id=%d'		=> $user_id
			]
		];
		$day_times_db = (new Times)->find_by_user_id( $user_id, 1, $times_where );
		$default_times = [];
		$available_times = [];
		$use_default = true;
		foreach( $day_times_db->data as $time_db ) {
			if( !Utils::to_bool( $time_db['status'] ) ) continue;
			if( $time_db['day'] == 9 ) {
				$default_times[] = $time_db;
			} else {
				$available_times[] = $time_db;
				$use_default = Utils::to_bool( $time_db['use_default'] );
			}
		}
		if( $use_default ) {
			$available_times = $default_times;
		}
		if( empty( $available_times ) ) return [];
	
		// Get all bookings for the day
		$exclude_statuses = ['cancelled', 'refunded', 'failed'];
		$where = [
			'AND'	=> [
				'date=%s'																			=> $date,
				'order_status NOT IN (' . DB::placeholder( $exclude_statuses, '%s' ) . ')'			=> $exclude_statuses,
				'specialist_id=%d'																	=> $specialist_id,
				'office_id=%s'																		=> $office_id,
			]
		];
		$existing_bookings = (new DBBooking)->find( $where, ['start_time', 'end_time'] )->data;
	
		// Convert existing bookings to an array of time ranges
		$booked_ranges = array_map(function($booking) {
			return ['start' => $booking['start_time'], 'end' => $booking['end_time']];
		}, $existing_bookings);
	
		// Generate available slots based on chunk duration
		$available_slots = [];
		foreach( $available_times as $time_range ) {
			$start_time = strtotime( $time_range['from'] );
			$end_time = strtotime( $time_range['to'] );
	
			while ($start_time + ($chunk_duration * 60) <= $end_time) {
				$slot_start = date('H:i', $start_time);
				$slot_end = date('H:i', $start_time + ($chunk_duration * 60));
	
				// Check if this slot overlaps with any booked range
				$is_available = true;
				if( $date == $current_date && $slot_start < $current_time ) {
					$is_available = false;
				} else {
					foreach( $booked_ranges as $range ) {
						if( $slot_start . ":00" < $range['end'] && $slot_end > $range['start'] ) {
							$is_available = false;
							break;
						}
					}
				}

				// set time name (morning, noon, evening)
				$time_name = '';
				$time_name = Date::get_time_period( (int) date( 'H', $start_time ) );

				$available_slots[] = [
					'from'		=> $slot_start,
					'to'		=> $slot_end,
					'available'	=> $is_available,
					'label'		=> $time_name,
				];
	
				// Move to the next slot
				$start_time += $chunk_duration * 60;
			}
		}
	
		return $available_slots;
	}

	public static function get_booking_product_id() {
		$booking_product_id = get_option( 'drplus_booking_product_id', "" );
		if ( $booking_product_id && get_post( $booking_product_id ) ) {
			return $booking_product_id;
		} else {
			return self::create_booking_product();
		}
	}

	public static function set_booking_product_id( $product_id ) {
		update_option( 'drplus_booking_product_id', $product_id, false );
	}

	public static function create_booking_product() {
		$product = new \WC_Product_Simple();
		$product->set_name( 'Book Product (Drplus Theme) - please do not remove or edit.' );
		$product->set_status( 'private' ); // Hidden from shop
		$product->set_catalog_visibility( 'hidden' ); // Hides from search results
		
		// Set virtual
		$product->set_virtual( true );
		$product->set_manage_stock( false );
		$product->set_sold_individually( true );

		// Save the variable product to get an ID
		$product_id = $product->save();
		self::set_booking_product_id( $product_id );
		return $product_id;
	}

	public static function new( $book_data ) {
		$book = new DBBooking();
		foreach( $book_data as $key => $value ) {
			$book->$key = $value;
		}
		return $book->insert();
	}

	public static function update( $id, $data ) {
		$book = new DBBooking( $id );
		if( empty( $book ) ) return false;

		foreach( $data as $key => $value ) {
			$book->$key = $value;
		}
		return $book->update();
	}

	public static function update_status( $id, $status ) {
		$book = new DBBooking( $id );
		if( empty( $book ) ) return false;
		$book->order_status = $status;
		return $book->update();
	}

	public static function get_specialist_appointments_count( $specialist_id, $office = "", $date = "", $where = [] ) {
		$exclude_statuses = ['cancelled', 'refunded', 'failed', 'on-hold'];
		$where['AND']['specialist_id=%d'] = $specialist_id;
		$where['AND']['order_status NOT IN (' . DB::placeholder( $exclude_statuses, '%s' ) . ')'] = $exclude_statuses;
		if( !empty( $office ) ) {
			$where['AND']['office_id=%s'] = $office;
		}
		if( !empty( $date ) ) {
			$where['AND']['date=%s'] = $date;
		}
		
		return (new DBBooking)->count( $where );
	}

	public static function get_specialist_appointments( $specialist_id, $statuses = [], $where = [], $cols = [], $limit = 10, $offset = 0 ) {
		$where['AND']['specialist_id=%d'] = $specialist_id;

		if( !empty( $statuses ) ) {
			if( !is_array( $statuses ) ) {
				$statuses = [$statuses];
			}
			$where['AND']['order_status IN (' . DB::placeholder( $statuses, '%s' ) . ')'] = $statuses;
		}
		$booking = new DBBooking();

		$attr = [];
		$attr['ORDER BY'] = 'date ASC, start_time ASC';
		if( !empty( $limit ) ) {
			$attr['LIMIT'] = $limit;
		}
		if( !empty( $offset ) ) {
			$attr['OFFSET'] = $offset;
		}
		
		return $booking->find( $where, $cols, $attr )->data;
	}

	public static function get_customer_appointments( $user_id, $statuses = [], $where = [], $cols = [], $limit = 10, $offset = 0 ) {
		$where['AND']['customer_id=%d'] = $user_id;

		if( !empty( $statuses ) ) {
			if( !is_array( $statuses ) ) {
				$statuses = [$statuses];
			}
			$where['AND']['order_status IN (' . DB::placeholder( $statuses, '%s' ) . ')'] = $statuses;
		}
		$booking = new DBBooking();

		$attr = [];
		$attr['ORDER BY'] = 'date DESC, start_time ASC';
		if( !empty( $limit ) ) {
			$attr['LIMIT'] = $limit;
		}
		if( !empty( $offset ) ) {
			$attr['OFFSET'] = $offset;
		}
		
		return $booking->find( $where, $cols, $attr )->data;
	}

	public static function get_customer_future_appointments( $user_id, $statuses = [], $where = [], $cols = [], $limit = 10, $offset = 0 ) {
		$where['AND']['date > %s'] = date( 'Y-m-d' );
		$where['AND']['start_time > %s'] = date_i18n( 'H:i:s' );

		return self::get_customer_appointments( $user_id, $statuses, $where, $cols, $limit, $offset );
	}

	public static function get_customer_past_appointments( $user_id, $statuses = [], $where = [], $cols = [], $limit = 10, $offset = 0 ) {
		$where['AND']['date < %s'] = date( 'Y-m-d' );
		$where['AND']['start_time < %s'] = date_i18n( 'H:i:s' );

		return self::get_customer_appointments( $user_id, $statuses, $where, $cols, $limit, $offset );
	}
}