<?php
use DrPlus\Utils;
use DrPlus\Utils\Options;
use DrPlus\Utils\WC;

if( !function_exists( "drplus_wc_pagination_args" ) ) {
	function drplus_wc_pagination_args( $args ) {
		$is_rtl = is_rtl();
		$args['prev_text'] = esc_html_x( "Previous", 'Pagination', 'drplus' );
		$args['prev_text'] .= $is_rtl ? "<i class='drplus-icon-chevron-right-dot'></i>" : "<i class='drplus-icon-chevron-left-dot'></i>";
		$args['next_text'] = esc_html_x( "Next", 'Pagination', 'drplus' );
		$args['next_text'] .= $is_rtl ? "<i class='drplus-icon-chevron-left-dot'></i>" : "<i class='drplus-icon-chevron-right-dot'></i>";
		return $args;
	}
}
add_filter( 'woocommerce_pagination_args', 'drplus_wc_pagination_args' );

// Change variable products price range
if( !function_exists( "drplus_wc_format_price_range" ) ) {
	function drplus_wc_format_price_range( $price_html, $from, $to ) {
		$price_html = '<div class="price-range-wrap">';
			$price_html .= '<div class="price-range price-range-from">';
				$price_html .= '<div class="price-range-label">' . esc_html_x( 'From', 'Price range', 'drplus' ) . '</div>';
				$price_html .= is_numeric( $from ) ? wc_price( $from ) : $from;
			$price_html .= '</div>';
			$price_html .= '<div class="price-range price-range-to">';
				$price_html .= '<div class="price-range-label">' . esc_html_x( 'To', 'Price range', 'drplus' ) . '</div>';
				$price_html .= is_numeric( $to ) ? wc_price( $to ) : $to;
			$price_html .= '</div>';
		$price_html .= '</div>';
		return $price_html;
	}
}
add_filter( 'woocommerce_format_price_range', 'drplus_wc_format_price_range', 10, 3 );

remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10 );
remove_action( 'woocommerce_archive_description', 'woocommerce_product_archive_description', 10 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );

remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
if( !function_exists( "drplus_wc_template_loop_product_link_open" ) ) {
	function drplus_wc_template_loop_product_link_open() {
		global $product;

		$link = apply_filters( 'woocommerce_loop_product_link', get_the_permalink(), $product );

		echo '<a href="' . esc_url( $link ) . '" class="woocommerce-LoopProduct-link woocommerce-loop-product__link" title="' . esc_attr( $product->get_name() ) . '">';
	}
}
add_action( 'woocommerce_before_shop_loop_item', 'drplus_wc_template_loop_product_link_open', 10 );

remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

if( !function_exists( "drplus_wc_catalog_orderby" ) ) {
	function drplus_wc_catalog_orderby( $args ) {
		$args['menu_order']	= __( 'Default sorting', 'drplus' );
		$args['popularity']	= __( 'Popularity', 'drplus' );
		$args['rating']		= __( 'Average rating', 'drplus' );
		$args['date']		= __( 'Latest', 'drplus' );
		$args['price']		= __( 'Price: low to high', 'drplus' );
		$args['price-desc']	= __( 'Price: high to low', 'drplus' );
		return $args;
	}
}
add_filter( 'woocommerce_catalog_orderby', 'drplus_wc_catalog_orderby' );

if( !function_exists( "drplus_wc_move_out_of_stock_to_end" ) ) {
	function drplus_wc_move_out_of_stock_to_end( $query ) {
		static $executed = false;
		if( !$executed ) {
			$options = Options::get_options( [
				'wc-move-out-of-stock-to-end'	=> false,
			] );
			if( !Utils::to_bool( $options['wc-move-out-of-stock-to-end'] ) ) return;

			if( isset( $_GET['instock'] ) && Utils::to_bool( $_GET['instock'] ) ) return;

			add_filter( 'posts_clauses', function( $args ) {
				global $wpdb;
				$args['join'] .= " LEFT JOIN {$wpdb->postmeta} AS bmt1 ON ({$wpdb->posts}.ID=bmt1.post_id)";
				$args['join'] .= " LEFT JOIN {$wpdb->postmeta} AS bmt2 ON ({$wpdb->posts}.ID=bmt2.post_id)";
				$args['join'] .= " LEFT JOIN {$wpdb->postmeta} AS bmt3 ON ({$wpdb->posts}.ID=bmt3.post_id)";

				$args['where'] .= " AND ( bmt1.meta_key = '_stock_status' AND ( ( bmt2.meta_key = '_price' OR bmt3.post_id IS NULL ) ) )";

				$default_orderby = $args['orderby'];
				$args['orderby'] = " bmt1.meta_value ASC, bmt1.meta_value ASC, bmt1.meta_value+0 ASC, bmt1.meta_value ASC";
				if( $default_orderby ) {
					$args['orderby'] .= ", {$default_orderby}";
				}

				return $args;
			} );
			$executed = true;
		}
	}
}
add_filter( 'woocommerce_product_query', 'drplus_wc_move_out_of_stock_to_end' );

if( !function_exists( "drplus_wc_move_out_of_stock_to_end_custom_loop" ) ) {
	function drplus_wc_move_out_of_stock_to_end_custom_loop( $query ) {
		if( $query->get( 'post_type' ) == 'product' ) {
			drplus_wc_move_out_of_stock_to_end( $query );
		}
	}
}
add_action( 'pre_get_posts', 'drplus_wc_move_out_of_stock_to_end_custom_loop' );

remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
if( !function_exists( "drplus_wc_loop_product_thumbnail" ) ) {
	function drplus_wc_loop_product_thumbnail() {
		?>
		<div class="product-thumbnail-wrap">
			<?php echo woocommerce_get_product_thumbnail() ?>
		</div>
		<?php
	}
}
add_action( 'woocommerce_before_shop_loop_item_title', 'drplus_wc_loop_product_thumbnail' );

if( !function_exists( "drplus_wc_loop_product_category" ) ) {
	function drplus_wc_loop_product_category() {
		global $product;
		$category = $product->get_category_ids()[0];
		$category = get_term( $category, 'product_cat' );
		echo '<div class="product-category">' . $category->name . '</div>';
	}
}
add_action( 'woocommerce_after_shop_loop_item_title', 'drplus_wc_loop_product_category' );

remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 11 );

if( !function_exists( "drplus_wc_shop_loop_product_badge" ) ) {
	function drplus_wc_shop_loop_product_badge() {
		global $product;
		$badge = WC::get_product_badge( $product->get_id() );
		if( empty( $badge ) ) return;
		?>
		<div class="drplus-product-badge drplus-popover-wrap drplus-popover-start">
			<?php echo wp_get_attachment_image( $badge['image'], [24, 24] ) ?>
			<div class="drplus-popover"><?php echo esc_html( $badge['name'] ) ?></div>
		</div>
		<?php
	}
}
add_action( 'woocommerce_after_shop_loop_item', 'drplus_wc_shop_loop_product_badge', 7 );