<?php
namespace DrPlus\Utils;

use DrPlus\DB;
use DrPlus\DB\NotificationsUserRel as DBNotificationsUserRel;
use DrPlus\Utils;

class Notifications extends Utils {
	private static $users = [];
	private static $reads = [];

	public static function default_options() {
		return [
			'message' => '',
			'recipients' => 'all_users',
		];
	}

	public static function get_options( $post_id = 0 ) {
		return parent::get_post_options( self::default_options(), $post_id );
	}

	public static function save_options( array $options, $post_id = 0 ) {
		parent::save_post_options( $options, self::default_options(), $post_id );
	}
	public static function get( $post = null, bool $get_users = true ) {
		$post = parent::get_post( $post );
		$options = self::get_options( $post->ID );
		$options['users'] = [];
		if( in_array( $options['recipients'], ['custom_users', 'custom_specialists'] ) ) {
			$user_ids = (new DBNotificationsUserRel)->find( [
				'AND'	=> [
					'`notif_id`=%d'	=> $post->ID,
				]
			], ['user_id'] )->data;
			if( !empty( $user_ids ) ) {
				$user_ids = wp_list_pluck( $user_ids, 'user_id' );
				if( $get_users ) {
					foreach( $user_ids as $user_id ) {
						if( empty( self::$users[$user_id] ) ) {
							self::$users[$user_id] = get_user_by( 'id', $user_id );
						}
						$options['users'][] = self::$users[$user_id];
					}
				} else {
					$options['users'] = $user_ids;
				}
			}
		}
		return $options;
	}

	public static function get_user_reads( $user_id = 0 ) : array {
		$user_id = parent::get_user_id( $user_id );
		if( !isset( self::$reads[$user_id] ) ) {
			self::$reads[$user_id] = get_user_meta( $user_id, 'drplus-read-notifs', true );
			if( !is_array( self::$reads[$user_id] ) ) self::$reads[$user_id] = [];
		}

		return self::$reads[$user_id];
	}

	public static function get_user_notifications( bool $include_reads = false, string $notif_type = 'public' ) : array {
		static $notifications = null;
		if( $notifications === null && is_user_logged_in() ) {
			$user_id = get_current_user_id();

			if( $notif_type == 'specialists' ) {
				$recipients = 'all_specialists';
			} else {
				$recipients = 'all_users';
			}

			$post_in = [];
			$db_args = [
				'`user_id`=%d'	=> $user_id,
			];
			$db_posts = (new DBNotificationsUserRel)->find( $db_args, ['notif_id'] )->data;
			if( !empty( $db_posts ) ) {
				$post_in = wp_list_pluck( $db_posts, 'notif_id' );
			}

			global $wpdb;
			$query = "SELECT p.`ID`, p.`post_date`, p.`post_title`, p.`post_content` FROM `{$wpdb->posts}` AS p INNER JOIN `{$wpdb->postmeta}` AS pm ON pm.`post_id`=p.`ID` WHERE ";
			$where = [];
			$prepares = [];
			$prepares = [
				'_recipients',
				$recipients
			];
			if( $post_in ) {
				$where[] = "((pm.`meta_key`=%s AND pm.`meta_value`=%s) OR p.`ID` IN (" . DB::placeholder( $post_in, '%d' ) . ")) ";
			} else {
				$where[] = "(pm.`meta_key`=%s AND pm.`meta_value`=%s) ";
			}
			$prepares = array_merge( $prepares, $post_in );

			$prepares[] = 'notification';
			$prepares[] = 'publish';
			$where[] = " p.`post_type`=%s AND p.`post_status`=%s";
			$query .= implode( " AND ", $where );
			$query .= " GROUP BY p.`ID` ORDER BY p.`post_date` DESC";
			$query = $wpdb->prepare( $query, $prepares );
		
			$notifications = $wpdb->get_results( $query );
			
			$reads = self::get_user_reads( $user_id );
			$date_format = get_option( 'date_format' );
			$time_format = get_option( 'time_format' );
			foreach( $notifications as $index => $notification ) {
				$notification = get_post( $notification );
				$notification->post_date = date_i18n( "{$date_format} {$time_format}", strtotime( $notification->post_date ) );
				$notification->read = in_array( $notification->ID, $reads );
				$notifications[$index] = $notification;
			}
		}

		$results = $notifications;
		if( !is_array( $results ) ) {
			$results = [];
		}
		if( !$include_reads && !empty( $results ) ) {
			$results = array_filter( $results, fn( $notification ) => $notification->read === false );
		}

		return $results;
	}

	public static function add_user_read( int $notif_id, $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		$reads = self::get_user_reads( $user_id );
		if( !in_array( $notif_id, $reads ) ) {
			$reads[] = $notif_id;
			update_user_meta( $user_id, 'drplus-read-notifs', $reads );
			self::$reads[$user_id] = $reads;
		}
	}

	public static function count_user_unread() {
		return is_user_logged_in() ? count( self::get_user_notifications() ) : 0;
	}

	public static function recipients_types() {
		return [
			'all_users'				=> __( 'All users', 'drplus' ),
			'all_specialists'		=> __( 'All specialists', 'drplus' ),
			'custom_users'			=> __( 'Custom users', 'drplus' ),
			'custom_specialists'	=> __( 'Custom specialists', 'drplus' ),
		];
	}
}