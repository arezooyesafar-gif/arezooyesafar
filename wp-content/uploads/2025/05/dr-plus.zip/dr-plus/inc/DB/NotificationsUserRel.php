<?php
namespace DrPlus\DB;

use DrPlus\DB as DB;
use DrPlus\Utils;

class NotificationsUserRel extends DB {
	public string $table = 'drplus_notifications_user_rel';
	public array $exclude_columns = ['created_at', 'updated_at', 'creator', 'deleted'];

	public array $columns = [
		'id'		=> 'INT NOT NULL AUTO_INCREMENT',
		'notif_id'	=> 'INT NOT NULL',
		'user_id'	=> 'TINYTEXT NOT NULL',
		'type'		=> 'VARCHAR(11) NOT NULL',
	];
	public array $defaults = [
		'notif_id'	=> 0,
		'user_id'	=> 0,
		'type'		=> 'public', // public or specialists
	];

	public function sanitize( bool $update = false ) {
		$this->notif_id	= Utils::convert_chars( $this->notif_id, true, 'absint' );
		$this->user_id	= Utils::convert_chars( $this->user_id, true, 'absint' );
		$this->type		= Utils::convert_chars( $this->type );
	}
}
new NotificationsUserRel;