<?php
namespace DrPlus\Utils;

use DrPlus\Utils;

class User extends Utils {
	public static function get_wishlist_products( $user_id = 0, $retrieve = 'ids', array $where = [], array $columns = [], array $attrs = [], array $get_products_args = [] ) {
		$user_id = parent::get_user_id( $user_id );
		static $products = null;
		if( $products === null ) {
			$products = Wishlist::get_user_wishlist( $user_id, $where, $columns, $attrs );
			if( !empty( $products ) ) {
				if( $retrieve == 'ids' ) {
					$products = wp_list_pluck( $products, 'product_id' );
				} else {
					$get_products_args['include'] = wp_list_pluck( $products, 'product_id' );
					$products = wc_get_products( $get_products_args );
				}
			}
		}

		return $products;
	}

	public static function get_account_menu_items() {
		$account_btn_items = [];
		if( is_user_logged_in() ) {
			$home_url = home_url();
			$my_account_link = Utils::is_wc_active() ? get_permalink( get_option( 'woocommerce_myaccount_page_id' ) ) : $home_url;
			if( has_nav_menu( 'account-menu' ) ) {
				foreach( Utils::get_nav_menu_items_by_location( 'account-menu' ) as $menu_item ) {
					$account_btn_items[] = [
						'label'	=> $menu_item->post_title,
						'link'	=> $menu_item->url,
						'icon'	=> UI::get_menu_icon( $menu_item->ID, 'icon' ),
					];
				}
			} else {
				$account_btn_items = [
					[
						'label'	=> __( 'Dashboard', 'drplus' ),
						'link'	=> $my_account_link,
						'icon'	=> 'drplus-icon-element-3',
					],
					[
						'label'	=> __( 'Orders', 'drplus' ),
						'link'	=> esc_url( wc_get_endpoint_url( 'orders' ) ),
						'icon'	=> 'drplus-icon-bag-1',
					],
					[
						'label'	=> _x( 'Wishlist', 'Plural', 'drplus' ),
						'link'	=> $my_account_link . "/wishlist",
						'icon'	=> 'drplus-icon-heart',
					],
					[
						'label'	=> __( 'Notifications', 'drplus' ),
						'link'	=> esc_url( wc_get_endpoint_url( 'notifications' ) ),
						'icon'	=> 'drplus-icon-notification',
					],
					[
						'label'	=> __( 'Logout', 'drplus' ),
						'link'	=> Utils::is_wc_active() ? wc_logout_url( $home_url ) : wp_logout_url( $home_url ),
						'icon'	=> 'drplus-icon-logout',
					],
				];
			}
		} else {
			$options = Options::get_options( [
				'login-text'		=> esc_html__( "Login", 'drplus' ),
				'login-icon'		=> "drplus-icon-login",
				'guest-login-url'	=> home_url( "?login=true" ),
				'signup-text'		=> esc_html__( "Signup", 'drplus' ),
				'signup-icon'		=> "drplus-icon-user-add",
				'signup-link'		=> home_url( "?login=true&section=signup" ),
			] );
			$account_btn_items = [
				'login'	=> [
					'label'	=> $options['login-text'],
					'link'	=> $options['guest-login-url'],
					'icon'	=> $options['login-icon'],
				],
				'signup'	=> [
					'label'	=> $options['signup-text'],
					'link'	=> $options['signup-link'],
					'icon'	=> $options['signup-icon'],
				],
			];
		}
		return $account_btn_items;
	}

	public static function get_avatar_id( $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		return absint( get_user_meta( $user_id, 'avatar', true ) );
	}

	public static function save_avatar_id( $avatar_id, $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		update_user_meta( $user_id, 'avatar', $avatar_id );
	}

	public static function get_phone( $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		$user_phone = get_user_meta( $user_id, 'mobile', true );
		if( !$user_phone ) {
			$user_phone = get_user_meta( $user_id, 'billing_phone', true );
			if( !$user_phone ) {
				$user_phone = get_user_meta( $user_id, 'shipping_phone', true );
			}
		}
		return $user_phone;
	}

	public static function update_phone() {
		
	}

	public static function get_birthday( $user_id = 0, string $format = 'U' ) {
		$user_id = parent::get_user_id( $user_id );
		$birthday = get_user_meta( $user_id, 'birthday', true );
		if( !is_numeric( $birthday ) ) {
			$birthday = strtotime( $birthday );
		}
		return date_i18n( $format, $birthday );
	}

	public static function get_nid( $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		return get_user_meta( $user_id, 'nid', true );
	}

	public static function get_gender( $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		return parent::ensure_values_in_array( get_user_meta( $user_id, 'gender', true ), ['male', 'female'], 'male' );
	}

	public static function get_email( $user_id ) {
		$user_id = parent::get_user_id( $user_id );
		
	}

	public static function find_user_by_mobile( string $mobile ) {
		$user = get_user_by( 'login', $mobile );
		if( empty( $user ) ) {
			$user = get_users( [
				'meta_query' => array(
					'relation' => 'OR',
					array(
						'key'   => 'mobile',
						'value' => $mobile,
					),
					array(
						'key'   => 'billing_phone',
						'value' => $mobile,
					),
					array(
						'key'   => 'shipping_phone',
						'value' => $mobile,
					),
				),
				'number' => 1,
				'fields' => 'ID',
			] );
			$user = !empty( $user[0] ) ? $user[0] : '';
		}
		return $user;
	}

	/**
	 * Update user meta and user data
	 *
	 * @param array $data
	 * @param mixed $user_id
	 * @param boolean $start_transaction
	 * @return boolean
	 */
	public static function update_user( array $data, $user_id = 0, bool $start_transaction = true ) : bool {
		$user_id = parent::get_user_id( $user_id );

		if( $start_transaction ) {
			global $wpdb;
			$wpdb->query( "START TRANSACTION" );
		}

		$meta_keys = ['first_name', 'last_name', 'birthday', 'specialist_code', 'nid', 'mobile', 'gender', 'avatar'];
		foreach( $meta_keys as $meta_key ) {
			if( isset( $data[$meta_key] ) ) {
				$data[$meta_key] = parent::convert_chars( $data[$meta_key] );
				// Sanitize
				if( $meta_key == 'birthday' ) {
					if( is_numeric( $data[$meta_key] ) ) {
						$data[$meta_key] = date_i18n( "Y-m-d", $data[$meta_key] );
					}
					$data[$meta_key] = Date::maybe_j2g( $data[$meta_key] );
				} else if( $meta_key == 'nid' ) {
					if( !Validators::id_code( $data[$meta_key] ) ) continue;
				} else if( $meta_key == 'mobile' ) {
					$data[$meta_key] = Sanitizers::phone( $data[$meta_key] );
				} else if( $meta_key == 'gender' ) {
					$data[$meta_key] = parent::ensure_values_in_array( $data[$meta_key], ['male', 'female'], 'male' );
				} else if( $meta_key == 'avatar' ) {
					$data[$meta_key] = absint( $data[$meta_key] );
				}
				update_user_meta( $user_id, $meta_key, $data[$meta_key] );
			}
		}

		// Update user data
		$user_data_keys = ['email'];
		// Update display_name
		if( isset( $data['first_name'] ) || isset( $data['last_name'] ) ) {
			$first_name = $data['first_name'] ?? get_user_meta( $user_id, 'first_name', true );
			$last_name = $data['last_name'] ?? get_user_meta( $user_id, 'last_name', true );
			$data['display_name'] = "{$first_name} {$last_name}";
			$user_data_keys[] = 'display_name';
		}
		$user_data = [
			'ID'	=> $user_id,
		];
		foreach( $user_data_keys as $user_data_key ) {
			if( isset( $data['email'] ) ) {
				$user_data['user_email'] = parent::convert_chars( $data['email'], true, 'sanitize_email' );
			}
			if( isset( $data['display_name'] ) ) {
				$user_data['display_name'] = parent::convert_chars( $data['display_name'] );
			}
		}
		wp_update_user( $user_data );

		if( $start_transaction ) {
			$wpdb->query( 'COMMIT' );
		}

		return true;
	}

	public static function add_recently_visited_specialist( $user_id = 0, $specialist_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
	
		// if user is guest save in cookie
		$recently_visited = self::get_user_recently_visited_specialists_ids( $user_id );
		// Add specialist id to first position
		array_unshift( $recently_visited, $specialist_id );
		// Remove duplicates
		$recently_visited = array_unique( $recently_visited );
		// Remove oldest 10
		if( count( $recently_visited ) > 10 ) {
			$recently_visited = array_slice( $recently_visited, 0, 10 );
		}

		if( !$user_id ) {
			$recently_visited = json_encode( $recently_visited );
			setcookie( 'drplus_recent_specialists_visited', $recently_visited, time() + 60 * 60 * 24 * 30, COOKIEPATH, COOKIE_DOMAIN );
		} else {
			update_user_meta( $user_id, '_drplus_recent_specialists_visited', $recently_visited );
		}
	}

	public static function get_user_recently_visited_specialists_ids( $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		$recently_visited = [];
		if( !$user_id ) {
			$recently_visited = isset( $_COOKIE['drplus_recent_specialists_visited'] ) ? json_decode( stripslashes( $_COOKIE['drplus_recent_specialists_visited'] ), true ) : [];
		} else {
			$recently_visited = get_user_meta( $user_id, '_drplus_recent_specialists_visited', true );
		}
		if( !is_array( $recently_visited ) ) {
			$recently_visited = [];
		}
		return $recently_visited;
	}

	public static function order_by() {
		return [
			'ID'				=> esc_html__( 'ID', 'drplus' ),
			'display_name'		=> esc_html__( 'User display name', 'drplus' ),
			'user_login'		=> esc_html__( 'Username', 'drplus' ),
			'user_registered'	=> esc_html__( 'Registered date', 'drplus' ),
			'rand'				=> esc_html__( 'Random', 'drplus' ),
		];
	}

	public static function get_user_appointments_reviews( $user_id = 0 ) {
		$user_id = parent::get_user_id( $user_id );
		$appointments_reviews = [];
		if( $user_id ) {
			$appointments_reviews = get_user_meta( $user_id, 'appointments_reviews', true );
			if( !is_array( $appointments_reviews ) ) {
				$appointments_reviews = [];
			}
		}
		return $appointments_reviews;
	}

	public static function update_user_appointments_reviews( $user_id = 0, $order_id, $review_id ) {
		$user_id = parent::get_user_id( $user_id );

		if( $user_id ) {
			$appointments_reviews = self::get_user_appointments_reviews( $user_id );
			$appointments_reviews[$order_id] = $review_id;
			update_user_meta( $user_id, 'appointments_reviews', $appointments_reviews );
		}
	}
}