<?php

use DrPlus\Utils\Booking;
use DrPlus\Utils\Formatters;
use DrPlus\Utils\Sanitizers;
use DrPlus\Utils\WC;

if( !defined( 'ABSPATH' ) ) exit;

$today_day_index = date('w'); // 0 (Sunday) to 6 (Saturday)
$today_date = date('Y-m-d');
if( $today_day_index == 6 ) {
    $last_saturday = $today_date;
} else {
    $last_saturday = date('Y-m-d', strtotime('last Saturday'));
}
if( $today_day_index == 5 ) {
    $next_friday = $today_date;
} else {
    $next_friday = date('Y-m-d', strtotime('next Friday'));
}

$where['AND'] = [
	'date >= %s' => $last_saturday,
	'date <= %s' => $next_friday,
];
$week_app_count = Booking::get_specialist_appointments_count( $specialist->ID, "", "", $where );
$today_app_count = Booking::get_specialist_appointments_count( $specialist->ID, "", $today_date );

$month_income = 0;
?>
<h2 class="drplus-myaccount-page-title"><?php esc_html_e( 'Dashboard', 'drplus' ) ?></h2>
<section class="drplus-specialist-statistics">
	<div class="drplus-specialist-statistic">
		<div class="drplus-specialist-statistic-texts">
			<div class="drplus-specialist-statistic-title"><?php esc_html_e( 'Patients of this week', 'drplus' ) ?></div>
			<div class="drplus-specialist-statistic-value"><?php echo number_format_i18n( $week_app_count ) ?></div>
		</div>
		<i class="drplus-specialist-statistic-icon drplus-icon-doctor-profile"></i>
	</div>

	<div class="drplus-specialist-statistic">
		<div class="drplus-specialist-statistic-texts">
			<div class="drplus-specialist-statistic-title"><?php esc_html_e( "This month's income", 'drplus' ) ?></div>
			<div class="drplus-specialist-statistic-value"><?php echo Formatters::price( $month_income ) ?></div>
		</div>
		<i class="drplus-specialist-statistic-icon drplus-icon-income"></i>
	</div>

	<div class="drplus-specialist-statistic">
		<div class="drplus-specialist-statistic-texts">
			<div class="drplus-specialist-statistic-title"><?php esc_html_e( "Today's appointments", 'drplus' ) ?></div>
			<div class="drplus-specialist-statistic-value"><?php echo number_format_i18n( $today_app_count ) ?></div>
		</div>
		<i class="drplus-specialist-statistic-icon drplus-icon-counter"></i>
	</div>
</section>

<section class="drplus-specialist-quick-access-section">
	<h3 class="drplus-myaccount-page-title"><?php esc_html_e( 'Quick access', 'drplus' ) ?></h3>
	<div class="drplus-specialist-quick-access-items">
		<?php foreach( WC::specialist_profile_sections() as $qa_key => $qa ) { ?>
			<a href="<?php echo esc_url( wc_get_endpoint_url( "specialist-dashboard/{$qa_key}" ) ) ?>" class="drplus-specialist-quick-access">
				<?php echo Sanitizers::icon( $qa['icon'], 'drplus-specialist-quick-access-icon' ) ?>
				<div class="drplus-specialist-quick-access-label"><?php echo esc_html( $qa['label'] ) ?></div>
			</a>
		<?php } ?>
	</div>
</section>