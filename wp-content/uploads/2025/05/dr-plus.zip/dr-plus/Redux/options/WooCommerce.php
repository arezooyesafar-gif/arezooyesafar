<?php
defined( 'ABSPATH' ) || exit;

Redux::set_section( // WooCommerce section
	$opt_name,
	array(
		'title'			=> esc_html__( 'WooCommerce', 'drplus' ),
		'id'			=> 'wc-general-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // product_badge
				'id'		=> 'product_badge',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Product badge status', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Enabled', 'drplus' ) ),
				'compiler'	=> true,
				'on'		=> esc_html__( 'Enabled', 'drplus' ),
				'off'		=> esc_html__( 'Disabled', 'drplus' ),
				'default'	=> true,
			],
			[ // sku_status
				'id'		=> 'sku_status',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'SKU status', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Enabled', 'drplus' ) ),
				'compiler'	=> true,
				'on'		=> esc_html__( 'Enabled', 'drplus' ),
				'off'		=> esc_html__( 'Disabled', 'drplus' ),
				'default'	=> true,
			],
		)
	)
);

Redux::set_section( // Shop archive
	$opt_name,
	array(
		'title'			=> esc_html__( 'Shop archive', 'drplus' ),
		'id'			=> 'wc-shop-archive-section',
		'subsection'	=> true,
		'fields'		=> array(
			[ // wc-move-out-of-stock-to-end
				'id'		=> 'wc-move-out-of-stock-to-end',
				'type'		=> 'switch',
				'title'		=> esc_html__( 'Move out of stock products to the end of the list', 'drplus' ),
				'subtitle'	=> sprintf( esc_html__( 'Default: %s', 'drplus' ), esc_html__( 'No', 'drplus' ) ) . "<br>" . esc_html__( "Caution: Enabling this feature may slow down the site speed.", 'drplus' ),
				'on'		=> esc_html__( 'Yes', 'drplus' ),
				'off'		=> esc_html__( 'No', 'drplus' ),
				'default'	=> false,
			],
			[ // wc-default-attribute-icon
				'id'		=> 'wc-default-attribute-icon',
				'type'			=> 'icon_select',
				'title'			=> esc_html__( 'Default attribute icon', 'drplus' ),
				'subtitle'		=> sprintf( __( "Default: %s", 'drplus' ), 'drplus-icon-diamond' ),
				'default'		=> 'drplus-icon-diamond',
				'enqueue_frontend'	=> false,
				'stylesheet'	=> [
					[
						'url'		=> DRPLUS_URI . 'assets/css/iconly.min.css',
						'title'		=> __( 'Doctor plus icons', 'drplus' ),
						'prefix'	=> 'drplus-icon',
					],
				],
			],
		),
	)
);

Redux::set_section( // Texts
	$opt_name,
	array(
		'title'			=> esc_html__( 'Texts', 'drplus' ),
		'id'			=> 'wc-texts-section',
		'subsection'	=> true,
		'fields'		=> array(
			[
				'id'		=> 'wc_add_to_cart_single_text',
				'type'		=> 'text',
				'title'		=> __( 'Add to cart (Single) text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Add to cart', 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> __( 'Add to cart', 'drplus' ),
			],
			[
				'id'		=> 'wc_empty_cart_text',
				'type'		=> 'text',
				'title'		=> __( 'Empty cart text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Your cart is empty!', 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> __( 'Your cart is empty!', 'drplus' ),
			],
			[
				'id'		=> 'wc_return_to_shop_text',
				'type'		=> 'text',
				'title'		=> __( 'Return to shop button text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Return to shop', 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> __( 'Return to shop', 'drplus' ),
			],
			[
				'id'		=> 'wc_checkout_text',
				'type'		=> 'text',
				'title'		=> __( 'Checkout button text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Checkout', 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> __( 'Checkout', 'woocommerce' ),
			],
			[
				'id'		=> 'wc_proceed_to_checkout_text',
				'type'		=> 'text',
				'title'		=> __( 'Proceed to checkout button text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Proceed to checkout', 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> __( 'Proceed to checkout', 'woocommerce' ),
			],
			[
				'id'		=> 'wc_pay_order_text',
				'type'		=> 'text',
				'title'		=> __( 'Pay order button text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'Pay and submit order', 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> __( 'Pay and submit order', 'drplus' ),
			],
			[
				'id'		=> 'wc_empty_orders_text',
				'type'		=> 'text',
				'title'		=> __( 'Empty orders page text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'No order has been made yet.', 'woocommerce' ) ),
				'compiler'	=> true,
				'default'	=> esc_html__( 'No order has been made yet.', 'woocommerce' ),
			],
			[
				'id'		=> 'wc_empty_downloads_text',
				'type'		=> 'text',
				'title'		=> __( 'Empty downloads page text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( 'No downloads available yet.', 'woocommerce' ) ),
				'compiler'	=> true,
				'default'	=> esc_html__( 'No downloads available yet.', 'woocommerce' ),
			],
			[
				'id'		=> 'wc_empty_shop_text',
				'type'		=> 'text',
				'title'		=> __( 'Empty shop page text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( "No product was found.", 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> esc_html__( 'No product was found.', 'drplus' ),
			],
			[
				'id'		=> 'wc_empty_notifications_text',
				'type'		=> 'text',
				'title'		=> __( 'Empty notifications page text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( "The notification list is empty.", 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> esc_html__( 'The notification list is empty.', 'drplus' ),
			],
			[
				'id'		=> 'wc_empty_wishlist_text',
				'type'		=> 'text',
				'title'		=> __( 'Empty wishlist page text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( "There are no products in wishlist.", 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> esc_html__( 'There are no products in wishlist.', 'drplus' ),
			],
			[
				'id'		=> 'wc_empty_appointments_text',
				'type'		=> 'text',
				'title'		=> __( 'Empty appointments page text', 'drplus' ),
				'subtitle'	=> sprintf( __( "Default: %s", 'drplus' ), esc_html__( "You have not booked any appointments yet.", 'drplus' ) ),
				'compiler'	=> true,
				'default'	=> esc_html__( 'You have not booked any appointments yet.', 'drplus' ),
			],
		),
	)
);