<?php
namespace DrPlus\Backend;

class Functions {
	public static function edit_specialist_post_link( $link, $post_id ) {
		$post = get_post( $post_id );
		if( $post->post_type == 'specialist' ) {
			$sid = absint( get_post_meta( $post_id, '_drplus_specialist_id', true ) );
			$link = admin_url( "admin.php?page=specialists&tab=view&sid={$sid}" );
		}

		return $link;
	}
}
add_filter( 'get_edit_post_link', [Functions::class, 'edit_specialist_post_link'], 10, 2 );