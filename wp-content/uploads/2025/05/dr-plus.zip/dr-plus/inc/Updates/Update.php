<?php
namespace DrPlus\Updates;

use DrPlus\Utils;

class Update {
	public static function execute() {
		$current_version = DRPLUS_VERSION;
		$last_updated_version = get_option( 'drplus_last_updated_version', '1.0.0.0' );
		if( version_compare( $current_version, $last_updated_version, '>' ) ) {
			if( !function_exists( 'WP_Filesystem' ) || !class_exists( 'WP_Filesystem_Direct' ) ) {
				require_once( ABSPATH . '/wp-admin/includes/file.php' );
				require_once( ABSPATH . '/wp-admin/includes/class-wp-filesystem-base.php' );
				require_once( ABSPATH . '/wp-admin/includes/class-wp-filesystem-direct.php' );
			}
			$wp_filesystem = new \WP_Filesystem_Direct( false );
			$versions = $wp_filesystem->dirlist( DRPLUS_DIR . "inc/Updates" );
			$versions = Utils::unset( $versions, ['Update.php'] );
			$versions = array_keys( $versions );
			$versions = array_map( function( $filename ) {
				$version = str_replace( ['V', '.php'], '', $filename );
				$version = str_replace( '_', '.', $version );
				return $version;
			}, $versions );
			$versions = array_filter( $versions, function( $version ) use( $last_updated_version ) {
				return version_compare( $last_updated_version, $version, '<' );
			} );

			foreach( $versions as $version ) {
				$version_filename = str_replace( '.', '_', $version );
				$filename = DRPLUS_DIR . "inc/Updates/V{$version_filename}.php";
				require( $filename );
				$class = "DrPlus\Updates\V" . $version_filename;
				$class::update();
			}

			update_option( 'drplus_last_updated_version', $current_version, false );
		}
	}
}
Update::execute();