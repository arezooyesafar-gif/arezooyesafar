<?php
namespace Drplus\Shortcodes;

if( !defined( 'ABSPATH' ) ) exit;

if( !class_exists( "\Drplus\Shortcodes\Booking" ) ) {
	class Booking {
		public static function view() {
			get_template_part( 'templates/booking/template-booking-base', null );
		}
	}
}
add_shortcode( 'drplus_booking', [Booking::class, 'view'] );